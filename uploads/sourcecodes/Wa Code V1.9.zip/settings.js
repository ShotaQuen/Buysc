const fs = require('fs');
const chalk = require('chalk');

global.storename = "Ikann"
global.botname = "IkannNew"
global.ownername = "Ikann"
global.owner = "6283137426460"
global.versi = "1.9"

global.packname = "ikann"
global.author = "Sticker"
global.wm = "ikann-2025"
global.chjid = "120363401697002820"
global.thum169 = "https://files.catbox.moe/zy1b8p.jpg"
global.thum11 = "https://files.catbox.moe/zwd5na.jpg"
global.linkSaluran = "https://whatsapp.com/channel/0029Vb6BnbsB4hdNFnu4gv3d"
global.namaSaluran = "ɪᴋᴀɴɴɴᴇᴡ - ᴜᴘᴅᴀᴛᴇ"
global.geminiToken = 'AIzaSyC01Fb7od3nOIoCCjsFN7J8DD5c34MPrNg'

global.mess = {
owner: "Fitur khusus owner!",
prem: "Fitur khusus premium!",
grup: "Fitur khusus grup chat!",
privat: "Fitur khusus privat chat!",
admin: "Fitur khusus admin!",
botadmin: "Bot bukan admin!",
no: "Kamu tidak dapat mengakses fitur ini!",
op: "Fitur khusus owner dan premium!",
or: "Fitur khusus owner dan reseller!",
ob: "Fitur khusus owner dan bot!",
oa: "Fitur khusus owner dan admin!"
}

// true pake prefix
global.prefixx = true

// Cpanel Setting
global.gmailPanel = "@buyer.ikann"
global.domain = "https://luciferprivat.privatesrvr.xyz/" // Domain Panel
global.apikey = "ptlc_gsatfWtNsLM1DjyQQ1HwvzbGEtRyhfWFFcAU1rx4Gm1" // ptlc
global.capikey = "ptla_pdWjuCWzCzYmJswQ02BoIsQQfH9PMeahhg2cfhqQo1Q" // ptla

global.eggs = "15"
global.locc = "1"

// Orkut Settings
global.orkut = {
codeqr: "00020101021126570011ID.DANA.WWW011893600915371490188402097149018840303UMI51440014ID.CO.QRIS.WWW0215ID10243349864510303UMI5204729853033605802ID5910Ipan store6012Kab. Cilacap6105532836304B918",
merchant: "-",
key: "-"
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})