const axios = require('axios')
const { JSDOM } = require('jsdom')
const FormData = require('form-data')

let handler = async (m, { text, reply }) => {
  try {
    const headers = {
      'Accept': '*/*',
      'Referer': 'https://claudeai.one/',
      'Origin': 'https://claudeai.one'
    }

    const { data: html } = await axios.get('https://claudeai.one/', { headers })
    const doc = new JSDOM(html).window.document

    const nonce = doc.querySelector('[data-nonce]')?.getAttribute('data-nonce') || ''
    const postId = doc.querySelector('[data-post-id]')?.getAttribute('data-post-id') || ''
    const botId = doc.querySelector('[data-bot-id]')?.getAttribute('data-bot-id') || ''
    const clientId = 'JHFiony-' + Math.random().toString(36).substring(2, 12)

    const form = new FormData()
    form.append('_wpnonce', nonce)
    form.append('post_id', postId)
    form.append('url', 'https://claudeai.one')
    form.append('action', 'wpaicg_chat_shortcode_message')
    form.append('message', text || 'Hai there!')
    form.append('bot_id', botId)
    form.append('chatbot_identity', 'shortcode')
    form.append('wpaicg_chat_history', '[]')
    form.append('wpaicg_chat_client_id', clientId)

    const { data } = await axios.post(
      'https://claudeai.one/wp-admin/admin-ajax.php',
      form,
      { headers: { ...headers, ...form.getHeaders() } }
    )

    m.reply(data?.data)
  } catch (e) {
    m.reply(e.message)
  }
}

handler.help = ['claudeai']
handler.command = ['claudeai']
handler.tags = ['ai']

module.exports = handler