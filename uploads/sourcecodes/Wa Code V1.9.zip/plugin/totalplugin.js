const fs = require('fs')
const path = require('path')

let handler = async (m, { reply }) => {
    const pluginDir = path.join(__dirname) // folder ini (plugins/) 
    const files = fs.readdirSync(pluginDir).filter(f => f.endsWith('.js'))

    let teks = `*📦 Total Plugin: ${files.length}*\n\n`
    teks += files.map((f, i) => `${i + 1}. ${f}`).join('\n')

    m.reply(teks)
}

handler.command = ["totalplugin"]
handler.tags = ["main"]
handler.help = ["totalplugin"]
module.exports = handler