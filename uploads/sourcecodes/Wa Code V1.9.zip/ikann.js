process.on('uncaughtException', console.error)
process.on('unhandledRejection', console.error)

require('./settings')
require('./lib/menulist')
const { default: WAConnection, BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, getBinaryNodeChildren, useMultiFileAuthState, generateWAMessageContent, downloadContentFromMessage, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require('@whiskeysockets/baileys')
const fs = require('fs');
const path = require('path');
const { GoogleGenerativeAI } = require("@google/generative-ai")
const util = require('util');
const axios = require('axios');
const chalk = require('chalk');
const { Client } = require('ssh2');
const moment = require("moment-timezone");
const nou = require("node-os-utils");
const os = require('os');
const fetch = require('node-fetch');
const cron = require('node-cron');
const didyoumean = require('didyoumean');
const ffmpeg = require('fluent-ffmpeg')

const { exec, execSync } = require('child_process')

const own = JSON.parse(fs.readFileSync('./data/owner.json').toString())
const ress = JSON.parse(fs.readFileSync('./data/reseller.json').toString()) 
const adminnel = JSON.parse(fs.readFileSync('./data/adminnel.json').toString())
const onwnel = JSON.parse(fs.readFileSync('./data/onwnel.json').toString())
const patner = JSON.parse(fs.readFileSync('./data/patner.json').toString())
const prem = JSON.parse(fs.readFileSync('./data/premium.json'))
const jasher = JSON.parse(fs.readFileSync('./data/jpm.json'))

const { yt_search, angka, CatBox, CloudMini, toBase64, randomNomor } = require('./lib/scrape')

// ==========================
const family100 = {}
const suit = {}
const tictactoe = {}
const petakbom = {}
const tebakgambar = {}
const tebakkalimat = {}
const tebakkata = {}
const tebaklirik = {}
const tebakanime = {}
const tebaklagu = {}
const kuis = {}
const tebakkimia = {}
const tebakbendera = {}
const siapakahaku = {}
const asahotak = {}
const susunkata = {}
const caklontong = {}
const kuismath = {}
const tebakgame = {}
const permintaan = {}
const laporan = {}
const globalCooldowns = new Map();
const userSessions = {}
const exceptFiles = []
// ==========================

module.exports = ikann = async (ikann, m, chatUpdate, store) => {
	try {

const code = fs.readFileSync('./ikann.js', 'utf8')
var regex = /case\s+'([^']+)':/g
var matches = []
var match
while ((match = regex.exec(code))) {
matches.push(match[1])
}
global.help = Object.values(matches).flatMap(v => v ?? []).map(entry => entry.trim().split(' ')[0].toLowerCase()).filter(Boolean)
global.handlers = []
const handlersDir = path.join(__dirname, 'plugin')
fs.readdirSync(handlersDir).forEach(file => {
const filePath = path.join(handlersDir, file)
if (fs.statSync(filePath).isFile() && file.endsWith('.js')) {
const handler = require(filePath)
global.handlers.push(handler)
global.help.push(...handler.command)
}})

const body = (m.type === 'conversation') ? m.message.conversation : (m.type == 'imageMessage') ? m.message.imageMessage.caption : (m.type == 'videoMessage') ? m.message.videoMessage.caption : (m.type == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.type == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.type == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.type == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.type === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')
const prefix = "."
const isCmd = typeof body === 'string' && body.startsWith(prefix)
const command = isCmd && typeof body === 'string' ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ""
const botNumber = await ikann.decodeJid(ikann.user.id)
const bulan = moment.tz('Asia/Jakarta').format('DD MMMM')
const bulan2 = moment.tz('Asia/Jakarta').format('MMMM')
const bulan3 = moment.tz('Asia/Jakarta').format('DD')
const tahun = moment.tz('Asia/Jakarta').format('YYYY')
const tanggal = moment().tz("Asia/Jakarta").format("dddd, d")
const tanggall = moment().tz("Asia/Jakarta").format("d")
const wibTime = moment().tz('Asia/Jakarta').format('HH:mm:ss')

const isOwner = [owner, botNumber, ...own]
.filter(v => typeof v === 'string' && v.trim() !== '')
.map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
.includes(m.sender)
const isReseller = [owner, botNumber, ...ress]
.filter(v => typeof v === 'string' && v.trim() !== '')
.map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
.includes(m.sender)
const isAdminnel = [owner, botNumber, ...adminnel]
.filter(v => typeof v === 'string' && v.trim() !== '')
.map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
.includes(m.sender)
const isOwnnel = [owner, botNumber, ...onwnel]
.filter(v => typeof v === 'string' && v.trim() !== '')
.map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
.includes(m.sender)
const isPatner = [owner, botNumber, ...patner]
.filter(v => typeof v === 'string' && v.trim() !== '')
.map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
.includes(m.sender)
const isPremium = [owner, botNumber, ...prem]
.filter(v => typeof v === 'string' && v.trim() !== '') 
.map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
.includes(m.sender)
const isJasher = [owner, botNumber, ...jasher]
.filter(v => typeof v === 'string' && v.trim() !== '') 
.map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
.includes(m.sender)

if (budy.startsWith('=> ')) {
if (!m.fromMe && !isOwner) return
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)
}
return m.reply(bang)
}
try {
m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
m.reply(util.format(e))
}}

if (budy.startsWith('> ')) {
if (!m.fromMe && !isOwner) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(util.format(err))
}}

if (budy.startsWith('$ ')) {
if (!m.fromMe && !isOwner) return 
exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})}

const args = (typeof body === 'string' ? body.trim().split(/ +/) : []).slice(1)
const text = q = args.join(" ")
const quoted = m.quoted ? m.quoted : m
const from = m.key.remoteJid
const mime = (quoted.msg || quoted).mimetype || ''
const isMedia = /image|video|sticker|audio/.test(mime)
const isMediaa = /image|video/.test(mime)
const isPc = from.endsWith('@s.whatsapp.net')
const isGc = from.endsWith('@g.us')
const more = String.fromCharCode(8206)
const readmore = more.repeat(4001)
const qmsg = (quoted.msg || quoted)
const m2 = '`'
const sender = m.key.fromMe ? (ikann.user.id.split(':')[0]+'@s.whatsapp.net' || ikann.user.id) : (m.key.participant || m.key.remoteJid)
const groupMetadata = m.isGroup ? await ikann.groupMetadata(m.chat) :''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await participants.filter((v) => v.admin !== null).map((i) => i.id) : [] || [];
const groupOwner = m.isGroup ? groupMetadata?.owner : false;
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false;
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false;
const groupMembers = m.isGroup ? groupMetadata.participants : ''
const pushname = m.pushName || "Anak haram"
const froms = m.quoted ? m.quoted.sender : text ? (text.replace(/[^0-9]/g, '') ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : false) : false;
const tag = `${m.sender.split('@')[0]}`
const tagg = `${m.sender.split('@')[0]}`+'@s.whatsapp.net'
const isImage = (m == 'imageMessage')
const isVideo = (m == 'videoMessage')
const isAudio = (m == 'audioMessage')
const isSticker = (m == 'stickerMessage')
const k_a = '`'
const qlocJpm = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `IkannNew`,jpegThumbnail: ""}}}
const _p = prefix
const p_c = prefix+command
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

if (!ikann.public) {
if (!isOwner && !m.key.fromMe) return
}

const ftext = {key : {participant : '0@s.whatsapp.net', ...(m.chat ? { remoteJid: `status@broadcast` } : {}) }, message: {extendedTextMessage: {text: `${command} ${text}`,thumbnailUrl: thum11}}}
ikann.ments = (teks = '') => {
return teks.match('@') ? [...teks.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net') : []}
ikann.sendTeks = async(chatId, text = '', quoted = '', opts = {}) => {
return ikann.sendMessage(chatId, { text: text, mentions: await ikann.ments(text), ...opts}, {quoted: quoted})}
ikann.sendPoll = (jid, name = '', values = [], selectableCount = global.select) => {
return ikann.sendMessage(jid, {poll: { name, values, selectableCount }})}
const reply = (teks) => {
return ikann.sendMessage(m.chat, { text: teks, mentions: ikann.ments(teks) }, {quoted: m})
}

const replyOwn = (teks) => {
return ikann.sendMessage(owner + '@s.whatsapp.net', { text: teks, mentions: ikann.ments(teks) }, {quoted: m})
}
/*async function react() {
const clockIcons = ["🕐", "🕑", "🕒", "🕓", "🕔", "🕕", "🕖", 
"🕗", "🕘", "🕙", "🕚", "🕛", "🕜", "🕝", 
"🕞", "🕟", "🕠", "🕡", "🕢", "🕣", "🕤", 
"🕥", "🕦", "🕧"];

const duration = 600; // Durasi tiap emoji (ms)
let currentIndex = 0;
let intervalId = null;

// Fungsi untuk menghentikan animasi
const stop = () => {
if (intervalId) {
clearInterval(intervalId);
intervalId = null;
}
};

return new Promise((resolve) => {
intervalId = setInterval(async () => {
try {
await ikann.sendMessage(from, {
react: {
text: clockIcons[currentIndex],
key: m.key
}
});

currentIndex++;

// Berhenti otomatis ketika semua emoji sudah ditampilkan
if (currentIndex >= clockIcons.length) {
stop();
resolve(); // Animasi selesai
}
} catch (error) {
console.error("Gagal mengirim reaction:", error);
stop();
resolve(); // Tetap resolve meskipun error
}
}, duration);
});
}*/
async function react() {
await ikann.sendMessage(from, { react: { text: '⏳', key: m.key }})
}

if (wibTime < "23:59:59"){ var ucapanWaktu = 'Selamat malam'}
if (wibTime < "19:00:00"){ var ucapanWaktu = 'Selamat malam'}
if (wibTime < "18:00:00"){ var ucapanWaktu = 'Selamat sore'}
if (wibTime < "14:59:59"){ var ucapanWaktu = 'Selamat siang'}
if (wibTime < "10:00:00"){ var ucapanWaktu = 'Selamat pagi'}
if (wibTime < "06:00:00"){ var ucapanWaktu = 'Selamat pagi'}

// ==== Function Button
async function buttonjpm(chat, text, url1, watermarkText = `By ${wm}`, quotedMessage, mediaPath = null, mediaType = "image") {
    let mediaObject = {}
    let mediaMessage = {}

    if (mediaPath) {
        let mediaBuffer = fs.readFileSync(mediaPath)
        mediaObject = mediaType === "video" ? { video: mediaBuffer } : { image: mediaBuffer }

        const uploadFile = {
    		upload: ikann.waUploadToServer
    	};

    	mediaMessage = await prepareWAMessageMedia(mediaObject,
    		uploadFile,
    	);
    }

    let message = generateWAMessageFromContent(chat, {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    contextInfo: {
                        mentionedJid: [m.sender],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        businessMessageForwardInfo: { 
                            businessOwnerJid: ikann.decodeJid(ikann.user.id) 
                        },
                    },
                    body: proto.Message.InteractiveMessage.Body.create({ text: text }),
                    footer: proto.Message.InteractiveMessage.Footer.create({ text: watermarkText }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        title: '',
                        subtitle: '',
                        hasMediaAttachment: !!mediaPath
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [{ 
                            name: "cta_url", 
                            buttonParamsJson: url1 
                        }]
                    })
                })
            }
        }
    }, { quoted: quotedMessage })

    if (mediaPath) {
        Object.assign(message.message.viewOnceMessage.message.interactiveMessage.header, mediaMessage)
    }

    await ikann.relayMessage(chat, message.message, { messageId: message.key.id })
}

ikann.sendButtonImage = async(chat, judul, teks, imageUrl, button, wmnye = `By ${wm}`, q) => {
let { data } = await axios.get(imageUrl, { responseType: 'arraybuffer' })
const uploadFile = { upload: ikann.waUploadToServer };
var imageMessage = await prepareWAMessageMedia(
{ image: data, }, uploadFile, )
let msg = generateWAMessageFromContent(chat, {
viewOnceMessage: {
message: {
"messageContextInfo": {
"deviceListMetadata": {},
"deviceListMetadataVersion": 2
},
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: {
mentionedJid: ikann.ments(teks),
forwardingScore: 9999999, 
isForwarded: true, 
forwardedNewsletterMessageInfo: {
newsletterJid: chjid + "@newsletter",
newsletterName: `Channel ${wm}`, 
serverMessageId: -1
},
businessMessageForwardInfo: { businessOwnerJid: ikann.decodeJid(ikann.user.id) },
},
body: proto.Message.InteractiveMessage.Body.create({
text: teks
}),
footer: proto.Message.InteractiveMessage.Footer.create({
text: wmnye
}),
header: proto.Message.InteractiveMessage.Header.create({
title: judul,
subtitle: "P",
imageMessage: imageMessage.imageMessage,
hasMediaAttachment: true
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
buttons: button,
})})
}}
}, { quoted: q })
ikann.relayMessage(msg.key.remoteJid, msg.message, {
messageId: msg.key.id
})
}

async function buttonpanel(chat, teks, copy1, copy2, lohmain, wmnye = `By ${wm}`, jm) {
  let msg = generateWAMessageFromContent(chat, {
    viewOnceMessage: {
      message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          contextInfo: {
            mentionedJid: [m.sender],
            forwardingScore: 9999999, 
            isForwarded: true, 
            forwardedNewsletterMessageInfo: {
              newsletterJid: chjid + "@newsletter",
newsletterName: `Channel ${wm}`, 
              serverMessageId: 145
            },
            businessMessageForwardInfo: { 
              businessOwnerJid: ikann.decodeJid(ikann.user.id) 
            },
          },
          body: proto.Message.InteractiveMessage.Body.create({
            text: teks
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wmnye
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: '',
            subtitle: '',
            hasMediaAttachment: false
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Username\",\"id\":\"${copy1}\",\"copy_code\":\"${copy1}\"}`
              },
              {
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Password\",\"id\":\"${copy2}\",\"copy_code\":\"${copy2}\"}`
              },
              {
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Login\",\"url\":\"${lohmain}\",\"merchant_url\":\"${lohmain}\"}`
              }
            ],
          })
        })
      }
    }
  }, { quoted: jm });

  await ikann.relayMessage(msg.key.remoteJid, msg.message, {
    messageId: msg.key.id
  });
}

async function copybut(chat, teks, name, copy, wmnye = `By ${wm}`, jm) {
let msg = generateWAMessageFromContent(chat, {
viewOnceMessage: {
message: {
"messageContextInfo": {
"deviceListMetadata": {},
"deviceListMetadataVersion": 2
},
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: {
mentionedJid: [m.sender],
forwardingScore: 9999999, 
isForwarded: true, 
forwardedNewsletterMessageInfo: {
newsletterJid: null,
newsletterName: null, 
serverMessageId: 145
},
businessMessageForwardInfo: { 
businessOwnerJid: ikann.decodeJid(ikann.user.id) },
},
body: proto.Message.InteractiveMessage.Body.create({
text: teks
}),
footer: proto.Message.InteractiveMessage.Footer.create({
text: wmnye
}),
header: proto.Message.InteractiveMessage.Header.create({
title: '',
subtitle: '',
hasMediaAttachment: false
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
buttons: [
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"${name}\",\"id\":\"${copy}\",\"copy_code\":\"${copy}\"}`
}
],
})})
}}
}, { quoted: jm })
await ikann.relayMessage(msg.key.remoteJid, msg.message, {
messageId: msg.key.id
})
}

async function quickreply1(chat, teks, quick1, wmnye = `By ${wm}`, jm) {
let msg = generateWAMessageFromContent(chat, {
viewOnceMessage: {
message: {
"messageContextInfo": {
"deviceListMetadata": {},
"deviceListMetadataVersion": 2
},
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: {
mentionedJid: [m.sender],
forwardingScore: 9999999, 
isForwarded: true, 
forwardedNewsletterMessageInfo: {
newsletterJid: null,
newsletterName: null, 
serverMessageId: -1
},
businessMessageForwardInfo: { businessOwnerJid: ikann.decodeJid(ikann.user.id) },
},
body: proto.Message.InteractiveMessage.Body.create({
text: teks
}),
footer: proto.Message.InteractiveMessage.Footer.create({
text: wmnye
}),
header: proto.Message.InteractiveMessage.Header.create({
title: '',
subtitle: '',
hasMediaAttachment: false
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
buttons: [
{
"name": "quick_reply",
"buttonParamsJson": quick1
}
],
})})
}}
}, { quoted: jm })
await ikann.relayMessage(msg.key.remoteJid, msg.message, {
messageId: msg.key.id
})
}

async function listbut2(chat, teks, listnye, jm) {
let msg = generateWAMessageFromContent(m.chat, {
viewOnceMessage: {
message: {
"messageContextInfo": {
"deviceListMetadata": {},
"deviceListMetadataVersion": 2
},
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: {
mentionedJid: [m.sender],
forwardingScore: 999999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterJid: chjid + "@newsletter",
newsletterName: `Channel ${wm}`,
serverMessageId: 145
}
},
body: proto.Message.InteractiveMessage.Body.create({
text: teks
}),
footer: proto.Message.InteractiveMessage.Footer.create({
text: `By ${wm}`
}),
header: proto.Message.InteractiveMessage.Header.create({
title: ``,
thumbnailUrl: "",
gifPlayback: true,
subtitle: "",
hasMediaAttachment: true,
...(await prepareWAMessageMedia({
document: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
mimetype: "image/png",
fileLength: 99999999999999,
jpegThumbnail: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
fileName: `${botname.toUpperCase()}`,
}, {
upload: ikann.waUploadToServer
}))
}),
gifPlayback: true,
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
buttons: [
{
"name": "single_select",
"buttonParamsJson": JSON.stringify(listnye)
}],
}), })}
}}, {quoted: jm})
await ikann.relayMessage(msg.key.remoteJid, msg.message, {
messageId: msg.key.id
})
}

ikann.sendButtonSpecial = async(chat, judul, teks, thumb, button, quot) => {
let msg = generateWAMessageFromContent(chat, {
    viewOnceMessage: {
        message: {
            "messageContextInfo": {
                "deviceListMetadata": {},
                "deviceListMetadataVersion": 2
            },
            interactiveMessage: proto.Message.InteractiveMessage.create({
                contextInfo: {
                    mentionedJid: ikann.ments(teks),
                    externalAdReply: {
                        showAdAttribution: true,
                        containsAutoReply: true,
                        title: `Ikann`,
                        body: `Rawr`,
                        thumbnailUrl: thumb,
                        sourceUrl: '',
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                },
                body: proto.Message.InteractiveMessage.Body.create({
                    text: teks
                }),
                footer: proto.Message.InteractiveMessage.Footer.create({
                    text: 'IkannNew 2030'
                }),
                header: proto.Message.InteractiveMessage.Header.create({
                    title: judul,
                    thumbnailUrl: thumb,
                    gifPlayback: true,
                    subtitle: "IkannNew",
                    hasMediaAttachment: true,
                    ...(await prepareWAMessageMedia({
                        document: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
                    mimetype: "application/pdf",
                        fileLength: 15000000,
                        jpegThumbnail:fs.readFileSync("./lib/thumbnail/thumbnail169.jpg"),
                        fileName: `Ikann`,
                     }, {
                        upload: ikann.waUploadToServer
                    }))
                }),
                gifPlayback: true,
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: button,
          })
        })
    }
  }
}, { quoted: m })

await ikann.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})
}

// ==== Function YtDl
const { ytM4, ytM3 } = require('./lib/scrape')
const downloadMp4 = async (link) => {
try {
const { download } = await ytM4(link)
if (download) {
ikann.sendMessage(m.chat, { video: { url: download } }, { quoted: m })
} else {
throw new Error('Aduh error')
}} catch (err) {
m.reply('Aduh, videonya ga bisa di-download... Coba lagi nanti')
console.error(err)
}}

const downloadMp3 = async (link) => {
try {
const { download } = await ytM3(link)
if (download) {
ikann.sendMessage(m.chat, { audio: { url: download }, mimetype: 'audio/mpeg' }, { quoted: m })
} else {
throw new Error('Aduh error')
}} catch (err) {
m.reply('Aduh, audionya ga bisa di-download... Coba lagi nanti')
console.error(err)
}}

const { downloader } = require('@ikanngeming/blubub')
const downloadMp4v2 = async (link) => {
try {
const result = await downloader.ytdlv2(link, 'mp4', 480)
if (result.download) {
const buffer = fs.readFileSync(result.download)
ikann.sendMessage(m.chat, { video: buffer }, { quoted: m })
fs.unlinkSync(result.download)
} else {
throw new Error('Aduh error')
}} catch (err) {
m.reply('Aduh, videonya ga bisa di-download... Coba lagi nanti')
console.error(err)
}}

const downloadMp3v2 = async (link) => {
try {
const result = await downloader.ytdlv2(link, 'mp3', 320)
if (result.download) {
const buffer = fs.readFileSync(result.download)
ikann.sendMessage(m.chat, { audio: buffer, mimetype: 'audio/mpeg' }, { quoted: m })
fs.unlinkSync(result.download)
} else {
throw new Error('Aduh error')
}} catch (err) {
m.reply('Aduh, audionya ga bisa di-download... Coba lagi nanti')
console.error(err)
}}

// ==== Function Game
const parseMention = (text = '') => {
    return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net')
}

if ((from in family100)) {
let { soal, jawaban, hadiah, waktu } = family100[from]
for (let i of jawaban){
if (body.toLowerCase().includes(i)) {
let anu = jawaban.indexOf(i)
jawaban.splice(anu, 1)
m.reply(`*GAME FAMILY 100*\nJawaban kamu benar!\n\nJawaban: ${i}\n\n${jawaban.length < 1 ? 'Semua jawaban sudah tertebak!\nHadiah: 12 limit' : 'Sisa yang belum ditebak : '+jawaban.length}`)
}}
if (jawaban.length < 1){
addLimit(tagg, 12)
clearTimeout(waktu);
delete family100[from];
}}

this.game = this.game ? this.game : {}
let room = Object.values(this.game).find(room => room.id && room.game && room.state && room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender) && room.state == 'PLAYING')
if (room) {
let ok
let isWin = !1
let isTie = !1
let isSurrender = !1
if (!/^([1-9]|(me)?.nyerah|surr?ender|off|skip)$/i.test(m.text)) return
isSurrender = !/^[1-9]$/.test(m.text)
if (m.sender !== room.game.currentTurn) {
if (!isSurrender) return !0
}
if (!isSurrender && 1 > (ok = room.game.turn(m.sender === room.game.playerO, parseInt(m.text) - 1))) {
m.reply({
'-3': 'Game telah berakhir',
'-2': 'Invalid',
'-1': 'Posisi invalid',
0: 'Posisi invalid',
}[ok])
return !0
}
if (m.sender === room.game.winner) isWin = true
else if (room.game.board === 511) isTie = true
let arr = room.game.render().map(v => {
return {
X: '❌',
O: '⭕',
1: '1️⃣',
2: '2️⃣',
3: '3️⃣',
4: '4️⃣',
5: '5️⃣',
6: '6️⃣',
7: '7️⃣',
8: '8️⃣',
9: '9️⃣',
}[v]
})
if (isSurrender) {
room.game._currentTurn = m.sender === room.game.playerX
isWin = true
}
let winner = isSurrender ? room.game.currentTurn : room.game.winner
let str = `Room ID: ${room.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

${isWin ? `@${winner.split('@')[0]} Menang!` : isTie ? `Game telah berakhir` : `Giliran ${['❌', '⭕'][1 * room.game._currentTurn]} (@${room.game.currentTurn.split('@')[0]})`}
❌: @${room.game.playerX.split('@')[0]}
⭕: @${room.game.playerO.split('@')[0]}

${isWin ? `@${winner.split('@')[0]} Menang!` : isTie ? `Game telah berakhir` : `Ketik .nyerah tuk menyerah`}`
if ((room.game._currentTurn ^ isSurrender ? room.x : room.o) !== m.chat)
room[room.game._currentTurn ^ isSurrender ? 'x' : 'o'] = m.chat
if (room.x !== room.o) await ikann.sendText(room.x, str, m, { mentions: parseMention(str) } )
await ikann.sendText(room.o, str, m, { mentions: parseMention(str) } )
if (isTie || isWin) {
delete this.game[room.id]
}}

let roof = Object.values(suit).find(roof => roof.id && roof.status && [roof.p, roof.p2].includes(m.sender))
if (roof) {
let win = ''
let tie = false
if (m.sender == roof.p2 && /^(acc(ept)?|y|gas|oke?|tolak|gamau|nanti|ga(k.)?bisa|y)/i.test(body) && m.isGroup && roof.status == 'Wait') {
if (/^(gamau|nanti|ga(k.)?bisa)/i.test(body)) {
pokl = `@${roof.p2.split('@')[0]} menolak suit, S
suit dibatalkan!`
await ikann.sendTeks(from, pokl, m)
delete suit[roof.id]
return !0
}
roof.status = 'play'
roof.asal = from
clearTimeout(roof.waktu)

teksbbb = `AYO PILIH SUIT MU`
ggy = `Suit telah dikirimkan ke chat

1. @${roof.p.split('@')[0]}
2. @${roof.p2.split('@')[0]}

Silahkan pilih suit di chat masing"`
await ikann.sendTeks(from, ggy, fkontak)
if (!roof.pilih) await ikann.sendTeks(roof.p, teksbbb+'\n\n• Gunting\n• Batu\n• Kertas', m)
if (!roof.pilih2) await ikann.sendTeks(roof.p2, teksbbb+'\n\n• Gunting\n• Batu\n• Kertas', m)
roof.waktu_milih = setTimeout(async() => {
if (!roof.pilih && !roof.pilih2) await ikann.sendMessage(from, {text: `Kedua pemain tidak niat bermain\nSuit dibatalkan!`})
else if (!roof.pilih || !roof.pilih2) {
win = !roof.pilih ? roof.p2 : roof.p
sffp = `@${(roof.pilih ? roof.p2 : roof.p).split('@')[0]} tidak memilih suit, game berakhir!`
await ikann.sendTeks(from, sffp, fkontak)
}
delete suit[roof.id]
return !0
}, roof.timeout)
}
let jwb = m.sender == roof.p
let jwb2 = m.sender == roof.p2
let g = /^(.gunting|gunting)/i
let b = /^(.batu|batu)/i
let k = /^(.kertas|kertas)/i
let reg = /^(.gunting|.batu|.kertas|gunting|batu|kertas)/i
if (jwb && reg.test(body) && !roof.pilih && !m.isGroup) {
roof.pilih = reg.exec(body.toLowerCase())[0]
roof.text = body
await ikann.sendMessage(from, {text: `Kamu telah memilih ${body} ${!roof.pilih2 ? `\n\nMenunggu lawan memilih` : ''}`}, {quoted:fkontak})
if (!roof.pilih2) await ikann.sendMessage(roof.p2, {text: 'Lawan sudah memilih\nSekarang giliran kamu'})
}
if (jwb2 && reg.test(body) && !roof.pilih2 && !m.isGroup) {
roof.pilih2 = reg.exec(body.toLowerCase())[0]
roof.text2 = body

tyu = `Kamu telah memilih ${body} ${!roof.pilih ? `\n\nMenunggu lawan memilih` : ''}`
await ikann.sendMessage(from, {text: tyu}, {quoted:m})

if (!roof.pilih) await ikann.sendMessage(roof.p, {text: 'Lawan sudah memilih\nSekarang giliran kamu'})
}
let stage = roof.pilih
let stage2 = roof.pilih2
if (roof.pilih && roof.pilih2) {
clearTimeout(roof.waktu_milih)
if (b.test(stage) && g.test(stage2)) win = roof.p
else if (b.test(stage) && k.test(stage2)) win = roof.p2
else if (g.test(stage) && k.test(stage2)) win = roof.p
else if (g.test(stage) && b.test(stage2)) win = roof.p2
else if (k.test(stage) && b.test(stage2)) win = roof.p
else if (k.test(stage) && g.test(stage2)) win = roof.p2
else if (stage == stage2) tie = true
await ikann.sendTeks(roof.asal, `${tie ? '*HASIL SERI*\n\n' : ''}@${roof.p.split('@')[0]} (${roof.text}) ${tie ? '' : roof.p == win ? 'Menang' : 'Kalah'}\n@${roof.p2.split('@')[0]} (${roof.text2}) ${tie ? '' : roof.p2 == win ? 'Menang' : 'Kalah'}`, bejir('HASIL SUIT PVP', null))
delete suit[roof.id]
}}

let pilih = "◽", bomb = "💣";
if (petakbom[m.sender]) {
if (!/^[1-9]|10$/i.test(body)) return !0;
if (petakbom[m.sender].petak[parseInt(body) - 1] === 1) return !0;
if (petakbom[m.sender].petak[parseInt(body) - 1] === 2) {
petakbom[m.sender].board[parseInt(body) - 1] = bomb;
petakbom[m.sender].pick++;
petakbom[m.sender].bomb--;
petakbom[m.sender].nyawa.pop();

let brd = petakbom[m.sender].board;
if (petakbom[m.sender].nyawa.length < 1) {
await m.reply(`*GAME TELAH BERAKHIR*\nKamu terkena bom!\n\n ${brd.slice(0, 3).join("")}\n${brd.slice(3, 6).join("")}\n${brd.slice(6).join("")}\n\nTerpilih: ${petakbom[m.sender].pick}`);
delete petakbom[m.sender];
} else await m.reply(`*PILIH ANGKA*\n\nKamu terkena bom!\n ${brd.slice(0, 3).join("")}\n${brd.slice(3, 6).join("")}\n${brd.slice(6).join("")}\n\nTerpilih: ${petakbom[m.sender].pick}\nNyawa: ${petakbom[m.sender].nyawa}`);
return !0;
}
if (petakbom[m.sender].petak[parseInt(body) - 1] === 0) {
petakbom[m.sender].petak[parseInt(body) - 1] = 1;
petakbom[m.sender].board[parseInt(body) - 1] = pilih;
petakbom[m.sender].pick++;
petakbom[m.sender].lolos--;
let brd = petakbom[m.sender].board;
if (petakbom[m.sender].lolos < 1) {
await m.reply(`*KAMU MENANG*\n\n${brd.slice(0, 3).join("")}\n${brd.slice(3, 6).join("")}\n${brd.slice(6).join("")}\n\nTerpilih: ${petakbom[m.sender].pick}\nSisa Nyawa: ${petakbom[m.sender].nyawa}\nBom: ${petakbom[m.sender].bomb}`);
delete petakbom[m.sender];
} else m.reply(`*PILIH ANGKA*\n\n${brd.slice(0, 3).join("")}\n${brd.slice(3, 6).join("")}\n${brd.slice(6).join("")}\n\nTerpilih: ${petakbom[m.sender].pick}\nSisa Nyawa: ${petakbom[m.sender].nyawa}\nBom: ${petakbom[m.sender].bomb}`)
}}

if (fs.existsSync(`./data/${m.chat}.json`)) {
var casinoo = setCasino(`${m.chat}`)
if (m.sender == `${casinoo.Y}` && body.toLowerCase() == 'n') {
ikann.sendMessage(m.chat, { text: `*GAME DIBATALKAN*\n\n• @${casinoo.Y.split("@")[0]} Membatalkan game`, mentions: [casinoo.Y] }, {quoted: m })
deleteCasino(m.chat)
}
if (m.sender == `${casinoo.Y}` && body.toLowerCase() == 'y') {
var angka1 = await randomNomor(10, 20)
var angka2 = await randomNomor(10, 20)
if (angka1 > angka2) {
starGame = `*🎰 GAME CASINO 💰*

• @${casinoo.Z} --> ${angka1} 👑
• @${casinoo.Y.split('@')[0]} --> ${angka2} 🥈

Pemenang: [ @${casinoo.Z} ]
Mendapatkan: Rp ${nebal(casinoo.nominal)}`
ikann.sendMessage(m.chat, { text: starGame, mentions: [casinoo.Z + "@s.whatsapp.net", casinoo.Y]}, {quoted: m })
await addSaldo(`${casinoo.Z}@s.whatsapp.net`, nebal(casinoo.nominal))
await minSaldo(`${casinoo.Y}`, nebal(casinoo.nominal))
deleteCasino(m.chat)
} else if (angka1 < angka2) {
starGame = `*🎰 GAME CASINO 💰*

• @${casinoo.Z} --> ${angka1} 🥈
• @${casinoo.Y.split('@')[0]} --> ${angka2} 👑

Pemenang: [ @${casinoo.Y.split('@')[0]} ]
Mendapatkan: Rp ${nebal(casinoo.nominal)}`
ikann.sendMessage(m.chat, { text: starGame, mentions: [casinoo.Z + "@s.whatsapp.net", casinoo.Y] }, {quoted: m })
await addSaldo(`${casinoo.Y}`, nebal(casinoo.nominal))
await minSaldo(`${casinoo.Z}@s.whatsapp.net`, nebal(casinoo.nominal))
deleteCasino(m.chat)
} else if (angka1 = angka2) {
starGame = `*🎰 GAME CASINO 💰*

• @${casinoo.Z} --> ${angka1} 📍
• @${casinoo.Y.split('@')[0]} --> ${angka2} 📍

Hasil draw, tidak ada pemenang!`
ikann.sendMessage(m.chat, { text: starGame, mentions: [casinoo.Z + "@s.whatsapp.net", casinoo.Y]}, { quoted: m })
deleteCasino(m.chat)
}}
}

if ((from in tebakgambar)) {
let { soal, jawaban, hadiah, waktu } = tebakgambar[m.chat]
if (body.toLowerCase().includes(jawaban) && !m.fromMe) {
await m.reply(`*JAWABAN BENAR*\nJawaban: ${jawaban}\nHadiah: 6 limit`);
addLimit(tagg, 6)
ikann.sendMessage(m.chat, {react: {text: '🔵', key: m.key}})
clearTimeout(waktu);
delete tebakgambar[m.chat];
} else if (!m.fromMe && m.text.includes('.nyerah')) {
ikann.sendMessage(m.chat, {react: {text: '🙂', key: m.key,}})
await ikann.sendMessage(m.chat, {text: `*KAMU MENYERAH*\nSoal: ${soal}\nJawaban: ${jawaban}`}, {quoted: m})
clearTimeout(waktu);
delete tebakgambar[m.chat];
} else if (!m.fromMe) {
ikann.sendMessage(m.chat, {react: {text: '🔴', key: m.key,}})}
}

if ((from in tebakkalimat)) {
let { soal, jawaban, hadiah, waktu } = tebakkalimat[m.chat]
if (body.toLowerCase().includes(jawaban) && !m.fromMe) {
await m.reply(`*JAWABAN BENAR*\nJawaban: ${jawaban}\nHadiah: 6 limit`);
addLimit(tagg, 6)
ikann.sendMessage(m.chat, {react: {text: '🔵', key: m.key}})
clearTimeout(waktu);
delete tebakkalimat[m.chat];
} else if (!m.fromMe && m.text.includes('.nyerah')) {
ikann.sendMessage(m.chat, {react: {text: '🙂', key: m.key,}})
await ikann.sendMessage(m.chat, {text: `*KAMU MENYERAH*\nSoal: ${soal}\nJawaban: ${jawaban}`}, {quoted: m})
clearTimeout(waktu);
delete tebakkalimat[m.chat];
} else if (!m.fromMe) {
ikann.sendMessage(m.chat, {react: {text: '🔴', key: m.key,}})}
}

if ((from in tebakkata)) {
let { soal, jawaban, hadiah, waktu } = tebakkata[m.chat]
if (body.toLowerCase().includes(jawaban) && !m.fromMe) {
await m.reply(`*JAWABAN BENAR*\nJawaban: ${jawaban}\nHadiah: 6 limit`);
addLimit(tagg, 6)
ikann.sendMessage(m.chat, {react: {text: '🔵', key: m.key}})
clearTimeout(waktu);
delete tebakkata[m.chat];
} else if (!m.fromMe && m.text.includes('.nyerah')) {
ikann.sendMessage(m.chat, {react: {text: '🙂', key: m.key,}})
await ikann.sendMessage(m.chat, {text: `*KAMU MENYERAH*\nSoal: ${soal}\nJawaban: ${jawaban}`}, {quoted: m})
clearTimeout(waktu);
delete tebakkata[m.chat];
} else if (!m.fromMe) {
ikann.sendMessage(m.chat, {react: {text: '🔴', key: m.key,}})}
}

if ((from in tebaklirik)) {
let { soal, jawaban, hadiah, waktu } = tebaklirik[m.chat]
if (body.toLowerCase().includes(jawaban) && !m.fromMe) {
await m.reply(`*JAWABAN BENAR*\nJawaban: ${jawaban}\nHadiah: 6 limit`);
addLimit(tagg, 6)
ikann.sendMessage(m.chat, {react: {text: '🔵', key: m.key}})
clearTimeout(waktu);
delete tebaklirik[m.chat];
} else if (!m.fromMe && m.text.includes('.nyerah')) {
ikann.sendMessage(m.chat, {react: {text: '🙂', key: m.key,}})
await ikann.sendMessage(m.chat, {text: `*KAMU MENYERAH*\nSoal: ${soal}\nJawaban: ${jawaban}`}, {quoted: m})
clearTimeout(waktu);
delete tebaklirik[m.chat];
} else if (!m.fromMe) {
ikann.sendMessage(m.chat, {react: {text: '🔴', key: m.key,}})}
}

if ((from in tebakanime)) {
let { soal, jawaban, hadiah, waktu } = tebakanime[m.chat]
if (body.toLowerCase().includes(jawaban) && !m.fromMe) {
await m.reply(`*JAWABAN BENAR*\nJawaban: ${jawaban}\nHadiah: 6 limit`);
addLimit(tagg, 6)
ikann.sendMessage(m.chat, {react: {text: '🔵', key: m.key}})
clearTimeout(waktu);
delete tebakanime[m.chat];
} else if (!m.fromMe && m.text.includes('.nyerah')) {
ikann.sendMessage(m.chat, {react: {text: '🙂', key: m.key,}})
await ikann.sendMessage(m.chat, {text: `*KAMU MENYERAH*\nSoal: ${soal}\nJawaban: ${jawaban}`}, {quoted: m})
clearTimeout(waktu);
delete tebakanime[m.chat];
} else if (!m.fromMe) {
ikann.sendMessage(m.chat, {react: {text: '🔴', key: m.key,}})}
}

if ((from in tebaklagu)) {
let { soal, jawaban, hadiah, waktu } = tebaklagu[m.chat]
if (body.toLowerCase().includes(jawaban) && !m.fromMe) {
await m.reply(`*JAWABAN BENAR*\nJawaban: ${jawaban}\nHadiah: 6 limit`);
addLimit(tagg, 6)
ikann.sendMessage(m.chat, {react: {text: '🔵', key: m.key}})
clearTimeout(waktu);
delete tebaklagu[m.chat];
} else if (!m.fromMe && m.text.includes('.nyerah')) {
ikann.sendMessage(m.chat, {react: {text: '🙂', key: m.key,}})
await ikann.sendMessage(m.chat, {text: `*KAMU MENYERAH*\nSoal: ${soal}\nJawaban: ${jawaban}`}, {quoted: m})
clearTimeout(waktu);
delete tebaklagu[m.chat];
} else if (!m.fromMe) {
ikann.sendMessage(m.chat, {react: {text: '🔴', key: m.key,}})}
}

if ((from in kuis)) {
let { soal, jawaban, hadiah, waktu } = kuis[m.chat]
if (body.toLowerCase().includes(jawaban) && !m.fromMe) {
await m.reply(`*JAWABAN BENAR*\nJawaban: ${jawaban}\nHadiah: 6 limit`);
addLimit(tagg, 6)
ikann.sendMessage(m.chat, {react: {text: '🔵', key: m.key}})
clearTimeout(waktu);
delete kuis[m.chat];
} else if (!m.fromMe && m.text.includes('.nyerah')) {
ikann.sendMessage(m.chat, {react: {text: '🙂', key: m.key,}})
await ikann.sendMessage(m.chat, {text: `*KAMU MENYERAH*\nSoal: ${soal}\nJawaban: ${jawaban}`}, {quoted: m})
clearTimeout(waktu);
delete kuis[m.chat];
} else if (!m.fromMe) {
ikann.sendMessage(m.chat, {react: {text: '🔴', key: m.key,}})}
}

if ((from in siapakahaku)) {
let { soal, jawaban, hadiah, waktu } = siapakahaku[m.chat]
if (body.toLowerCase().includes(jawaban) && !m.fromMe) {
await m.reply(`*JAWABAN BENAR*\nJawaban: ${jawaban}\nHadiah: 6 limit`);
addLimit(tagg, 6)
ikann.sendMessage(m.chat, {react: {text: '🔵', key: m.key}})
clearTimeout(waktu);
delete siapakahaku[m.chat];
} else if (!m.fromMe && m.text.includes('.nyerah')) {
ikann.sendMessage(m.chat, {react: {text: '🙂', key: m.key,}})
await ikann.sendMessage(m.chat, {text: `*KAMU MENYERAH*\nSoal: ${soal}\nJawaban: ${jawaban}`}, {quoted: m})
clearTimeout(waktu);
delete siapakahaku[m.chat];
} else if (!m.fromMe) {
ikann.sendMessage(m.chat, {react: {text: '🔴', key: m.key,}})}
}

if ((from in tebakkimia)) {
let { soal, jawaban, hadiah, waktu } = tebakkimia[m.chat]
if (body.toLowerCase().includes(jawaban) && !m.fromMe) {
await m.reply(`*JAWABAN BENAR*\nJawaban: ${jawaban}\nHadiah: 6 limit`);
addLimit(tagg, 6)
ikann.sendMessage(m.chat, {react: {text: '🔵', key: m.key}})
clearTimeout(waktu);
delete tebakkimia[m.chat];
} else if (!m.fromMe && m.text.includes('.nyerah')) {
ikann.sendMessage(m.chat, {react: {text: '🙂', key: m.key,}})
await ikann.sendMessage(m.chat, {text: `*KAMU MENYERAH*\nSoal: ${soal}\nJawaban: ${jawaban}`}, {quoted: m})
clearTimeout(waktu);
delete tebakkimia[m.chat];
} else if (!m.fromMe) {
ikann.sendMessage(m.chat, {react: {text: '🔴', key: m.key,}})}
}

if ((from in tebakbendera)) {
let { soal, jawaban, hadiah, waktu } = tebakbendera[m.chat]
if (body.toLowerCase().includes(jawaban) && !m.fromMe) {
await m.reply(`*JAWABAN BENAR*\nJawaban: ${jawaban}\nHadiah: 6 limit`);
addLimit(tagg, 6)
ikann.sendMessage(m.chat, {react: {text: '🔵', key: m.key}})
clearTimeout(waktu);
delete tebakbendera[m.chat];
} else if (!m.fromMe && m.text.includes('.nyerah')) {
ikann.sendMessage(m.chat, {react: {text: '🙂', key: m.key,}})
await ikann.sendMessage(m.chat, {text: `*KAMU MENYERAH*\nSoal: ${soal}\nJawaban: ${jawaban}`}, {quoted: m})
clearTimeout(waktu);
delete tebakbendera[m.chat];
} else if (!m.fromMe) {
ikann.sendMessage(m.chat, {react: {text: '🔴', key: m.key,}})}
}

if ((from in asahotak)) {
let { soal, jawaban, hadiah, waktu } = asahotak[m.chat]
if (body.toLowerCase().includes(jawaban) && !m.fromMe) {
await m.reply(`*JAWABAN BENAR*\nJawaban: ${jawaban}\nHadiah: 6 limit`);
addLimit(tagg, 6)
ikann.sendMessage(m.chat, {react: {text: '🔵', key: m.key}})
clearTimeout(waktu);
delete asahotak[m.chat];
} else if (!m.fromMe && m.text.includes('.nyerah')) {
ikann.sendMessage(m.chat, {react: {text: '🙂', key: m.key,}})
await ikann.sendMessage(m.chat, {text: `*KAMU MENYERAH*\nSoal: ${soal}\nJawaban: ${jawaban}`}, {quoted: m})
clearTimeout(waktu);
delete asahotak[m.chat];
} else if (!m.fromMe) {
ikann.sendMessage(m.chat, {react: {text: '🔴', key: m.key,}})}
}

if ((from in susunkata)) {
let { soal, jawaban, hadiah, waktu } = susunkata[m.chat]
if (body.toLowerCase().includes(jawaban) && !m.fromMe) {
await m.reply(`*JAWABAN BENAR*\nJawaban: ${jawaban}\nHadiah: 6 limit`);
addLimit(tagg, 6)
ikann.sendMessage(m.chat, {react: {text: '🔵', key: m.key}})
clearTimeout(waktu);
delete susunkata[m.chat];
} else if (!m.fromMe && m.text.includes('.nyerah')) {
ikann.sendMessage(m.chat, {react: {text: '🙂', key: m.key,}})
await ikann.sendMessage(m.chat, {text: `*KAMU MENYERAH*\nSoal: ${soal}\nJawaban: ${jawaban}`}, {quoted: m})
clearTimeout(waktu);
delete susunkata[m.chat];
} else if (!m.fromMe) {
ikann.sendMessage(m.chat, {react: {text: '🔴', key: m.key,}})}
}

if ((from in caklontong)) {
let { soal, jawaban, hadiah, waktu } = caklontong[m.chat]
if (body.toLowerCase().includes(jawaban) && !m.fromMe) {
await m.reply(`*JAWABAN BENAR*\nJawaban: ${jawaban}\nHadiah: 6 limit`);
addLimit(tagg, 6)
ikann.sendMessage(m.chat, {react: {text: '🔵', key: m.key}})
clearTimeout(waktu);
delete caklontong[m.chat];
} else if (!m.fromMe && m.text.includes('.nyerah')) {
ikann.sendMessage(m.chat, {react: {text: '🙂', key: m.key,}})
await ikann.sendMessage(m.chat, {text: `*KAMU MENYERAH*\nSoal: ${soal}\nJawaban: ${jawaban}`}, {quoted: m})
clearTimeout(waktu);
delete caklontong[m.chat];
} else if (!m.fromMe) {
ikann.sendMessage(m.chat, {react: {text: '🔴', key: m.key,}})}
}

if ((from in kuismath)) {
let { soal, jawaban, hadiah, waktu } = kuismath[m.chat]
if (body.toLowerCase().includes(jawaban) && !m.fromMe) {
await m.reply(`*JAWABAN BENAR*\nJawaban: ${jawaban}\nHadiah: 6 limit`);
addLimit(tagg, 6)
ikann.sendMessage(m.chat, {react: {text: '🔵', key: m.key}})
clearTimeout(waktu);
delete kuismath[m.chat];
} else if (!m.fromMe && m.text.includes('.nyerah')) {
ikann.sendMessage(m.chat, {react: {text: '🙂', key: m.key,}})
await ikann.sendMessage(m.chat, {text: `*KAMU MENYERAH*\nSoal: ${soal}\nJawaban: ${jawaban}`}, {quoted: m})
clearTimeout(waktu);
delete kuismath[m.chat];
} else if (!m.fromMe) {
ikann.sendMessage(m.chat, {react: {text: '🔴', key: m.key,}})}
}

const JwbTrue = (tebak, hadiah) => {
return`*🎮 ${tebak} 🎮*\n\nJawaban Benar! 🎉\n+ ${hadiah} Limit`
}
const waktuHabis = (jawaban) => {
return `*WAKTU HABIS!*\nJawaban: ${jawaban}`
}

if (tebakgame[m.chat] && !m.fromMe) {
let json = JSON.parse(JSON.stringify(tebakgame[m.chat][1]))
jawaban = json.jawaban.toLowerCase().trim()
if (body.toLowerCase() == jawaban && !m.fromMe) {
await addLimit(m.sender, tebakgame[m.chat][2]) 
await m.reply(JwbTrue("TEBAK GAME", tebakgame[m.chat][2]) + `\n\nKetik .tebakgame untuk bermain lagi...`)
clearTimeout(tebakgame[m.chat][3])
delete tebakgame[m.chat]
} else if (body.toLowerCase().includes('.nyerah', '. nyerah')) {
m.reply('Yahh, masa nyerah :)')
clearTimeout(tebakgame[m.chat][3])
delete tebakgame[m.chat]
} else if (!m.fromMe) {
ikann.sendMessage(m.chat, {react: { text: "🔴",key: m.key,}})
}}

function totalCase() {
  try {
    const script = fs.readFileSync('./ikann.js', 'utf-8')
    const jumlah = (script.match(/case ['"`](.+?)['"`]:/g) || []).length
    return jumlah
  } catch (e) {
    return 0
  }
}

function totalPlugin() {
  try {
    const pluginDir = path.join(__dirname, './plugin')
    const files = fs.readdirSync(pluginDir).filter(f => f.endsWith('.js'))

    let total = 0
    for (const file of files) {
      const plugin = require(path.join(pluginDir, file))
      const names = Array.isArray(plugin.name) ? plugin.name : [plugin.name]
      total += names.length
    }

    return total
  } catch (e) {
    return 0
  }
}
const totalFitur = totalPlugin() + totalCase()

const onlyOwn = () => {
m.reply(onlyOwn)
}
const onlyPrem = () => {
m.reply(mess.prem)
}
const onlyGrup = () => {
m.reply(mess.grup)
}
const onlyPrivat = () => {
m.reply(mess.privat)
}
const onlyAdmin = () => {
m.reply(mess.admin)
}
const onlyBotAdmin = () => {
m.reply(mess.botadmin)
}
const onlyNo = () => {
m.reply(mess.no)
}

const onlyOp = () => {
m.reply(mess.op)
}
const onlyOr = () => {
m.reply(mess.or)
}
const onlyOb = () => {
m.reply(mess.ob)
}
const onlyOa = () => {
m.reply(mess.oa)
}

const example = (teks) => {
return `Contoh: ${p_c} ${teks}`
}

async function gempa() {
try {
const response = await axios.get(`https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json`)
return response.data.Infogempa.gempa
} catch (error) {
console.error(error)
throw new Error('Gagal mengambil data gempa!')
}
}

async function autogempa() {
const data = await gempa()
const text = `🧭 *Info Gempa Terkini*
🕒 Waktu Gempa: ${data.Tanggal} ${data.Jam}
📍 Lokasi: ${data.Wilayah}
📌 Koordinat: ${data.Lintang} - ${data.Bujur}
🌋 Magnitudo: ${data.Magnitude} SR
⬇️ Kedalaman: ${data.Kedalaman}
⚠️ Potensi: ${data.Potensi}`

return text
}

const commandCooldowns = {
    'raul': 60,
    '1gb': 300,
    '2gb': 300,
    '3gb': 300,
    '5gb': 300,
    '6gb': 300,
    '7gb': 300,
    '8gb': 300,
    '9gb': 300,
    '10gb': 300,
    'unli': 300
};

async function handleGlobalCooldown(m, command, callback) {
    // Cek GLOBAL cooldown terlebih dahulu
    if (globalCooldowns.has(command)) {
        const expiresAt = globalCooldowns.get(command);
        const remainingTime = Math.ceil((expiresAt - Date.now()) / 1000);
        
        if (remainingTime > 0) {
            await m.reply(`📌 **GLOBAL COOLDOWN AKTIF!**\nCommand *${command}* baru bisa digunakan lagi dalam *${remainingTime} detik* oleh semua user`);
            return false;
        } else {
            globalCooldowns.delete(command);
        }
    }
    
    try {
        // Eksekusi callback function
        const result = await callback();
        
        // Jika berhasil, set GLOBAL cooldown
        globalCooldowns.set(command, Date.now() + commandCooldowns[command] * 1000);
        
        return true;
    } catch (error) {
        // Jika error terjadi, cooldown TIDAK diaktifkan
        globalCooldowns.delete(command);
        console.error('Command error:', error);
        await m.reply(`❌ Error: ${error.message}`);
        return false;
    }
}

async function backup() {
  const _id = require('crypto').randomBytes(9).toString('hex').toUpperCase();
  const __id = _id
  try {
    m.reply('Mengumpulkan semua file ke folder...')
    m.reply('Sukses backup script.');
    const {
      execSync
    } = require("child_process");
    const ls = (await execSync("ls")).toString().split("\n").filter((pe) =>
      pe != "node_modules" &&
      pe != "session" &&
      pe != "package-lock.json" &&
      pe != "yarn.lock" &&
      pe != "");
    const exec = await execSync(`zip -r Backup${__id}.zip ${ls.join(" ")}`);
    await ikann.sendMessage( m.isGroup ? owner + '@s.whatsapp.net' : from, {
      document: await fs.readFileSync(`./Backup${__id}.zip`),
      mimetype: "application/zip",
      fileName: `Backup${__id}.zip`,
    }, {
      quoted: m
    });
    await execSync(`rm -rf Backup${__id}.zip`);
  } catch (err) {
    m.reply('Terjadi kesalahan' + err)
  }
}

if (didyoumean && command) {
let c_names = getCaseNames()
const s_threshold = 0.6
function getCaseNames() {
try {
const data = fs.readFileSync('ikann.js', 'utf8')
const c_pattern = /case\s+'([^']+)'/g
const matches = data.match(c_pattern)
return matches ? matches.map(match => match.replace(/case\s+'([^']+)'/, '$1')) : []
} catch (err) {
return [] }}
function levenshtein(a, b) {
const m = a.length, n = b.length
if (m === 0) return n
if (n === 0) return m
let dp = Array.from({ length: m+1 }, () => Array(n+1).fill(0))
for (let i = 0; i <= m; i++) dp[i][0] = i
for (let j = 0; j <= n; j++) dp[0][j] = j
for (let i = 1; i <= m; i++) {
for (let j = 1; j <= n; j++) {
let cost = a[i - 1] === b[j - 1] ? 0 : 1
dp[i][j] = Math.min(dp[i - 1][j]+1, dp[i][j - 1]+1, dp[i - 1][j - 1]+cost) }}
return dp[m][n] }
function similarity(a, b) {
let m_length = Math.max(a.length, b.length)
if (m_length === 0) return 1
return (m_length - levenshtein(a, b)) / m_length }
let b_match = ''
let h_similarity = 0
for (const c_name of c_names) {
let sim = similarity(command.toLowerCase(), c_name.toLowerCase())
let lengthDiff = Math.abs(command.length - c_name.length)
if (sim > h_similarity && lengthDiff <= 1) {
h_similarity = sim
b_match = c_name }}
let s_percentage = parseInt(h_similarity * 100)
if (h_similarity >= s_threshold && command.toLowerCase() !== b_match.toLowerCase()) {
let response = `Maaf, command yang kamu berikan salah. Mungkin ini yang kamu maksud:\n\n•> ${prefix+b_match}\n•> Kemiripan: ${s_percentage}%`
const buttons = [
{
buttonId: `${prefix+b_match} ${text}`,
buttonText: { displayText: `${prefix+b_match}` },
type: 1
}
]
await ikann.sendMessage(m.chat, {
text: response,
footer: null,
buttons: buttons,
headerType: 1,
viewOnce: true
}, { quoted: m })
}}

const chFilePath = path.join(__dirname, 'data/ch.json')

function getChList() {
  try {
    if (!fs.existsSync(chFilePath)) return []
    const data = fs.readFileSync(chFilePath)
    return JSON.parse(data)
  } catch (err) {
    console.error('Gagal baca ch.json:', err)
    return []
  }
}

function updateChList(newArray) {
  try {
    fs.writeFileSync(chFilePath, JSON.stringify(newArray, null, 2))
    return true
  } catch (err) {
    console.error('Gagal tulis ch.json:', err)
    return false
  }
}

const getBuffer = (url, options) => {
	try {
		options ? options : {}
		const res = axios({
			method: "get",
			url,
			headers: {
				'DNT': 1,
				'Upgrade-Insecure-Request': 1
			},
			...options,
			responseType: 'arraybuffer'
		})
		return res.data
	} catch (err) {
		return err
	}
}
// ========== Function Grup ========== //
if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink === true) {
if (budy.match('chat.whatsapp|wa.me|whatsapp.com|t.me|http|www.')) {
if (!isBotAdmins) return !0
if (isAdmins) return !0
if (isOwner) return !0
await ikann.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant }})
await ikann.groupParticipantsUpdate(m.chat, [m.sender], 'delete')
}
}

if (global.db.groups?.[m.chat]?.welcome)

if ((m.mtype === "groupStatusMentionMessage" || m.message?.groupStatusMentionMessage) && m.isGroup && db.groups[m.chat] && db.groups[m.chat].antitagsw === true) {
if (!isBotAdmins) return
if (isAdmins || isOwner) return
await ikann.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.sender }})
}

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antitoxic === true) {
const budy = m.message.conversation || "";
const toxicWords = ['babi', 'ajg', 'anjing', 'mmk', 'mmek','memk','memek', 'kntl', 'kontl', 'kntol', 'puqi', 'puqimak', 'ppk', 'ppq', 'pepek', 'ppek', 'ppeq', 'jembud', 'jembut', 'jmbt', 'jmbd', 'jemboed', 'jemboet', 'jmbod', 'jmbud', 'jmbut', 'jmbot', 'bangsat', 'bangke', 'pantek', 'bgsat', 'bngsat', 'bgst', 'bgke', 'bngke', 'pntk', 'pntek', 'pantk', 'gblk', 'gblok', 'goblok', 'gblg', 'gblog', 'goblog', 'kintil', 'mimik', 'raimu', 'fefek', 'ngtd', 'ngntod', 'ngentd', 'ngentod', 'ngntt', 'ngntot', 'mgentt', 'ngentot', 'njing', 'jing', 'pussy', 'dick', 'stupid', 'dog', 'titit', 'titid', 'ttid', 'ttit', 'tytyd', 'tytyt', 'kontol', 'pepeq', 'koncol', 'ngentit', 'nying'];
const maxreplys = 5;
if (toxicWords.some(word => budy.toLowerCase().includes(word))) {
db.groups[m.chat].replys = db.groups[m.chat].replys || {};
db.groups[m.chat].replys[sender] = (db.groups[m.chat].replys[sender] || 0) + 1;
const replys = db.groups[m.chat].replys[sender];
await ikann.sendMessage(m.chat, { text: 
`📮 *Kata-Kata Toxic Terdeteksi*

- reply: ${replys}/${maxreplys}

*Jika reply mencapai ${maxreplys}, kamu akan dikeluarkan dari grup.*
`}, {quoted: m});
await ikann.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: sender } });
if (replys >= maxreplys) {
await ikann.sendMessage(m.chat, { text: 
`📮 *Kata-Kata Toxic Terdeteksi*

- reply: ${replys}/${maxreplys}

*Kamu kena kick karna sudah 5x berkata kasar!*`}, {quoted: m});
await ikann.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: sender } });
await ikann.groupParticipantsUpdate(m.chat, [sender], 'remove');
delete db.groups[m.chat].replys[sender];
}}
}

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].mute === true) {
if (!isAdmins && !isOwner) return
}

// ========== Function Bot ========== //
if (command && global.autoread) {
const readkey = { remoteJid: m.chat, id: m.key.id, participant: m.isGroup ? m.key.participant : undefined }
await ikann.readMessages([readkey]); }

// ========== Case Command ========== //
switch (command) {

case 'menu': {
let teks = `│ *‎${m2}</> I N F O - B O T </>${m2}*
╭────────────────────•
│  •  ʙᴏᴛ ɴᴀᴍᴇ : ɪᴋᴀɴɴ - ᴍᴅ
│  •  ᴠᴇʀꜱɪᴏɴ : 1.9
│️  •  ʙᴀɪʟᴇʏꜱ : ɪᴢᴜᴍɪ
│️  •  ᴏᴡɴᴇʀ : ɪᴋᴀɴɴ
╰────────────────────•
│ *‎${m2}</> I N F O - U S R </>${m2}*
╭──────────────────•
│  ◦  *ɴᴀᴍᴀ:* ${pushname || "anak haram"}
│  ◦  *ꜱᴛᴀᴛᴜꜱ:* ${isOwner ? 'ᴅᴇᴠᴇʟᴏᴘᴇʀ':'ᴜꜱᴇʀ'}
│  ◦  *ᴘʀᴇᴍɪᴜᴍ:* ${isPremium ? 'ʏᴇꜱ':'ɴᴏ'}
│  ◦  *ʟɪᴍɪᴛ:* ᴜɴʟɪᴍɪᴛᴇᴅ
╰──────────────────•
`

let bet = {
title: 'sᴇʟᴇᴄᴛ ᴛʜɪs ᴍᴇɴᴜ',
sections: [
{
title: `List menu yang sering dipakai`, 
highlight_label: `Populer`,
rows: [
{
title: "All Menu",
description: "Menampilkan All Menu",
id: `${_p}allmenu`, 
},
]},
{
title: `List menu yang dipisahkan`, 
highlight_label: ``,
rows: [
{
title: "Game Menu",
description: "Menampilkan Game Menu",
id: `${_p}gamemenu`, 
},
{
title: "Rpg Menu",
description: "Menampilkan Rpg Menu",
id: `${_p}rpgmenu`, 
},
{
title: "Main Menu",
description: "Menampilkan Main Menu",
id: `${_p}mainmenu`, 
},
{
title: "Search Menu",
description: "Menampilkan Search Menu",
id: `${_p}searchmenu`, 
},
{
title: "Grup Menu",
description: "Menampilkan Grup Menu",
id: `${_p}grupmenu`, 
},
{
title: "Download Menu",
description: "Menampilkan Download Menu",
id: `${_p}downloadmenu`, 
},
{
title: "Owner Menu",
description: "Menampilkan Owner Menu",
id: `${_p}onwermenu`, 
},
{
title: "Tools Menu",
description: "Menampilkan Tools Menu",
id: `${_p}toolsmenu`, 
},
{
title: "Ai Menu",
description: "Menampilkan Ai Menu",
id: `${_p}aimenu`, 
},
{
title: "Others Menu",
description: "Menampilkan Others Menu",
id: `${_p}othersmenu`, 
},
{
title: "Stalk Menu",
description: "Menampilkan Stalk Menu",
id: `${_p}stalkmenu`, 
},
{
title: "Cpanel Menu",
description: "Menampilkan Cpanel Menu",
id: `${_p}cpanelmenu`, 
},
{
title: "Buy Menu",
description: "Menampilkan Buy Menu",
id: `${_p}buymenu`, 
},
{
title: "Jpm Menu",
description: "Menampilkan Jpm Menu",
id: `${_p}jpmmenu`, 
},
]},
]
}

let msg = generateWAMessageFromContent(m.chat, {
viewOnceMessage: {
message: {
"messageContextInfo": {
"deviceListMetadata": {},
"deviceListMetadataVersion": 2
},
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: {
mentionedJid: [m.sender],
forwardingScore: 9999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterJid: global.chjid,
newsletterName: 'ɪᴋᴀɴɴɴᴇᴡ - ᴜᴘᴅᴀᴛᴇ',
serverMessageId: null,
},
businessMessageForwardInfo: {
businessOwnerJid: ikann.decodeJid(ikann.user.id)
},
externalAdReply: {
title: global.lengkap,
body: `Wʜᴀᴛᴀᴘᴘ - Bᴏᴛs ʙʏ ${ownername}`,
thumbnailUrl: thum169,
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}
},
body: proto.Message.InteractiveMessage.Body.create({
text: teks
}),
footer: proto.Message.InteractiveMessage.Footer.create({
text: ``
}),
header: proto.Message.InteractiveMessage.Header.create({
title: ``,
thumbnailUrl: thum169,
gifPlayback: true,
subtitle: "",
hasMediaAttachment: true,
...(await prepareWAMessageMedia({
document: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
mimetype: "image/png",
jpegThumbnail: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
fileLength: 0,
fileName: `ɪᴋᴀɴɴɴᴇᴡ`,
}, {
upload: ikann.waUploadToServer
}))
}),
gifPlayback: true,
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
buttons: [
{
"name": "single_select",
"buttonParamsJson": JSON.stringify(bet)
},
{
"name": "quick_reply",
"buttonParamsJson": `{\"display_text\":\"sᴄʀɪᴘᴛ\",\"id\":\"${_p}sc\"}`
},
{
"name": "cta_url",
"buttonParamsJson": `{"display_text":"ɪɴғᴏʀᴍᴀᴛɪᴏɴ","url":"https://whatsapp.com/channel/0029Vb6BnbsB4hdNFnu4gv3d","merchant_url":"https://www.google.com"}`
}
],
}), })}
}}, {quoted: m })
await delay(500);
await ikann.relayMessage(msg.key.remoteJid, msg.message, {
messageId: msg.key.id
})
}
break

case 'allmenu': {
let ptext = `╭────────────────────•
│ *‎${m2}</> I N F O - B O T </>${m2}*
╭────────────────────•
│  •  ʙᴏᴛ ɴᴀᴍᴇ : ɪᴋᴀɴɴ - ᴍᴅ
│  •  ᴠᴇʀꜱɪᴏɴ : 1.8
│️  •  ʙᴀɪʟᴇʏꜱ : ᴡʜɪꜱᴋᴇʏꜱᴏᴄᴋᴇᴛꜱ
│️  •  ᴏᴡɴᴇʀ : ɪᴋᴀɴɴ
╰────────────────────•
│ *‎${m2}</> I N F O - U S R </>${m2}*
╭──────────────────•
│  ◦  *ɴᴀᴍᴀ:* ${pushname || "anak haram"}
│  ◦  *ꜱᴛᴀᴛᴜꜱ:* ${isOwner ? 'ᴅᴇᴠᴇʟᴏᴘᴇʀ':'ᴜꜱᴇʀ'}
│  ◦  *ᴘʀᴇᴍɪᴜᴍ:* ${isPremium ? 'ʏᴇꜱ':'ɴᴏ'}
│  ◦  *ʟɪᴍɪᴛ:* ᴜɴʟɪᴍɪᴛᴇᴅ
╰──────────────────•

${gamemenu}

${rpgmenu}

${mainmenu}

${searchmenu}

${grupmenu}

${ownermenu}

${toolsmenu}

${aimenu}

${othersmenu}

${stalkmenu}

${cpanelmenu}

${buymenu}

${jpmmenu}
`

await ikann.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.menu`,
      buttonText: { displayText: 'Back to menu' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  document: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileName: `sepebw`,
  mimetype: "pdf",
  jpegThumbnail: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileLength: 0,
  caption: ptext,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.chjid + '@newsletter',
   newsletterName: global.namaSaluran
   },    
    externalAdReply: {
      title: `${botname} - ${versi}`,
      body: `King IkannNew`,
      thumbnailUrl: thum169,
      sourceUrl: linkSaluran,
      mediaType: 1,
    }
}}, { quoted: m })
await delay(1000);
}
break

case 'gamemenu': {
  let ptext = `╭────────────────────•
│ *‎${m2}</> I N F O - B O T </>${m2}*
╭────────────────────•
│  •  ʙᴏᴛ ɴᴀᴍᴇ : ɪᴋᴀɴɴ - ᴍᴅ
│  •  ᴠᴇʀꜱɪᴏɴ : 1.8
│️  •  ʙᴀɪʟᴇʏꜱ : ᴡʜɪꜱᴋᴇʏꜱᴏᴄᴋᴇᴛꜱ
│️  •  ᴏᴡɴᴇʀ : ɪᴋᴀɴɴ
╰────────────────────•
│ *‎${m2}</> I N F O - U S R </>${m2}*
╭──────────────────•
│  ◦  *ɴᴀᴍᴀ:* ${pushname || "anak haram"}
│  ◦  *ꜱᴛᴀᴛᴜꜱ:* ${isOwner ? 'ᴅᴇᴠᴇʟᴏᴘᴇʀ':'ᴜꜱᴇʀ'}
│  ◦  *ᴘʀᴇᴍɪᴜᴍ:* ${isPremium ? 'ʏᴇꜱ':'ɴᴏ'}
│  ◦  *ʟɪᴍɪᴛ:* ᴜɴʟɪᴍɪᴛᴇᴅ
╰──────────────────•

${gamemenu}
`
  await ikann.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.menu`,
      buttonText: { displayText: 'Back to menu' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  document: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileName: `sepebw`,
  mimetype: "pdf",
  jpegThumbnail: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileLength: 0,
  caption: ptext,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.chjid + '@newsletter',
   newsletterName: global.namaSaluran
   },    
    externalAdReply: {
      title: `${botname} - ${versi}`,
      body: `King IkannNew`,
      thumbnailUrl: thum169,
      sourceUrl: linkSaluran,
      mediaType: 1,
    }
}}, { quoted: m })
await delay(1000);
}
break

case 'rpgmenu': {
  let ptext = `╭────────────────────•
│ *‎${m2}</> I N F O - B O T </>${m2}*
╭────────────────────•
│  •  ʙᴏᴛ ɴᴀᴍᴇ : ɪᴋᴀɴɴ - ᴍᴅ
│  •  ᴠᴇʀꜱɪᴏɴ : 1.8
│️  •  ʙᴀɪʟᴇʏꜱ : ᴡʜɪꜱᴋᴇʏꜱᴏᴄᴋᴇᴛꜱ
│️  •  ᴏᴡɴᴇʀ : ɪᴋᴀɴɴ
╰────────────────────•
│ *‎${m2}</> I N F O - U S R </>${m2}*
╭──────────────────•
│  ◦  *ɴᴀᴍᴀ:* ${pushname || "anak haram"}
│  ◦  *ꜱᴛᴀᴛᴜꜱ:* ${isOwner ? 'ᴅᴇᴠᴇʟᴏᴘᴇʀ':'ᴜꜱᴇʀ'}
│  ◦  *ᴘʀᴇᴍɪᴜᴍ:* ${isPremium ? 'ʏᴇꜱ':'ɴᴏ'}
│  ◦  *ʟɪᴍɪᴛ:* ᴜɴʟɪᴍɪᴛᴇᴅ
╰──────────────────•

${rpgmenu}
`
  await ikann.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.menu`,
      buttonText: { displayText: 'Back to menu' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  document: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileName: `sepebw`,
  mimetype: "pdf",
  jpegThumbnail: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileLength: 0,
  caption: ptext,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.chjid + '@newsletter',
   newsletterName: global.namaSaluran
   },    
    externalAdReply: {
      title: `${botname} - ${versi}`,
      body: `King IkannNew`,
      thumbnailUrl: thum169,
      sourceUrl: linkSaluran,
      mediaType: 1,
    }
}}, { quoted: m })
await delay(1000);
}
break

case 'mainmenu': {
  let ptext = `╭────────────────────•
│ *‎${m2}</> I N F O - B O T </>${m2}*
╭────────────────────•
│  •  ʙᴏᴛ ɴᴀᴍᴇ : ɪᴋᴀɴɴ - ᴍᴅ
│  •  ᴠᴇʀꜱɪᴏɴ : 1.8
│️  •  ʙᴀɪʟᴇʏꜱ : ᴡʜɪꜱᴋᴇʏꜱᴏᴄᴋᴇᴛꜱ
│️  •  ᴏᴡɴᴇʀ : ɪᴋᴀɴɴ
╰────────────────────•
│ *‎${m2}</> I N F O - U S R </>${m2}*
╭──────────────────•
│  ◦  *ɴᴀᴍᴀ:* ${pushname || "anak haram"}
│  ◦  *ꜱᴛᴀᴛᴜꜱ:* ${isOwner ? 'ᴅᴇᴠᴇʟᴏᴘᴇʀ':'ᴜꜱᴇʀ'}
│  ◦  *ᴘʀᴇᴍɪᴜᴍ:* ${isPremium ? 'ʏᴇꜱ':'ɴᴏ'}
│  ◦  *ʟɪᴍɪᴛ:* ᴜɴʟɪᴍɪᴛᴇᴅ
╰──────────────────•

${mainmenu}
`
  await ikann.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.menu`,
      buttonText: { displayText: 'Back to menu' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  document: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileName: `sepebw`,
  mimetype: "pdf",
  jpegThumbnail: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileLength: 0,
  caption: ptext,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.chjid + '@newsletter',
   newsletterName: global.namaSaluran
   },    
    externalAdReply: {
      title: `${botname} - ${versi}`,
      body: `King IkannNew`,
      thumbnailUrl: thum169,
      sourceUrl: linkSaluran,
      mediaType: 1,
    }
}}, { quoted: m })
await delay(1000);
}
break

case 'searchmenu': {
  let ptext = `╭────────────────────•
│ *‎${m2}</> I N F O - B O T </>${m2}*
╭────────────────────•
│  •  ʙᴏᴛ ɴᴀᴍᴇ : ɪᴋᴀɴɴ - ᴍᴅ
│  •  ᴠᴇʀꜱɪᴏɴ : 1.8
│️  •  ʙᴀɪʟᴇʏꜱ : ᴡʜɪꜱᴋᴇʏꜱᴏᴄᴋᴇᴛꜱ
│️  •  ᴏᴡɴᴇʀ : ɪᴋᴀɴɴ
╰────────────────────•
│ *‎${m2}</> I N F O - U S R </>${m2}*
╭──────────────────•
│  ◦  *ɴᴀᴍᴀ:* ${pushname || "anak haram"}
│  ◦  *ꜱᴛᴀᴛᴜꜱ:* ${isOwner ? 'ᴅᴇᴠᴇʟᴏᴘᴇʀ':'ᴜꜱᴇʀ'}
│  ◦  *ᴘʀᴇᴍɪᴜᴍ:* ${isPremium ? 'ʏᴇꜱ':'ɴᴏ'}
│  ◦  *ʟɪᴍɪᴛ:* ᴜɴʟɪᴍɪᴛᴇᴅ
╰──────────────────•

${searchmenu}
`
  await ikann.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.menu`,
      buttonText: { displayText: 'Back to menu' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  document: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileName: `sepebw`,
  mimetype: "pdf",
  jpegThumbnail: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileLength: 0,
  caption: ptext,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.chjid + '@newsletter',
   newsletterName: global.namaSaluran
   },    
    externalAdReply: {
      title: `${botname} - ${versi}`,
      body: `King IkannNew`,
      thumbnailUrl: thum169,
      sourceUrl: linkSaluran,
      mediaType: 1,
    }
}}, { quoted: m })
await delay(1000);
}
break

case 'grupmenu': {
  let ptext = `╭────────────────────•
│ *‎${m2}</> I N F O - B O T </>${m2}*
╭────────────────────•
│  •  ʙᴏᴛ ɴᴀᴍᴇ : ɪᴋᴀɴɴ - ᴍᴅ
│  •  ᴠᴇʀꜱɪᴏɴ : 1.8
│️  •  ʙᴀɪʟᴇʏꜱ : ᴡʜɪꜱᴋᴇʏꜱᴏᴄᴋᴇᴛꜱ
│️  •  ᴏᴡɴᴇʀ : ɪᴋᴀɴɴ
╰────────────────────•
│ *‎${m2}</> I N F O - U S R </>${m2}*
╭──────────────────•
│  ◦  *ɴᴀᴍᴀ:* ${pushname || "anak haram"}
│  ◦  *ꜱᴛᴀᴛᴜꜱ:* ${isOwner ? 'ᴅᴇᴠᴇʟᴏᴘᴇʀ':'ᴜꜱᴇʀ'}
│  ◦  *ᴘʀᴇᴍɪᴜᴍ:* ${isPremium ? 'ʏᴇꜱ':'ɴᴏ'}
│  ◦  *ʟɪᴍɪᴛ:* ᴜɴʟɪᴍɪᴛᴇᴅ
╰──────────────────•

${grupmenu}
`
  await ikann.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.menu`,
      buttonText: { displayText: 'Back to menu' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  document: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileName: `sepebw`,
  mimetype: "pdf",
  jpegThumbnail: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileLength: 0,
  caption: ptext,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.chjid + '@newsletter',
   newsletterName: global.namaSaluran
   },    
    externalAdReply: {
      title: `${botname} - ${versi}`,
      body: `King IkannNew`,
      thumbnailUrl: thum169,
      sourceUrl: linkSaluran,
      mediaType: 1,
    }
}}, { quoted: m })
await delay(1000);
}
break

case 'downloadmenu': {
  let ptext = `╭────────────────────•
│ *‎${m2}</> I N F O - B O T </>${m2}*
╭────────────────────•
│  •  ʙᴏᴛ ɴᴀᴍᴇ : ɪᴋᴀɴɴ - ᴍᴅ
│  •  ᴠᴇʀꜱɪᴏɴ : 1.8
│️  •  ʙᴀɪʟᴇʏꜱ : ᴡʜɪꜱᴋᴇʏꜱᴏᴄᴋᴇᴛꜱ
│️  •  ᴏᴡɴᴇʀ : ɪᴋᴀɴɴ
╰────────────────────•
│ *‎${m2}</> I N F O - U S R </>${m2}*
╭──────────────────•
│  ◦  *ɴᴀᴍᴀ:* ${pushname || "anak haram"}
│  ◦  *ꜱᴛᴀᴛᴜꜱ:* ${isOwner ? 'ᴅᴇᴠᴇʟᴏᴘᴇʀ':'ᴜꜱᴇʀ'}
│  ◦  *ᴘʀᴇᴍɪᴜᴍ:* ${isPremium ? 'ʏᴇꜱ':'ɴᴏ'}
│  ◦  *ʟɪᴍɪᴛ:* ᴜɴʟɪᴍɪᴛᴇᴅ
╰──────────────────•

${downloadmenu}
`
  await ikann.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.menu`,
      buttonText: { displayText: 'Back to menu' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  document: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileName: `sepebw`,
  mimetype: "pdf",
  jpegThumbnail: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileLength: 0,
  caption: ptext,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.chjid + '@newsletter',
   newsletterName: global.namaSaluran
   },    
    externalAdReply: {
      title: `${botname} - ${versi}`,
      body: `King IkannNew`,
      thumbnailUrl: thum169,
      sourceUrl: linkSaluran,
      mediaType: 1,
    }
}}, { quoted: m })
await delay(1000);
}
break

case 'ownermenu': {
  let ptext = `╭────────────────────•
│ *‎${m2}</> I N F O - B O T </>${m2}*
╭────────────────────•
│  •  ʙᴏᴛ ɴᴀᴍᴇ : ɪᴋᴀɴɴ - ᴍᴅ
│  •  ᴠᴇʀꜱɪᴏɴ : 1.8
│️  •  ʙᴀɪʟᴇʏꜱ : ᴡʜɪꜱᴋᴇʏꜱᴏᴄᴋᴇᴛꜱ
│️  •  ᴏᴡɴᴇʀ : ɪᴋᴀɴɴ
╰────────────────────•
│ *‎${m2}</> I N F O - U S R </>${m2}*
╭──────────────────•
│  ◦  *ɴᴀᴍᴀ:* ${pushname || "anak haram"}
│  ◦  *ꜱᴛᴀᴛᴜꜱ:* ${isOwner ? 'ᴅᴇᴠᴇʟᴏᴘᴇʀ':'ᴜꜱᴇʀ'}
│  ◦  *ᴘʀᴇᴍɪᴜᴍ:* ${isPremium ? 'ʏᴇꜱ':'ɴᴏ'}
│  ◦  *ʟɪᴍɪᴛ:* ᴜɴʟɪᴍɪᴛᴇᴅ
╰──────────────────•

${ownermenu}
`
  await ikann.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.menu`,
      buttonText: { displayText: 'Back to menu' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  document: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileName: `sepebw`,
  mimetype: "pdf",
  jpegThumbnail: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileLength: 0,
  caption: ptext,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.chjid + '@newsletter',
   newsletterName: global.namaSaluran
   },    
    externalAdReply: {
      title: `${botname} - ${versi}`,
      body: `King IkannNew`,
      thumbnailUrl: thum169,
      sourceUrl: linkSaluran,
      mediaType: 1,
    }
}}, { quoted: m })
await delay(1000);
}
break

case 'toolsmenu': {
  let ptext = `╭────────────────────•
│ *‎${m2}</> I N F O - B O T </>${m2}*
╭────────────────────•
│  •  ʙᴏᴛ ɴᴀᴍᴇ : ɪᴋᴀɴɴ - ᴍᴅ
│  •  ᴠᴇʀꜱɪᴏɴ : 1.8
│️  •  ʙᴀɪʟᴇʏꜱ : ᴡʜɪꜱᴋᴇʏꜱᴏᴄᴋᴇᴛꜱ
│️  •  ᴏᴡɴᴇʀ : ɪᴋᴀɴɴ
╰────────────────────•
│ *‎${m2}</> I N F O - U S R </>${m2}*
╭──────────────────•
│  ◦  *ɴᴀᴍᴀ:* ${pushname || "anak haram"}
│  ◦  *ꜱᴛᴀᴛᴜꜱ:* ${isOwner ? 'ᴅᴇᴠᴇʟᴏᴘᴇʀ':'ᴜꜱᴇʀ'}
│  ◦  *ᴘʀᴇᴍɪᴜᴍ:* ${isPremium ? 'ʏᴇꜱ':'ɴᴏ'}
│  ◦  *ʟɪᴍɪᴛ:* ᴜɴʟɪᴍɪᴛᴇᴅ
╰──────────────────•

${toolsmenu}
`
  await ikann.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.menu`,
      buttonText: { displayText: 'Back to menu' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  document: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileName: `sepebw`,
  mimetype: "pdf",
  jpegThumbnail: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileLength: 0,
  caption: ptext,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.chjid + '@newsletter',
   newsletterName: global.namaSaluran
   },    
    externalAdReply: {
      title: `${botname} - ${versi}`,
      body: `King IkannNew`,
      thumbnailUrl: thum169,
      sourceUrl: linkSaluran,
      mediaType: 1,
    }
}}, { quoted: m })
await delay(1000);
}
break

case 'aimenu': {
  let ptext = `╭────────────────────•
│ *‎${m2}</> I N F O - B O T </>${m2}*
╭────────────────────•
│  •  ʙᴏᴛ ɴᴀᴍᴇ : ɪᴋᴀɴɴ - ᴍᴅ
│  •  ᴠᴇʀꜱɪᴏɴ : 1.8
│️  •  ʙᴀɪʟᴇʏꜱ : ᴡʜɪꜱᴋᴇʏꜱᴏᴄᴋᴇᴛꜱ
│️  •  ᴏᴡɴᴇʀ : ɪᴋᴀɴɴ
╰────────────────────•
│ *‎${m2}</> I N F O - U S R </>${m2}*
╭──────────────────•
│  ◦  *ɴᴀᴍᴀ:* ${pushname || "anak haram"}
│  ◦  *ꜱᴛᴀᴛᴜꜱ:* ${isOwner ? 'ᴅᴇᴠᴇʟᴏᴘᴇʀ':'ᴜꜱᴇʀ'}
│  ◦  *ᴘʀᴇᴍɪᴜᴍ:* ${isPremium ? 'ʏᴇꜱ':'ɴᴏ'}
│  ◦  *ʟɪᴍɪᴛ:* ᴜɴʟɪᴍɪᴛᴇᴅ
╰──────────────────•

${aimenu}
`
  await ikann.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.menu`,
      buttonText: { displayText: 'Back to menu' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  document: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileName: `sepebw`,
  mimetype: "pdf",
  jpegThumbnail: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileLength: 0,
  caption: ptext,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.chjid + '@newsletter',
   newsletterName: global.namaSaluran
   },    
    externalAdReply: {
      title: `${botname} - ${versi}`,
      body: `King IkannNew`,
      thumbnailUrl: thum169,
      sourceUrl: linkSaluran,
      mediaType: 1,
    }
}}, { quoted: m })
await delay(1000);
}
break

case 'othersmenu': {
  let ptext = `╭────────────────────•
│ *‎${m2}</> I N F O - B O T </>${m2}*
╭────────────────────•
│  •  ʙᴏᴛ ɴᴀᴍᴇ : ɪᴋᴀɴɴ - ᴍᴅ
│  •  ᴠᴇʀꜱɪᴏɴ : 1.8
│️  •  ʙᴀɪʟᴇʏꜱ : ᴡʜɪꜱᴋᴇʏꜱᴏᴄᴋᴇᴛꜱ
│️  •  ᴏᴡɴᴇʀ : ɪᴋᴀɴɴ
╰────────────────────•
│ *‎${m2}</> I N F O - U S R </>${m2}*
╭──────────────────•
│  ◦  *ɴᴀᴍᴀ:* ${pushname || "anak haram"}
│  ◦  *ꜱᴛᴀᴛᴜꜱ:* ${isOwner ? 'ᴅᴇᴠᴇʟᴏᴘᴇʀ':'ᴜꜱᴇʀ'}
│  ◦  *ᴘʀᴇᴍɪᴜᴍ:* ${isPremium ? 'ʏᴇꜱ':'ɴᴏ'}
│  ◦  *ʟɪᴍɪᴛ:* ᴜɴʟɪᴍɪᴛᴇᴅ
╰──────────────────•

${othersmenu}
`
  await ikann.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.menu`,
      buttonText: { displayText: 'Back to menu' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  document: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileName: `sepebw`,
  mimetype: "pdf",
  jpegThumbnail: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileLength: 0,
  caption: ptext,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.chjid + '@newsletter',
   newsletterName: global.namaSaluran
   },    
    externalAdReply: {
      title: `${botname} - ${versi}`,
      body: `King IkannNew`,
      thumbnailUrl: thum169,
      sourceUrl: linkSaluran,
      mediaType: 1,
    }
}}, { quoted: m })
await delay(1000);
}
break

case 'stalkmenu': {
  let ptext = `╭────────────────────•
│ *‎${m2}</> I N F O - B O T </>${m2}*
╭────────────────────•
│  •  ʙᴏᴛ ɴᴀᴍᴇ : ɪᴋᴀɴɴ - ᴍᴅ
│  •  ᴠᴇʀꜱɪᴏɴ : 1.8
│️  •  ʙᴀɪʟᴇʏꜱ : ᴡʜɪꜱᴋᴇʏꜱᴏᴄᴋᴇᴛꜱ
│️  •  ᴏᴡɴᴇʀ : ɪᴋᴀɴɴ
╰────────────────────•
│ *‎${m2}</> I N F O - U S R </>${m2}*
╭──────────────────•
│  ◦  *ɴᴀᴍᴀ:* ${pushname || "anak haram"}
│  ◦  *ꜱᴛᴀᴛᴜꜱ:* ${isOwner ? 'ᴅᴇᴠᴇʟᴏᴘᴇʀ':'ᴜꜱᴇʀ'}
│  ◦  *ᴘʀᴇᴍɪᴜᴍ:* ${isPremium ? 'ʏᴇꜱ':'ɴᴏ'}
│  ◦  *ʟɪᴍɪᴛ:* ᴜɴʟɪᴍɪᴛᴇᴅ
╰──────────────────•

${stalkmenu}
`
await ikann.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.menu`,
      buttonText: { displayText: 'Back to menu' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  document: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileName: `sepebw`,
  mimetype: "pdf",
  jpegThumbnail: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileLength: 0,
  caption: ptext,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.chjid + '@newsletter',
   newsletterName: global.namaSaluran
   },    
    externalAdReply: {
      title: `${botname} - ${versi}`,
      body: `King IkannNew`,
      thumbnailUrl: thum169,
      sourceUrl: linkSaluran,
      mediaType: 1,
    }
}}, { quoted: m })
await delay(1000);
}
break

case 'cpanelmenu': {
  let ptext = `╭────────────────────•
│ *‎${m2}</> I N F O - B O T </>${m2}*
╭────────────────────•
│  •  ʙᴏᴛ ɴᴀᴍᴇ : ɪᴋᴀɴɴ - ᴍᴅ
│  •  ᴠᴇʀꜱɪᴏɴ : 1.8
│️  •  ʙᴀɪʟᴇʏꜱ : ᴡʜɪꜱᴋᴇʏꜱᴏᴄᴋᴇᴛꜱ
│️  •  ᴏᴡɴᴇʀ : ɪᴋᴀɴɴ
╰────────────────────•
│ *‎${m2}</> I N F O - U S R </>${m2}*
╭──────────────────•
│  ◦  *ɴᴀᴍᴀ:* ${pushname || "anak haram"}
│  ◦  *ꜱᴛᴀᴛᴜꜱ:* ${isOwner ? 'ᴅᴇᴠᴇʟᴏᴘᴇʀ':'ᴜꜱᴇʀ'}
│  ◦  *ᴘʀᴇᴍɪᴜᴍ:* ${isPremium ? 'ʏᴇꜱ':'ɴᴏ'}
│  ◦  *ʟɪᴍɪᴛ:* ᴜɴʟɪᴍɪᴛᴇᴅ
╰──────────────────•

${cpanelmenu}
`
  await ikann.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.menu`,
      buttonText: { displayText: 'Back to menu' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  document: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileName: `sepebw`,
  mimetype: "pdf",
  jpegThumbnail: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileLength: 0,
  caption: ptext,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.chjid + '@newsletter',
   newsletterName: global.namaSaluran
   },    
    externalAdReply: {
      title: `${botname} - ${versi}`,
      body: `King IkannNew`,
      thumbnailUrl: thum169,
      sourceUrl: linkSaluran,
      mediaType: 1,
    }
}}, { quoted: m })
await delay(1000);
}
break

case 'buymenu': {
  let ptext = `╭────────────────────•
│ *‎${m2}</> I N F O - B O T </>${m2}*
╭────────────────────•
│  •  ʙᴏᴛ ɴᴀᴍᴇ : ɪᴋᴀɴɴ - ᴍᴅ
│  •  ᴠᴇʀꜱɪᴏɴ : 1.8
│️  •  ʙᴀɪʟᴇʏꜱ : ᴡʜɪꜱᴋᴇʏꜱᴏᴄᴋᴇᴛꜱ
│️  •  ᴏᴡɴᴇʀ : ɪᴋᴀɴɴ
╰────────────────────•
│ *‎${m2}</> I N F O - U S R </>${m2}*
╭──────────────────•
│  ◦  *ɴᴀᴍᴀ:* ${pushname || "anak haram"}
│  ◦  *ꜱᴛᴀᴛᴜꜱ:* ${isOwner ? 'ᴅᴇᴠᴇʟᴏᴘᴇʀ':'ᴜꜱᴇʀ'}
│  ◦  *ᴘʀᴇᴍɪᴜᴍ:* ${isPremium ? 'ʏᴇꜱ':'ɴᴏ'}
│  ◦  *ʟɪᴍɪᴛ:* ᴜɴʟɪᴍɪᴛᴇᴅ
╰──────────────────•

${buymenu}
`
  await ikann.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.menu`,
      buttonText: { displayText: 'Back to menu' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  document: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileName: `sepebw`,
  mimetype: "pdf",
  jpegThumbnail: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileLength: 0,
  caption: ptext,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.chjid + '@newsletter',
   newsletterName: global.namaSaluran
   },    
    externalAdReply: {
      title: `${botname} - ${versi}`,
      body: `King IkannNew`,
      thumbnailUrl: thum169,
      sourceUrl: linkSaluran,
      mediaType: 1,
    }
}}, { quoted: m })
await delay(1000);
}
break

case 'jpmmenu': {
  let ptext = `╭────────────────────•
│ *‎${m2}</> I N F O - B O T </>${m2}*
╭────────────────────•
│  •  ʙᴏᴛ ɴᴀᴍᴇ : ɪᴋᴀɴɴ - ᴍᴅ
│  •  ᴠᴇʀꜱɪᴏɴ : 1.8
│️  •  ʙᴀɪʟᴇʏꜱ : ᴡʜɪꜱᴋᴇʏꜱᴏᴄᴋᴇᴛꜱ
│️  •  ᴏᴡɴᴇʀ : ɪᴋᴀɴɴ
╰────────────────────•
│ *‎${m2}</> I N F O - U S R </>${m2}*
╭──────────────────•
│  ◦  *ɴᴀᴍᴀ:* ${pushname || "anak haram"}
│  ◦  *ꜱᴛᴀᴛᴜꜱ:* ${isOwner ? 'ᴅᴇᴠᴇʟᴏᴘᴇʀ':'ᴜꜱᴇʀ'}
│  ◦  *ᴘʀᴇᴍɪᴜᴍ:* ${isPremium ? 'ʏᴇꜱ':'ɴᴏ'}
│  ◦  *ʟɪᴍɪᴛ:* ᴜɴʟɪᴍɪᴛᴇᴅ
╰──────────────────•

${jpmmenu}
`
  await ikann.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.menu`,
      buttonText: { displayText: 'Back to menu' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  document: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileName: `sepebw`,
  mimetype: "pdf",
  jpegThumbnail: fs.readFileSync('./lib/thumbnail/thumbnail169.jpg'),
  fileLength: 0,
  caption: ptext,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.chjid + '@newsletter',
   newsletterName: global.namaSaluran
   },    
    externalAdReply: {
      title: `${botname} - ${versi}`,
      body: `King IkannNew`,
      thumbnailUrl: thum169,
      sourceUrl: linkSaluran,
      mediaType: 1,
    }
}}, { quoted: m })
await delay(1000);
}
break

// ==== Game Menu
case 'akinator': {
    if (!isPremium) return onlyPrem();
    ikann.akinator = ikann.akinator ? ikann.akinator : {};
    let room = ikann.akinator;
    let subcmd = args[0]?.toLowerCase();

    switch (subcmd) {
        case 'start': {
            if (m.sender in room) return m.reply('Kamu masih ada di sesi Akinator.');
            
            try {
                const { Aki } = require('aki-api');
                room[m.sender] = new Aki({
                    region: 'id',
                    childMode: false,
                    proxy: undefined,
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
                    }
                });
                
                await room[m.sender].start();
                let { question } = room[m.sender];
                
                let teks = `🎮 *Akinator Game* 🎮\n\n@${m.sender.split('@')[0]}\n${question}\n\n`;
                teks += `Jawab dengan:\n`;
                teks += `• 0 = Ya\n• 1 = Tidak\n• 2 = Tidak Tahu\n• 3 = Mungkin\n• 4 = Mungkin Tidak\n\n`;
                teks += `Contoh: .akinator answer 0\n`;
                teks += `Ketik *.akinator end* untuk keluar`;
                
                room[m.sender].chat = await m.reply(teks, null, { mentions: [m.sender] });
                
                room[m.sender].waktu = setTimeout(() => {
                    m.reply(`⏱️ Waktu habis! Sesi Akinator telah dihapus.`);
                    delete ikann.akinator[m.sender];
                }, 60000);
                
            } catch (error) {
                console.error('Akinator error:', error);
                delete room[m.sender];
                m.reply('❌ Gagal memulai sesi Akinator. Silakan coba lagi nanti.');
            }
            break;
        }

        case 'answer': {
            if (!(m.sender in room)) return m.reply('Kamu belum memulai sesi Akinator.');
            if (!args[1]) return m.reply('Masukkan jawaban kamu! (0-4)');
            if (!/^[0-4]$/.test(args[1])) return m.reply('Jawaban hanya berupa angka 0 sampai 4');

            try {
                clearTimeout(room[m.sender].waktu);
                await room[m.sender].step(parseInt(args[1]));

                let { question: q, currentStep, progress, guess } = room[m.sender];
                
                if (guess?.completion === 'OK') {
                    let teks = `🎮 *Akinator Tebakan*\n\n`;
                    teks += `Aku yakin ini adalah *${guess.name_proposition}*\n`;
                    teks += `Deskripsi: ${guess.description_proposition}\n\n`;
                    teks += `Akurasi: ${Math.round(guess.proba * 100)}%`;
                    
                    try {
                        await ikann.sendMessage(m.chat, {
                            image: { url: guess.photo },
                            caption: teks,
                            mentions: [m.sender]
                        }, { quoted: m });
                    } catch (e) {
                        await m.reply(teks);
                    }
                    
                    delete room[m.sender];
                } else {
                    let teks = `🎮 *Akinator* 🎮\n\n@${m.sender.split('@')[0]}\n`;
                    teks += `_Step ${currentStep} (${progress.toFixed(2)}%)_\n\n`;
                    teks += `${q}\n\n`;
                    teks += `• 0 = Ya\n• 1 = Tidak\n• 2 = Tidak Tahu\n• 3 = Mungkin\n• 4 = Mungkin Tidak`;
                    
                    room[m.sender].chat = await m.reply(teks, null, { mentions: [m.sender] });
                    
                    room[m.sender].waktu = setTimeout(() => {
                        m.reply(`⏱️ Waktu habis! Sesi Akinator dihapus.`);
                        delete room[m.sender];
                    }, 60000);
                }
            } catch (error) {
                console.error('Akinator error:', error);
                delete room[m.sender];
                m.reply('❌ Terjadi kesalahan saat memproses jawaban. Sesi direset.');
            }
            break;
        }

        case 'end': {
            if (!(m.sender in room)) return m.reply('Kamu tidak sedang dalam sesi Akinator.');
            clearTimeout(room[m.sender].waktu);
            delete ikann.akinator[m.sender];
            m.reply('✅ Sesi Akinator dihentikan.');
            break;
        }

        default: {
            let helpText = `📌 *Akinator Game*\n\n`;
            helpText += `Perintah:\n`;
            helpText += `• *.akinator start* - Mulai permainan baru\n`;
            helpText += `• *.akinator answer [0-4]* - Jawab pertanyaan\n`;
            helpText += `• *.akinator end* - Akhiri permainan\n\n`;
            helpText += `Panduan Jawaban:\n`;
            helpText += `0 = Ya\n1 = Tidak\n2 = Tidak Tahu\n3 = Mungkin\n4 = Mungkin Tidak`;
            
            m.reply(helpText);
            break;
        }
    }
    break;
}

case 'family100':
case 'f100': {
  var {
    soal,
    jawaban
  } = pickRandom(JSON.parse(fs.readFileSync('./lib/game/family100.json')));
  console.log('Jawaban: ' + jawaban)
  let famil = []
  for (let i of jawaban) {
    let fefsh = i.split('/') ? i.split('/')[0] : i
    let iuhbs = fefsh.startsWith(' ') ? fefsh.replace(' ', '') : fefsh
    let axsfh = iuhbs.endsWith(' ') ? iuhbs.replace(iuhbs.slice(-1), '') : iuhbs
    famil.push(axsfh.toLowerCase())
  }
  await m.reply(`*GAME FAMILY 100*\n\nSoal: ${soal}\nTotal jawaban: ${jawaban.length}\n\nWaktu: ${gamewaktu} detik`)
  family100[from] = {
    soal: soal,
    jawaban: famil,
    hadiah: randomNomor(10, 20),
    waktu: setTimeout(async function () {
      let jwb = family100[from].jawaban
      if (from in family100) {
let teks = `*WAKTU HABIS!*\nJawaban yang belum terjawab:\n`
for (let i of jwb) {
  teks += `\n${i}`
}
m.reply(teks)
delete family100[from];
      };
    }, gamewaktu * 1000)
  }
}
break

case 'suit':
case 'suitpvp': {
  if (Object.values(suit).find(roof => roof.id.startsWith('suit') && [roof.p, roof.p2].includes(m.sender))) return m.reply(`Selesaikan suit mu yang sebelumnya!`)
  gue = `0@s.whatsapp.net`
  if (!froms) return m.reply(`Siapa yang ingin kamu tantang?\n\nContoh: ${prefix+command} @${gue.split('@')[0]}`)
  if (froms === botNumber) return m.reply(`Tidak bisa bermain dengan bot!`)
  if (Object.values(suit).find(roof => roof.id.startsWith('suit') && [roof.p, roof.p2].includes(froms))) return m.reply(`Orang nya lagi main sama yang lain!`)
  var hadiah = randomNomor(10, 20)
  let poin = 10
  let poin_lose = 10
  let timeout = 60000
  let id = 'suit_' + new Date() * 1
  suit[id] = {
    chat: await ikann.sendTeks(from, `@${m.sender.split('@')[0]} menantang @${froms.split('@')[0]} untuk bermain suit\n\nKirim *gas/gak* untuk bermain`, m),
    id: id,
    p: m.sender,
    p2: froms,
    status: 'Wait',
    hadiah: hadiah,
    waktu: setTimeout(() => {
      if (suit[id]) ikann.sendMessage(from, {
text: `Waktu suit habis!`
      }, {
quoted: m
      })
      delete suit[id]
    }, 60000),
    poin,
    poin_lose,
    timeout
  }
}
break

case 'ttt':
case 'ttc':
case 'tictactoe': {
  if (!m.isGroup) return onlyGrup()
  let TicTacToe = require("./lib/game/tictactoe")
  this.game = this.game ? this.game : {}
  if (Object.values(this.game).find(room => room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender))) return m.reply('Kamu masih didalam game!')
  let room = Object.values(this.game).find(room => room.state === 'WAITING' && (text ? room.name === text : true))
  if (room) {
    m.reply('Lawan bermain ditemukan!')
    room.o = m.chat
    room.game.playerO = m.sender
    room.state = 'PLAYING'
    let arr = room.game.render().map(v => {
      return {
X: '❌',
O: '⭕',
1: '1️⃣',
2: '2️⃣',
3: '3️⃣',
4: '4️⃣',
5: '5️⃣',
6: '6️⃣',
7: '7️⃣',
8: '8️⃣',
9: '9️⃣',
      } [v]
    })
    let str = `Room ID: ${room.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

Menunggu @${room.game.currentTurn.split('@')[0]}

Ketik .nyerah untuk menyerah`
    if (room.x !== room.o) await ikann.sendText(room.x, str, m, {
      mentions: parseMention(str)
    })
    await ikann.sendText(room.o, str, m, {
      mentions: parseMention(str)
    })
  } else {
    room = {
      id: 'tictactoe-' + (+new Date),
      x: m.chat,
      o: '',
      game: new TicTacToe(m.sender, 'o'),
      state: 'WAITING'
    }
    if (text) room.name = text
    m.reply('Menunggu lawan bermain' + (text ? ` mengetik command dibawah ini ${prefix+command} ${text}` : ''))
    this.game[room.id] = room
  }
}
break

case 'delttt':
case 'delttc':
case 'deltictactoe': {
  let roomnya = Object.values(this.game).find(room => room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender))
  if (!roomnya) return m.reply(`Kamu sedang tidak bermain tictactoe!`)
  delete this.game[roomnya.id]
  m.reply(`Game tictactoe telah diakhiri!`)
}
break

case 'tebakbom':
case 'petakbom': {
  if (petakbom[m.sender]) return m.reply(`Sesi game mu belum terselesaikan, lanjutkan:\n\n${petakbom[sender].board.join("")}\n\nKetik ${_p}delpetakbom untuk menghapus sesi game`);

  function shuffle(array) {
    return array.sort(() => Math.random() - 0.5);
  }
  petakbom[m.sender] = {
    petak: shuffle([0, 0, 0, 2, 0, 2, 0, 2, 0]),
    board: ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣"],
    bomb: 3,
    lolos: 6,
    pick: 0,
    hadiah: randomNomor(5000, 10000),
    nyawa: ["❤️", "❤️", "❤️"]
  };
  await m.reply(`*PETAK BOM*

${petakbom[m.sender].board.slice(0, 3).join("")}
${petakbom[m.sender].board.slice(3, 6).join("")}
${petakbom[m.sender].board.slice(6).join("")}

Pillih angka diatas tetapi berhati-hati
lah, karena ada bom!

Bomb: ${petakbom[m.sender].bomb}
Nyawa: ${petakbom[m.sender].nyawa.join("")}`);
}
break

case 'delpetakbom': {
  if (!(m.sender in petakbom)) return m.reply(`Kamu sedang tidak bermain petakbom!`)
  delete petakbom[m.sender];
  m.reply(`Game petakbom telah diakhiri!`)
}
break

case 'tebakgambar': {
  if (from in tebakgambar) return m.reply('Masih ada sesi yang belum diselesaikan!');
  var {
    img,
    jawaban,
    deskripsi
  } = pickRandom(JSON.parse(fs.readFileSync('./lib/game/tebakgambar.json')));
  console.log('Jawaban: ' + jawaban)
  var teks1 = `*GAME TEBAK GAMBAR*\nPetunjuk: ${jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi, '-')}\nDeskripsi: ${deskripsi}\nWaktu: ${gamewaktu} detik\n\nKetik .nyerah untuk menyerah`
  await ikann.sendMessage(from, {
    image: {
      url: img
    },
    caption: teks1
  }, {
    quoted: m
  })
  tebakgambar[from] = {
    soal: img,
    jawaban: jawaban.toLowerCase(),
    hadiah: randomNomor(10, 20),
    waktu: setTimeout(function () {
      if (tebakgambar[from]) m.reply(`*WAKTU HABIS!*\nJawaban: ${tebakgambar[from].jawaban}`);
      delete tebakgambar[from];
    }, gamewaktu * 1000)
  }
}
break

case 'tebakkalimat': {
  if (from in tebakkalimat) return m.reply('Masih ada sesi yang belum diselesaikan!');
  var {
    soal,
    jawaban
  } = pickRandom(JSON.parse(fs.readFileSync('./lib/game/tebakkalimat.json')));
  console.log('Jawaban: ' + jawaban)
  await m.reply(`*GAME TEBAK KALIMAT*\nSoal: ${soal}\nPetunjuk: ${jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi, '-')}\nWaktu: ${gamewaktu} detik\n\nKetik .nyerah untuk menyerah`)
  tebakkalimat[from] = {
    soal: soal,
    jawaban: jawaban.toLowerCase(),
    hadiah: randomNomor(10, 20),
    waktu: setTimeout(function () {
      if (tebakkalimat[from]) m.reply(`*WAKTU HABIS!*\nJawaban dari soal: ${soal}\n\nAdalah: ${jawaban}`);
      delete tebakkalimat[from];
    }, gamewaktu * 1000)
  }
}
break

case 'tebakkata': {
  if (from in tebakkata) return m.reply('Masih ada sesi yang belum diselesaikan!');
  var {
    soal,
    jawaban
  } = pickRandom(JSON.parse(fs.readFileSync('./lib/game/tebakkata.json')));
  console.log('Jawaban: ' + jawaban)
  await m.reply(`*GAME TEBAK KATA*\nSoal: ${soal}\nPetunjuk: ${jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi, '-')}\nWaktu: ${gamewaktu} detik\n\nKetik .nyerah untuk menyerah`)
  tebakkata[from] = {
    soal: soal,
    jawaban: jawaban.toLowerCase(),
    hadiah: randomNomor(10, 20),
    waktu: setTimeout(function () {
      if (tebakkata[from]) m.reply(`*WAKTU HABIS!*\nJawaban dari soal: ${soal}\n\nAdalah: ${jawaban}`);
      delete tebakkata[from];
    }, gamewaktu * 1000)
  }
}
break

case 'tebaklirik': {
  if (from in tebaklirik) return m.reply('Masih ada sesi yang belum diselesaikan!');
  var {
    soal,
    jawaban
  } = pickRandom(JSON.parse(fs.readFileSync('./lib/game/tebaklirik.json')));
  console.log('Jawaban: ' + jawaban)
  await m.reply(`*GAME TEBAK LIRIK*\nSoal: ${soal}\nPetunjuk: ${jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi, '-')}\nWaktu: ${gamewaktu} detik\n\nKetik .nyerah untuk menyerah`)
  tebaklirik[from] = {
    soal: soal,
    jawaban: jawaban.toLowerCase(),
    hadiah: randomNomor(10, 20),
    waktu: setTimeout(function () {
      if (tebaklirik[from]) m.reply(`*WAKTU HABIS!*\nJawaban dari soal:\n${soal}\n\nAdalah: ${jawaban}`);
      delete tebaklirik[from];
    }, gamewaktu * 1000)
  }
}
break

case 'tebakanime': {
  if (from in tebakanime) return m.reply('Masih ada sesi yang belum diselesaikan!');
  var {
    image,
    jawaban
  } = pickRandom(JSON.parse(fs.readFileSync('./lib/game/tebakanime.json')));
  console.log('Jawaban: ' + jawaban)
  var teks1 = `*GAME TEBAK ANIME*\nPetunjuk: ${jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi, '-')}\nWaktu: ${gamewaktu} detik\n\nKetik .nyerah untuk menyerah`
  await ikann.sendMessage(from, {
    image: {
      url: image
    },
    caption: teks1
  }, {
    quoted: m
  })
  tebakanime[m.chat] = {
    soal: image,
    jawaban: jawaban.toLowerCase(),
    hadiah: randomNomor(10, 20),
    waktu: setTimeout(function () {
      if (tebakanime[m.chat]) m.reply(`*WAKTU HABIS!*\nJawaban: ${tebakanime[m.chat].jawaban}`);
      delete tebakanime[m.chat];
    }, gamewaktu * 1000)
  }
}
break

case 'tebaklagu': {
  if (from in tebaklagu) return m.reply('Masih ada sesi yang belum diselesaikan!');
  var {
    soal,
    artis,
    jawaban
  } = pickRandom(JSON.parse(fs.readFileSync('./lib/game/tebaklagu.json')));
  console.log('Jawaban: ' + jawaban)
  if (jawaban.toLowerCase() == 'Audio tidak ditemukan, silahkan request ulang!') return m.reply('Terjadi kesalahan')
  var teks1 = `*GAME TEBAK LAGU*\nPetunjuk: ${jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi, '-')}\nArtis: ${artis}\nWaktu: ${gamewaktu} detik\n\nKetik .nyerah untuk menyerah`
  ikann.sendMessage(from, {
    audio: {
      url: soal
    },
    mimetype: 'audio/mpeg',
    ptt: true
  }, {
    quoted: m
  })
  await ikann.sendMessage(from, {
    text: teks1
  }, {
    quoted: m
  })
  tebaklagu[m.chat] = {
    soal: soal,
    jawaban: jawaban.toLowerCase(),
    hadiah: randomNomor(10, 20),
    waktu: setTimeout(function () {
      if (tebaklagu[m.chat]) m.reply(`*WAKTU HABIS!*\nJawaban: ${tebaklagu[m.chat].jawaban}`);
      delete tebaklagu[m.chat];
    }, gamewaktu * 1000)
  }
}
break

case 'kuis': {
  if (from in kuis) return m.reply('Masih ada sesi yang belum diselesaikan!');
  var {
    soal,
    jawaban
  } = pickRandom(JSON.parse(fs.readFileSync('./lib/game/kuis.json')));
  console.log('Jawaban: ' + jawaban)
  await m.reply(`*GAME KUIS*\nSoal: ${soal}\nPetunjuk: ${jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi, '-')}\nWaktu: ${gamewaktu} detik\n\nKetik .nyerah untuk menyerah`)
  kuis[m.chat] = {
    soal: soal,
    jawaban: jawaban.toLowerCase(),
    hadiah: randomNomor(10, 20),
    waktu: setTimeout(function () {
      if (kuis[m.chat]) m.reply(`*WAKTU HABIS!*\nJawaban dari soal:\n${soal}\n\nAdalah: ${jawaban}`);
      delete kuis[m.chat];
    }, gamewaktu * 1000)
  }
}
break

case 'tebakkimia': {
  if (from in tebakkimia) return m.reply('Masih ada sesi yang belum diselesaikan!');
  var {
    soal,
    jawaban
  } = pickRandom(JSON.parse(fs.readFileSync('./lib/game/tebakkimia.json')));
  console.log('Jawaban: ' + jawaban)
  await m.reply(`*GAME TEBAK KIMIA*\nSoal: ${soal}\nWaktu: ${gamewaktu} detik\n\nKetik .nyerah untuk menyerah`)
  tebakkimia[m.chat] = {
    soal: soal,
    jawaban: jawaban.toLowerCase(),
    hadiah: randomNomor(10, 20),
    waktu: setTimeout(function () {
      if (tebakkimia[m.chat]) m.reply(`*WAKTU HABIS!*\nNama unsur dari lambang ${soal}\n\nAdalah: ${jawaban}`)
      delete tebakkimia[m.chat];
    }, gamewaktu * 1000)
  }
}
break

case 'tebakbendera': {
  if (from in tebakbendera) return m.reply('Masih ada sesi yang belum diselesaikan!');
  var {
    soal,
    jawaban
  } = pickRandom(JSON.parse(fs.readFileSync('./lib/game/tebakbendera.json')));
  console.log('Jawaban: ' + jawaban)
  await m.reply(`*GAME TEBAK BENDERA*\nSoal: ${soal}\nPetunjuk: ${jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi, '-')}\nWaktu: ${gamewaktu} detik\n\nKetik .nyerah untuk menyerah`)
  tebakbendera[m.chat] = {
    soal: soal,
    jawaban: jawaban.toLowerCase(),
    hadiah: randomNomor(10, 20),
    waktu: setTimeout(function () {
      if (tebakbendera[m.chat]) m.reply(`*WAKTU HABIS!*\nJawaban dari soal:\n${soal}\n\nAdalah: ${jawaban}`);
      delete tebakbendera[m.chat];
    }, gamewaktu * 1000)
  }
}
break

case 'siapakahaku': {
  if (from in siapakahaku) return m.reply('Masih ada sesi yang belum diselesaikan!');
  var {
    soal,
    jawaban
  } = pickRandom(JSON.parse(fs.readFileSync('./lib/game/siapakahaku.json')));
  console.log('Jawaban: ' + jawaban)
  await m.reply(`*GAME SIAPAKAH AKU*\nSoal: ${soal}\nPetunjuk: ${jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi, '-')}\nWaktu: ${gamewaktu} detik\n\nKetik .nyerah untuk menyerah`)
  siapakahaku[m.chat] = {
    soal: soal,
    jawaban: jawaban.toLowerCase(),
    hadiah: randomNomor(10, 20),
    waktu: setTimeout(function () {
      if (siapakahaku[m.chat]) m.reply(`*WAKTU HABIS!*\nJawaban dari soal:\n${soal}\n\nAdalah: ${jawaban}`);
      delete siapakahaku[m.chat];
    }, gamewaktu * 1000)
  }
}
break

case 'asahotak': {
  if (from in asahotak) return m.reply('Masih ada sesi yang belum diselesaikan!');
  var {
    soal,
    jawaban
  } = pickRandom(JSON.parse(fs.readFileSync('./lib/game/asahotak.json')));
  console.log('Jawaban: ' + jawaban)
  await m.reply(`*GAME ASAH OTAK*\nSoal: ${soal}\nPetunjuk: ${jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi, '-')}\nWaktu: ${gamewaktu} detik\n\nKetik .nyerah untuk menyerah`)
  asahotak[m.chat] = {
    soal: soal,
    jawaban: jawaban.toLowerCase(),
    hadiah: randomNomor(10, 20),
    waktu: setTimeout(function () {
      if (asahotak[m.chat]) m.reply(`*WAKTU HABIS!*\nJawaban dari soal:\n${soal}\n\nAdalah: ${jawaban}`);
      delete asahotak[m.chat];
    }, gamewaktu * 1000)
  }
}
break

case 'susunkata': {
  if (from in susunkata) return m.reply('Masih ada sesi yang belum diselesaikan!');
  var {
    soal,
    jawaban
  } = pickRandom(JSON.parse(fs.readFileSync('./lib/game/susunkata.json')));
  console.log('Jawaban: ' + jawaban)
  await m.reply(`*GAME SUSUN KATA*\nSoal: ${soal}\nPetunjuk: ${jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi, '-')}\nWaktu: ${gamewaktu} detik\n\nKetik .nyerah untuk menyerah`)
  susunkata[m.chat] = {
    soal: soal,
    jawaban: jawaban.toLowerCase(),
    hadiah: randomNomor(10, 20),
    waktu: setTimeout(function () {
      if (susunkata[m.chat]) m.reply(`*WAKTU HABIS!*\nJawaban dari soal:\n${soal}\n\nAdalah: ${jawaban}`);
      delete susunkata[m.chat];
    }, gamewaktu * 1000)
  }
}
break

case 'caklontong': {
  if (from in caklontong) return m.reply('Masih ada sesi yang belum diselesaikan!');
  var {
    soal,
    jawaban,
    deskripsi
  } = pickRandom(JSON.parse(fs.readFileSync('./lib/game/caklontong.json')));
  console.log(`Jawaban: ${jawaban}\n${deskripsi}`)
  await m.reply(`*GAME CAK LONTONG*\nSoal: ${soal}\nPetunjuk: ${jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi, '-')}\nWaktu: ${gamewaktu} detik\n\nKetik .nyerah untuk menyerah`)
  caklontong[from] = {
    soal: soal,
    jawaban: jawaban.toLowerCase(),
    hadiah: randomNomor(10, 20),
    waktu: setTimeout(function () {
      if (caklontong[from]) m.reply(`*WAKTU HABIS!*\nJawaban: ${jawaban}\n${deskripsi}`)
      delete caklontong[from];
    }, gamewaktu * 1000)
  }
}
break

case 'math':
case 'kuismath': {
  if (from in kuismath) return m.reply('Masih ada sesi yang belum diselesaikan!');
  let {
    genMath,
    modes
  } = require('./lib/game/math')
  if (!q) return m.reply(`*MODE*\n• ${Object.keys(modes).join('\n• ')}\n\nContoh: ${prefix+command} easy`)
  if (!(Object.keys(modes)).includes(args[0])) return m.reply('Silahkan pilih modenya yang benar!')
  var {
    soal,
    jawaban,
    waktu,
    hadiah
  } = await genMath(q.toLowerCase()).catch((err) => m.reply('Silahkan pilih modenya yang benar!'))
  console.log('Jawaban: ' + jawaban)
  await m.reply(`*GAME KUIS MATH*\nSoal: Berapa hasil dari ${soal.toLowerCase()}\nWaktu: ${waktu / 1000} detik\n\nKetik .nyerah untuk menyerah`)
  kuismath[from] = {
    soal: soal,
    jawaban: jawaban,
    hadiah: randomNomor(2000, hadiah),
    waktu: setTimeout(function () {
      if (kuismath[from]) m.reply(`*WAKTU HABIS!*\nJawaban: ${jawaban}`)
      delete kuismath[from];
    }, waktu)
  }
}
break

case 'tebakgame': {
  let anu = await fetchJson('https://raw.githubusercontent.com/qisyana/scrape/main/tebakgame.json')
  let result = anu[Math.floor(Math.random() * anu.length)]
  tebakgame[m.chat] = [
    await ikann.sendMessage(m.chat, {
      image: {
url: result.img
      },
      caption: `Apa nama Game diatas?\n\nWaktu: ${(120000 / 1000).toFixed(2)} detik\n\nKetik .nyerah untuk menyerah`
    }, {
      quoted: m
    }), result, 250,
    setTimeout(() => {
      if (tebakgame[m.chat]) {
m.reply(waktuHabis(result.jawaban))
delete tebakgame[m.chat]
      }
    }, 120000)
  ]
}
break

case 'nyerah': {
  if (m.chat in tebakgambar) {
    let {
      soal,
      jawaban,
      hadiah,
      waktu
    } = tebakgambar[m.chat]
    clearTimeout(waktu)
    delete tebakgambar[m.chat]
    return ikann.sendMessage(m.chat, {
      text: `*KAMU MENYERAH*\nSoal: ${soal}\nJawaban: ${jawaban}`
    }, {
      quoted: m
    })
  }
  if (m.chat in tebakkalimat) {
    let {
      soal,
      jawaban,
      hadiah,
      waktu
    } = tebakkalimat[m.chat]
    clearTimeout(waktu)
    delete tebakkalimat[m.chat]
    return ikann.sendMessage(m.chat, {
      text: `*KAMU MENYERAH*\nSoal: ${soal}\nJawaban: ${jawaban}`
    }, {
      quoted: m
    })
  }
  if (m.chat in tebakkata) {
    let {
      soal,
      jawaban,
      hadiah,
      waktu
    } = tebakkata[m.chat]
    clearTimeout(waktu)
    delete tebakkata[m.chat]
    return ikann.sendMessage(m.chat, {
      text: `*KAMU MENYERAH*\nSoal: ${soal}\nJawaban: ${jawaban}`
    }, {
      quoted: m
    })
  }
  if (m.chat in tebaklirik) {
    let {
      soal,
      jawaban,
      hadiah,
      waktu
    } = tebaklirik[m.chat]
    clearTimeout(waktu)
    delete tebaklirik[m.chat]
    return ikann.sendMessage(m.chat, {
      text: `*KAMU MENYERAH*\nSoal: ${soal}\nJawaban: ${jawaban}`
    }, {
      quoted: m
    })
  }
  if (m.chat in tebakanime) {
    let {
      soal,
      jawaban,
      hadiah,
      waktu
    } = tebakanime[m.chat]
    clearTimeout(waktu)
    delete tebakanime[m.chat]
    return ikann.sendMessage(m.chat, {
      text: `*KAMU MENYERAH*\nSoal: ${soal}\nJawaban: ${jawaban}`
    }, {
      quoted: m
    })
  }
  if (m.chat in tebaklagu) {
    let {
      soal,
      jawaban,
      hadiah,
      waktu
    } = tebaklagu[m.chat]
    clearTimeout(waktu)
    delete tebaklagu[m.chat]
    return ikann.sendMessage(m.chat, {
      text: `*KAMU MENYERAH*\nSoal: ${soal}\nJawaban: ${jawaban}`
    }, {
      quoted: m
    })
  }
  if (m.chat in kuis) {
    let {
      soal,
      jawaban,
      hadiah,
      waktu
    } = kuis[m.chat]
    clearTimeout(waktu)
    delete kuis[m.chat]
    return ikann.sendMessage(m.chat, {
      text: `*KAMU MENYERAH*\nSoal: ${soal}\nJawaban: ${jawaban}`
    }, {
      quoted: m
    })
  }
  if (m.chat in tebakkimia) {
    let {
      soal,
      jawaban,
      hadiah,
      waktu
    } = tebakkimia[m.chat]
    clearTimeout(waktu)
    delete tebakkimia[m.chat]
    return ikann.sendMessage(m.chat, {
      text: `*KAMU MENYERAH*\nSoal: ${soal}\nJawaban: ${jawaban}`
    }, {
      quoted: m
    })
  }
  if (m.chat in tebakbendera) {
    let {
      soal,
      jawaban,
      hadiah,
      waktu
    } = tebakbendera[m.chat]
    clearTimeout(waktu)
    delete tebakbendera[m.chat]
    return ikann.sendMessage(m.chat, {
      text: `*KAMU MENYERAH*\nSoal: ${soal}\nJawaban: ${jawaban}`
    }, {
      quoted: m
    })
  }
  if (m.chat in siapakahaku) {
    let {
      soal,
      jawaban,
      hadiah,
      waktu
    } = siapakahaku[m.chat]
    clearTimeout(waktu)
    delete siapakahaku[m.chat]
    return ikann.sendMessage(m.chat, {
      text: `*KAMU MENYERAH*\nSoal: ${soal}\nJawaban: ${jawaban}`
    }, {
      quoted: m
    })
  }
  if (m.chat in asahotak) {
    let {
      soal,
      jawaban,
      hadiah,
      waktu
    } = asahotak[m.chat]
    clearTimeout(waktu)
    delete asahotak[m.chat]
    return ikann.sendMessage(m.chat, {
      text: `*KAMU MENYERAH*\nSoal: ${soal}\nJawaban: ${jawaban}`
    }, {
      quoted: m
    })
  }
  if (m.chat in susunkata) {
    let {
      soal,
      jawaban,
      hadiah,
      waktu
    } = susunkata[m.chat]
    clearTimeout(waktu)
    delete susunkata[m.chat]
    return ikann.sendMessage(m.chat, {
      text: `*KAMU MENYERAH*\nSoal: ${soal}\nJawaban: ${jawaban}`
    }, {
      quoted: m
    })
  }
  if (m.chat in caklontong) {
    let {
      soal,
      jawaban,
      hadiah,
      waktu
    } = caklontong[m.chat]
    clearTimeout(waktu)
    delete caklontong[m.chat]
    return ikann.sendMessage(m.chat, {
      text: `*KAMU MENYERAH*\nSoal: ${soal}\nJawaban: ${jawaban}`
    }, {
      quoted: m
    })
  }
  if (m.chat in kuismath) {
    let {
      soal,
      jawaban,
      hadiah,
      waktu
    } = kuismath[m.chat]
    clearTimeout(waktu)
    delete kuismath[m.chat]
    return ikann.sendMessage(m.chat, {
      text: `*KAMU MENYERAH*\nSoal: ${soal}\nJawaban: ${jawaban}`
    }, {
      quoted: m
    })
  }
  if (m.chat in tebakgame) {
    clearTimeout(tebakgame[m.chat][3])
    delete tebakgame[m.chat]
    return ikann.sendMessage(m.chat, {
      text: `Yahh, masa nyerah :)`
    }, {
      quoted: m
    })
  }
}
break

// ==== Other Menu
case 'publik':
case 'public': {
  if (!isOwner) return onlyOwn()
  ikann.public = true
  m.reply('Sukses mengubah ke mode public')
}
break

case 'self': {
  if (!isOwner) return onlyOwn()
  ikann.public = false
  m.reply('Sukses mengubah ke mode self')
}
break

case 'rvo':
case 'readvo':
case 'readviewonce': {
    if (!m.quoted) return m.reply('Kutip pesan view-once!')
    let msg = m.quoted
    let type = msg.mtype
    if (!msg.viewOnce) return m.reply('Itu bukan pesan view-once!')

    let media = await downloadContentFromMessage(
msg, 
type === 'imageMessage' ? 'image' : 
type === 'videoMessage' ? 'video' : 'audio'
    )

    let buffer = Buffer.from([])
    for await (const chunk of media) {
buffer = Buffer.concat([buffer, chunk])
    }

    let sendOptions = { quoted: m }
    if (/video/.test(type)) {
return ikann.sendMessage(m.chat, { video: buffer, caption: msg.caption || '' }, sendOptions)
    } else if (/image/.test(type)) {
return ikann.sendMessage(m.chat, { image: buffer, caption: msg.caption || '' }, sendOptions)
    } else if (/audio/.test(type)) {
return ikann.sendMessage(m.chat, { audio: buffer, mimetype: 'audio/mpeg', ptt: true }, sendOptions)
    }
}
break

case 'sc':
case 'script': {
async function image(url) {
const {
imageMessage
} = await generateWAMessageContent({
image: {
url
}
}, {
upload: ikann.waUploadToServer
})
return imageMessage
}
let msg = generateWAMessageFromContent(
m.chat, {
viewOnceMessage: {
message: {
interactiveMessage: {
body: {
text: (`ᴍᴀᴜ ʙᴇʟɪ sᴄʀɪᴘᴛ, ʙɪsᴀ ʟᴀɴɢsᴜɴɢ ᴋᴇ ᴏᴡɴᴇʀ ᴋᴀᴍɪ ʏᴀ ᴋᴀᴋ`)
},
carouselMessage: {
cards: [
{
header: {
imageMessage: await image(thum11),
hasMediaAttachment: true,
},
body: {
text: `## *sᴄʀɪᴘᴛ ( 𝟷𝟻.𝟶𝟶𝟶 )*
> ғʀᴇᴇ ᴜᴘᴅᴀᴛᴇ
> sᴄʀɪᴘᴛ ᴍᴅ
> ɴᴏ ʙᴜɢ 𝟷𝟶𝟶%
> ʜᴀʀɢᴀ ᴛᴇʀᴊᴀɴɢᴋᴀᴜ
> ᴇʀʀᴏʀ? ʟᴀɴɢsᴜɴɢ ᴅɪ ʙᴇɴᴇʀɪɴ ᴘᴀs ᴜᴘᴅᴀᴛᴇ
> ʀᴇǫᴜᴇsᴛ ғɪᴛᴜʀ sᴇᴛɪᴀᴘ ᴜᴘᴅᴀᴛᴇ
`
},
nativeFlowMessage: {
buttons: [{
name: "cta_url",
buttonParamsJson: '{"display_text":"ʙᴇʟɪ ʙɪsᴀ ᴋᴇ sɪɴɪ","url":"https:\\/\\/wa.me\\/6285765183832?text=Bang+beli+script+ikann","webview_presentation":null}',
},
],
},
},
],
messageVersion: 1,
},
},
},
},
}, {});
await ikann.relayMessage(msg.key.remoteJid, msg.message, {
messageId: msg.key.id,
});
}
break

// ==== Owner Menu
case 'addcase': {
  if (!isOwner) return onlyOwn();
  if (!text) return m.reply(`Contoh: ${p_c} case nya`);
  const namaFile = path.join(__dirname, 'ikann.js');
  const caseBaru = `${text}\n\n`;
  const tambahCase = (data, caseBaru) => {
    const posisiDefault = data.lastIndexOf("default:");
    if (posisiDefault !== -1) {
      const kodeBaruLengkap = data.slice(0, posisiDefault) + caseBaru + data.slice(posisiDefault);
      return {
success: true,
kodeBaruLengkap
      };
    } else {
      return {
success: false,
message: "Tidak dapat menemukan case default di dalam file!"
      };
    }
  };
  fs.readFile(namaFile, 'utf8', (err, data) => {
    if (err) {
      console.error('Terjadi kesalahan saat membaca file:', err);
      return m.reply(`Terjadi kesalahan saat membaca file: ${err.message}`);
    }
    const result = tambahCase(data, caseBaru);
    if (result.success) {
      fs.writeFile(namaFile, result.kodeBaruLengkap, 'utf8', (err) => {
if (err) {
  console.error('Terjadi kesalahan saat menulis file:', err);
  return m.reply(`Terjadi kesalahan saat menulis file: ${err.message}`);
} else {
  console.log('Sukses menambahkan case baru:');
  console.log(caseBaru);
  return m.reply('Sukses menambahkan case!');
}
      });
    } else {
      console.error(result.message);
      return m.reply(result.message);
    }
  });
}
break

case 'delcase': {
  if (!isOwner) return onlyOwn();
  if (!text) return m.reply(`Contoh: ${p_c} nama case`);
  const fs = require('fs').promises;
  async function dellCase(filePath, caseNameToRemove) {
    try {
      let data = await fs.readFile(filePath, 'utf8');
      const regex = new RegExp(`case\\s+'${caseNameToRemove}':[\\s\\S]*?break`, 'g');
      const modifiedData = data.replace(regex, '');
      if (data === modifiedData) {
m.reply('Case tidak ditemukan atau sudah dihapus.');
return;
      }
      await fs.writeFile(filePath, modifiedData, 'utf8');
      m.reply('Sukses menghapus case!');
    } catch (err) {
      m.reply(`Terjadi kesalahan: ${err.message}`);
    }
  }
  dellCase('./ikann.js', q);
}
break

case 'getcase': {
  if (!isOwner) return onlyOwn();
  if (!text) return m.reply(`Contoh: ${p_c} 1 caseName atau ${p_c} 2 caseName1 caseName2`);
  const modeRegex = /^([12])\s+(.+)$/;
  const match = text.match(modeRegex);
  if (!match) return m.reply(`Format tidak valid. Contoh: ${p_c} 1 caseName atau ${p_c} 2 caseName1 caseName2`);
  const mode = parseInt(match[1], 10);
  const caseNames = match[2].split(' ').map(name => name.trim()).filter(name => name);
  if (mode === 1 && caseNames.length !== 1) {
    return m.reply(`Untuk mode '1', masukkan satu case name. Contoh: ${p_c} 1 caseName`);
  }
  if (mode === 2 && (caseNames.length < 1 || caseNames.length > 2)) {
    return m.reply(`Untuk mode '2', masukkan satu atau dua case names. Contoh: ${p_c} 2 caseName1 caseName2`);
  }
  const getCase = async (caseName) => {
    try {
      const fileContent = await fs.promises.readFile('./ikann.js', "utf-8");
      const caseRegex = new RegExp(`case '${caseName}'[\\s\\S]*?break`, 'g');
      const match = fileContent.match(caseRegex);
      if (!match) {
return m.reply(`Case '${caseName}' tidak ditemukan.`);
      }
      return match[0];
    } catch (error) {
      return m.reply(`Terjadi kesalahan saat membaca file: ${error.message}`);
    }
  };
  const getCases = async (caseNames) => {
    try {
      const casePromises = caseNames.map(caseName => getCase(caseName));
      const cases = await Promise.all(casePromises);
      return cases.join('\n\n');
    } catch (error) {
      return m.reply(`Terjadi kesalahan: ${error.message}`);
    }
  };

  getCases(caseNames)
  .then(caseCode => m.reply(caseCode))
  .catch(error => m.reply(`Terjadi kesalahan: ${error.message}`));
}
break

case 'backup': {
  if (!isOwner) return onlyOwn()
  backup()
}
break

case 'addprem':
case 'addpremium': {
  if (!isOwner) return onlyOwn();
  if (!args[0]) return m.reply(`Contoh: ${p_c} tag/kutip`);
  let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
  if (prem.includes(users)) return m.reply('User sudah ada di daftar premium!');
  prem.push(users);
  fs.writeFileSync('./data/premium.json', JSON.stringify(prem, null, 2));
  m.reply('Berhasil addpremium');
}
break

case 'delprem':
case 'delpremium': {
  if (!isOwner) return onlyOwn();
  if (!args[0]) return m.reply(`Contoh: ${p_c} tag/kutip`);
  let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
  const index = prem.indexOf(users);
  if (index === -1) return m.reply('User tidak ditemukan di daftar premium!');
  prem.splice(index, 1);
  fs.writeFileSync('./data/premium.json', JSON.stringify(prem, null, 2));
  m.reply('Berhasil delpremium');
}
break

case 'listprem':
case 'listpremium':
case 'listpremiums': {
  if (!isOwner) return onlyOwn();
  let teks = `List premium\nTotal: ${own.length}\n\n`;
  for (let kon of prem) {
    teks += `• ${kon}\n`;
  }
  m.reply(teks);
}
break

case 'addown':
case 'addowner': {
  if (!isOwner) return onlyOwn();
  if (!args[0]) return m.reply(`Contoh: ${p_c} tag`);
  let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
  if (own.includes(users)) return m.reply('User sudah ada di daftar owner!');
  own.push(users);
  fs.writeFileSync('./data/owner.json', JSON.stringify(own, null, 2));
  m.reply('Berhasil addowner');
}
break

case 'delown':
case 'delowner': {
  if (!isOwner) return onlyOwn();
  if (!args[0]) return m.reply(`Contoh: ${p_c} tag`);
  let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
  const index = own.indexOf(users);
  if (index === -1) return m.reply('User tidak ditemukan di daftar owner!');
  own.splice(index, 1);
  fs.writeFileSync('./data/owner.json', JSON.stringify(own, null, 2));
  m.reply('Berhasil delowner');
}
break

case 'listown':
case 'listowner':
case 'listcreator': {
  if (!isOwner) return onlyOwn();
  let teks = `List owner\nTotal: ${own.length}\n\n`;
  for (let kon of own) {
    teks += `• ${kon}\n`;
  }
  m.reply(teks);
}
break

case 'addownnel':
case 'addownerpanel': {
  if (!isOwner) return onlyNo();
  if (!args[0]) return m.reply(`Contoh: ${p_c} tag`);
  let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
  if (patner.includes(users)) return m.reply('User sudah ada di daftar owner!');
  patner.push(users);
  fs.writeFileSync('./data/ownnel.json', JSON.stringify(patner, null, 2));
  m.reply('Berhasil menambahkan owner');
}
break

case 'delownnel':
case 'delownerpanel': {
  if (!isOwner) return onlyNo();
  if (!args[0]) return m.reply(`Contoh: ${p_c} tag`);
  let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
  const index = onwnel.indexOf(users);
  if (index === -1) return m.reply('User tidak ditemukan di daftar owner!');
  onwnel.splice(index, 1);
  fs.writeFileSync('./data/onwnel.json', JSON.stringify(onwnel, null, 2));
  m.reply('Berhasil menghapus owner');
}
break

case 'listownnel':
case 'listownerpanel': {
  if (!isOwner) return onlyOwn();
  let teks = `List owner\nTotal: ${onwnel.length}\n\n`;
  for (let kon of onwnel) {
    teks += `• ${kon}\n`;
  }
  m.reply(teks);
}
break

case 'addpt':
case 'addpatner': {
  if (!isOwner && !isPatner) return onlyNo();
  if (!args[0]) return m.reply(`Contoh: ${p_c} tag`);
  let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
  if (patner.includes(users)) return m.reply('User sudah ada di daftar patner!');
  patner.push(users);
  fs.writeFileSync('./data/patner.json', JSON.stringify(patner, null, 2));
  m.reply('Berhasil menambahkan patner');
}
break

case 'delpt':
case 'delpatner': {
  if (!isOwner && !isPatner) return onlyNo();
  if (!args[0]) return m.reply(`Contoh: ${p_c} tag`);
  let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
  const index = patner.indexOf(users);
  if (index === -1) return m.reply('User tidak ditemukan di daftar patner!');
  patner.splice(index, 1);
  fs.writeFileSync('./data/patner.json', JSON.stringify(patner, null, 2));
  m.reply('Berhasil menghapus patner');
}
break

case 'listpt':
case 'listpatner': {
  if (!isOwner && !isPatner) return onlyNo();
  let teks = `List patner\nTotal: ${patner.length}\n\n`;
  for (let kon of patner) {
    teks += `• ${kon}\n`;
  }
  m.reply(teks);
}
break

case 'addmin':
case 'addadmin': {
  if (!isOwner && !isReseller && !isPatner) return onlyNo();
  if (!args[0]) return m.reply(`Contoh: ${p_c} tag`);
  let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
  if (adminnel.includes(users)) return m.reply('User sudah ada di daftar admin!');
  adminnel.push(users);
  fs.writeFileSync('./data/adminnel.json', JSON.stringify(adminnel, null, 2));
  m.reply('Berhasil menambahkan admin');
}
break

case 'delmin':
case 'deladmin': {
  if (!isOwner && !isReseller && !isPatner) return onlyNo();
  if (!args[0]) return m.reply(`Contoh: ${p_c} tag`);
  let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
  const index = adminnel.indexOf(users);
  if (index === -1) return m.reply('User tidak ditemukan di daftar admin!');
  adminnel.splice(index, 1);
  fs.writeFileSync('./data/adminnel.json', JSON.stringify(adminnel, null, 2));
  m.reply('Berhasil menghapus admin');
}
break

case 'listmin':
case 'listadmin': {
  if (!isOwner && !isReseller && !isPatner) return onlyNo();
  let teks = `List admin\nTotal: ${adminnel.length}\n\n`;
  for (let kon of adminnel) {
    teks += `• ${kon}\n`;
  }
  m.reply(teks);
}
break

case 'addres':
case 'addreseller': {
  if (!isOwner && !isReseller && !isAdminnel && !isPatner) return onlyNo();
  if (!args[0]) return m.reply(`Contoh: ${p_c} tag`);
  let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
  if (ress.includes(users)) return m.reply('User sudah ada di daftar reseller!');
  ress.push(users);
  fs.writeFileSync('./data/reseller.json', JSON.stringify(ress, null, 2));
  m.reply('Berhasil menambahkan reseller');
}
break


case 'delres':
case 'delreseller': {
  if (!isOwner && !isReseller && !isAdminnel && !isPatner) return onlyNo();
  if (!args[0]) return m.reply(`Contoh: ${p_c} tag`);
  let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
  const index = ress.indexOf(users);
  if (index === -1) return m.reply('User tidak ditemukan di daftar reseller!');
  ress.splice(index, 1);
  fs.writeFileSync('./data/reseller.json', JSON.stringify(ress, null, 2));
  m.reply('Berhasil menambahkan reseller');
}
break

case 'listres':
case 'listreseller': {
  if (!isOwner && !isReseller && !isAdminnel && !isPatner) return onlyNo();
  let teks = `List reseller\nTotal: ${ress.length}\n\n`;
  for (let kon of ress) {
    teks += `• ${kon}\n`;
  }
  m.reply(teks);
}
break

case 'addjpm':
case 'addmuridjpm': {
  if (!isOwner) return onlyOwn()
  if (!args[0]) return m.reply(`Contoh: ${p_c} tag`);
  let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
  if (jasher.includes(users)) return m.reply('User sudah ada di daftar jasher!');
  jasher.push(users);
  fs.writeFileSync('./data/jpm.json', JSON.stringify(jasher, null, 2));
  m.reply('Berhasil menambahkan jasher');
}
break

case 'deljpm':
case 'delmuridjpm': {
  if (!isOwner) return onlyOwn()
  if (!args[0]) return m.reply(`Contoh: ${p_c} tag`);
  let users = m.mentionedJid[0]
    ? m.mentionedJid[0]
    : m.quoted
    ? m.quoted.sender
    : q.split('|')[0].replace(/[^0-9]/g, '');
  const index = jasher.indexOf(users);
  if (index === -1) return m.reply('User tidak ditemukan di daftar murid jasher!');
  jasher.splice(index, 1);
  fs.writeFileSync('./data/jpm.json', JSON.stringify(jasher, null, 2));
  m.reply('Berhasil menambahkan jasher');
}
break

case 'listjpm':
case 'listmuridjpm': {
  if (!isOwner) return onlyOwn()
  let teks = `List jasher\nTotal: ${jasher.length}\n\n`;
  for (let kon of jasher) {
    teks += `• ${kon}\n`;
  }
  m.reply(teks);
}
break

// ==== Main Menu
case 'autoread': {
  if (!isOwner) return onlyOwn()
  if (!args[0]) return m.reply(`Contoh: ${p_c} on/off`)
  if (args[0] === 'on') {
    global.autoread = true
    await m.reply('Sukses mengaktifkan autoread.')
  } else if (args[0] === 'off') {
    global.autoread = false
    await m.reply('Sukses menonaktifkan autoread.')
  }
}
break

case 'ping':
case 'ping-v':
case 'srvinfo': {
  const os = require('os')
  const nou = require('node-os-utils')

  function formatp(bytes) {
    if (bytes < 1024) return `${bytes} B`
    const kb = bytes / 1024
    if (kb < 1024) return `${kb.toFixed(2)} KB`
    const mb = kb / 1024
    if (mb < 1024) return `${mb.toFixed(2)} MB`
    const gb = mb / 1024
    return `${gb.toFixed(2)} GB`
  }

  async function getServerInfo() {
    try {
      const osType = nou.os.type()
      const release = os.release()
      const arch = os.arch()
      const nodeVersion = process.version
      const ip = await nou.os.ip()

      const cpus = os.cpus()
      const cpuModel = cpus[0].model
      const coreCount = cpus.length
      const cpu = cpus.reduce((acc, cpu) => {
acc.total += Object.values(cpu.times).reduce((a, b) => a + b, 0)
acc.speed += cpu.speed
acc.times.user += cpu.times.user
acc.times.nice += cpu.times.nice
acc.times.sys += cpu.times.sys
acc.times.idle += cpu.times.idle
acc.times.irq += cpu.times.irq
return acc
      }, { speed: 0, total: 0, times: { user: 0, nice: 0, sys: 0, idle: 0, irq: 0 } })
      const cpuUsage = ((cpu.times.user + cpu.times.sys) / cpu.total * 100).toFixed(2) + '%'
      const loadAverage = os.loadavg()
      const totalMem = os.totalmem()
      const freeMem = os.freemem()
      const usedMem = totalMem - freeMem
      const storageInfo = await nou.drive.info()
      const speed = require('performance-now')
      const timestamp = speed()
      const latensi = speed() - timestamp
      const responseText = `
 *INFO SERVER*
• OS: ${osType} (${release})
• Arsitektur: ${arch}
• Versi Node.js: ${nodeVersion}
• IP Address: ${ip}

 *CPU SISTEM*
• Model: ${cpuModel}
• Kecepatan: ${cpu.speed} MHz
• Beban CPU: ${cpuUsage} (${coreCount} Core)
• Load Average: ${loadAverage.join(', ')}

 *MEMORI (RAM)*
• Total: ${formatp(totalMem)}
• Digunakan: ${formatp(usedMem)}
• Tersedia: ${formatp(freeMem)}

 *PENYIMPANAN*
• Total: ${storageInfo.totalGb} GB
• Digunakan: ${storageInfo.usedGb} GB (${storageInfo.usedPercentage}%)
• Tersedia: ${storageInfo.freeGb} GB (${storageInfo.freePercentage}%)

 *PING*
• Latensi: ${latensi.toFixed(4)} detik
`
      return responseText.trim()
    } catch (error) {
      console.error('Terjadi kesalahan', error)
      return 'Terjadi kesalahan'
    }
  }

  getServerInfo().then(responseText => {
    ikann.sendMessage(m.chat, { text: responseText }, { quoted: m })
  })
}
break

case 'totalfitur': {
const Allfitur = totalPlugin() + totalCase()
m.reply( `*🚀 IkannNew – Total feature* 🚀\n\n` +
`🔹️ *Cases Commands :* ${totalCase()}\n` +
`🔹️ *Plugins Commands :* ${totalPlugin()}\n\n` +
`☑️ *Total all features :* ${Allfitur}\n` +
`> 💡 Punya ide fitur keren ?\n> jangan ragu untuk memberi saran!`)
}
break
// ==== Tools Menu
case 'qc':
case 'qcstick': {
  if (!args[0]) return m.reply(`Contoh: ${p_c} white halo`)
  if (!args[1]) return m.reply(`Contoh: ${p_c} white halo`)
  if (text.length > 80) return m.reply(`Maximal 80 karakter!`)
  react()
  let [color, ...message] = text.split(' ')
  message = m.quoted ? m.quoted : message.join(' ')
  let backgroundColor
  switch (color) {
  case 'pink':
    backgroundColor = '#f68ac9'
    break
  case 'blue':
    backgroundColor = '#6cace4'
    break
  case 'red':
    backgroundColor = '#f44336'
    break
  case 'green':
    backgroundColor = '#4caf50'
    break
  case 'yellow':
    backgroundColor = '#ffeb3b'
    break
  case 'purple':
    backgroundColor = '#9c27b0'
    break
  case 'darkblue':
    backgroundColor = '#0d47a1'
    break
  case 'lightblue':
    backgroundColor = '#03a9f4'
    break
  case 'ash':
    backgroundColor = '#9e9e9e'
    break
  case 'orange':
    backgroundColor = '#ff9800'
    break
  case 'black':
    backgroundColor = '#000000'
    break
  case 'white':
    backgroundColor = '#ffffff'
    break
  case 'teal':
    backgroundColor = '#008080'
    break
  case 'lightpink':
    backgroundColor = '#FFC0CB'
    break
  case 'chocolate':
    backgroundColor = '#A52A2A'
    break
  case 'salmon':
    backgroundColor = '#FFA07A'
    break
  case 'magenta':
    backgroundColor = '#FF00FF'
    break
  case 'tan':
    backgroundColor = '#D2B48C'
    break
  case 'wheat':
    backgroundColor = '#F5DEB3'
    break
  case 'deeppink':
    backgroundColor = '#FF1493'
    break
  case 'fire':
    backgroundColor = '#B22222'
    break
  case 'skyblue':
    backgroundColor = '#00BFFF'
    break
  case 'brightskyblue':
    backgroundColor = '#1E90FF'
    break
  case 'hotpink':
    backgroundColor = '#FF69B4'
    break
  case 'lightskyblue':
    backgroundColor = '#87CEEB'
    break
  case 'seagreen':
    backgroundColor = '#20B2AA'
    break
  case 'darkred':
    backgroundColor = '#8B0000'
    break
  case 'orangered':
    backgroundColor = '#FF4500'
    break
  case 'cyan':
    backgroundColor = '#48D1CC'
    break
  case 'violet':
    backgroundColor = '#BA55D3'
    break
  case 'mossgreen':
    backgroundColor = '#00FF7F'
    break
  case 'darkgreen':
    backgroundColor = '#008000'
    break
  case 'navyblue':
    backgroundColor = '#191970'
    break
  case 'darkorange':
    backgroundColor = '#FF8C00'
    break
  case 'darkpurple':
    backgroundColor = '#9400D3'
    break
  case 'fuchsia':
    backgroundColor = '#FF00FF'
    break
  case 'darkmagenta':
    backgroundColor = '#8B008B'
    break
  case 'darkgray':
    backgroundColor = '#2F4F4F'
    break
  case 'peachpuff':
    backgroundColor = '#FFDAB9'
    break
  case 'darkishgreen':
    backgroundColor = '#BDB76B'
    break
  case 'darkishred':
    backgroundColor = '#DC143C'
    break
  case 'goldenrod':
    backgroundColor = '#DAA520'
    break
  case 'darkishgray':
    backgroundColor = '#696969'
    break
  case 'darkishpurple':
    backgroundColor = '#483D8B'
    break
  case 'gold':
    backgroundColor = '#FFD700'
    break
  case 'silver':
    backgroundColor = '#C0C0C0'
    break
  default:
    return m.reply('Warna tersebut tidak ditemukan!')
  }
  const username = pushname
  const avatar = await ikann.profilePictureUrl(m.sender, "image").catch(() => 'https://files.catbox.moe/nwvkbt.png')
  const json = {
    type: 'quote',
    format: 'png',
    backgroundColor,
    width: 512,
    height: 768,
    scale: 2,
    messages: [{
      entities: [],
      avatar: true,
      from: {
id: 1,
name: username,
photo: { url: avatar }
      },
      text: message,
      replyMessage: {}
    }]
  }
  const response = await axios.post('https://bot.lyo.su/quote/generate', json, {
    headers: { 'Content-Type': 'application/json' }
  })
  const buffer = Buffer.from(response.data.result.image, 'base64')
  ikann.sendImageAsSticker(m.chat, buffer, m, {
    packname: ``,
    author: `${author} | ${username}`
  })
}
break

case 'qckode':
case 'kodeqc': {
  m.reply(`${monospace("LIST  WARNA")}\n\n• Pink\n• Blue\n• Red\n• Green\n• Yellow\n• Purple\n• Darkblue\n• Lightblue\n• Ash\n• Orange\n• black\n• White\n• Teal\n• Lightpink\n• Chocolate\n• Salmon\n• Magenta\n• Tan\n• Wheat\n• Deeppink\n• Fire\n• Skyblue\n• Safron\n• Brightskyblue\n• Hotpink\n• Lightskyblue\n• Seagreen\n• Darkred\n• Orangered\n• Cyan\n• Violet\n• Mossgreen\n• Darkgreen\n• Navyblue\n• Darkorange\n• Darkpurple\n• Fuchsia\n• Darkmagenta\n• Darkgray\n• Peachpuff\n• Plackishgreen\n• Darkishred\n• Goldenrod\n• Darkishgray\n• Darkishpurple\n• Gold\n• Silver`)
}
break

case 's':
case 'stiker':
case 'sticker': {
  if (!quoted) return m.reply(`Kirim/kutip gambar dengan caption ${p_c}`)
  react()
  
  if (quoted.message) {
    let msg = quoted.message
    let type = Object.keys(msg)[0]
    if (msg[type].viewOnce) {
      let media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : 'video')
      let buffer = Buffer.from([])
      for await (const chunk of media) {
buffer = Buffer.concat([buffer, chunk])
      }
      if (/video/.test(type)) {
if ((quoted.msg || quoted).seconds > 25) return m.reply('Maksimal 25 detik!')
await ikann.vidToSticker(m.chat, buffer, m, {
  packname: ``,
  author: author + ` | ${pushname}`
})
return
      } else if (/image/.test(type)) {
await ikann.imgToSticker(m.chat, buffer, m, {
  packname: ``,
  author: author + ` | ${pushname}`
})
return
      }
    }
  }
  
  if (/image/.test(mime)) {
    let media = await ikann.downloadAndSaveMediaMessage(quoted, +new Date * 1)
    await ikann.imgToSticker(m.chat, media, m, {
      packname: ``,
      author: author + ` | ${pushname}`
    })
    await fs.unlinkSync(media)
  } else if (/video/.test(mime)) {
    if ((quoted.msg || quoted).seconds > 25) return m.reply('Maksimal 25 detik!')
    let media = await ikann.downloadAndSaveMediaMessage(quoted, +new Date * 1)
    await ikann.vidToSticker(m.chat, media, m, {
      packname: ``,
      author: author + ` | ${pushname}`
    })
    await fs.unlinkSync(media)
  } else if (/sticker/.test(mime)) {
    let media = await ikann.downloadAndSaveMediaMessage(quoted, +new Date * 1)
    await ikann.sendStickerFromUrl(m.chat, media, m, {
      packname: ``,
      author: author + ` | ${pushname}`
    })
    await fs.unlinkSync(media)
  } else m.reply(`Kirim/kutip gambar dengan caption ${p_c}`)
}
break

case 'smeme': {
  react()
  if (quoted.message) {
    let msg = quoted.message
    let type = Object.keys(msg)[0]
    if (msg[type].viewOnce && /image/.test(type)) {
      let media = await downloadContentFromMessage(msg[type], 'image')
      let buffer = Buffer.from([])
      for await (const chunk of media) {
buffer = Buffer.concat([buffer, chunk])
      }
      
      atas = text.split('|')[0] ? text.split('|')[0] : '-'
      bawah = text.split('|')[1] ? text.split('|')[1] : '-'
      
      const tempFile = `./temp_${Date.now()}.jpg`
      await fs.writeFileSync(tempFile, buffer)
      
      mem = await CatBox(tempFile)
      let smeme = await fetch(`https://api.memegen.link/images/custom/${encodeURIComponent(atas)}/${encodeURIComponent(bawah)}.png?background=${mem}`)
      let smem = await smeme.buffer()
      
      await ikann.sendImageAsSticker(m.chat, smem, m, {
packname: ``,
author: `${author} | ${pushname}`
      })
      
      await fs.unlinkSync(tempFile)
      return
    }
  }
  
  if (!/webp/.test(mime) && /image/.test(mime)) {
    react()
    atas = text.split('|')[0] ? text.split('|')[0] : '-'
    bawah = text.split('|')[1] ? text.split('|')[1] : '-'
    mee = await ikann.downloadAndSaveMediaMessage(quoted)
    mem = await CatBox(mee)
    let smeme = await fetch(`https://api.memegen.link/images/custom/${encodeURIComponent(atas)}/${encodeURIComponent(bawah)}.png?background=${mem}`)
    let smem = await smeme.buffer()
    await ikann.sendImageAsSticker(m.chat, smem, m, {
      packname: ``,
      author: `${author} | ${pushname}`
    })
    await fs.unlinkSync(mee)
  } else {
    m.reply(`Kirim/kutip gambar dengan caption ${p_c} sanjaya|toyaa`)
  }
}
break

case 'wm':
case 'swm': {
  if (!quoted) return m.reply(`Kirim/kutip stiker lalu ketik ${p_c} teks1|teks2`)
  
  let [teks1, teks2] = text.split('|').map(v => v || '')
  react()

  let processSticker = async (media, type) => {
    await ikann[`${type}ToSticker`](m.chat, media, m, { packname: teks1, author: teks2 })
  }

  if (m.quoted.isAnimated) {
    let media = await ikann.downloadAndSaveMediaMessage(quoted, new Date * 1)
    let buffer = await getBuffer(await webp2mp4File(await CatBox(media)))
    await processSticker(buffer, 'vid')
  } else if (/image/.test(mime)) {
    let media = await quoted.download()
    await processSticker(media, 'img')
  } else if (/video/.test(mime)) {
    if ((quoted.msg || quoted).seconds > 18) return m.reply('Maksimal 18 detik!')
    let media = await quoted.download()
    await processSticker(media, 'vid')
  } else {
    m.reply(`Kirim/kutip stiker lalu ketik ${p_c} teks1|teks2`)
  }
}
break

case 'get': {
    if (!text) return m.reply(`Contoh: ${p_c} linknya`)
	if (!text.includes('http')) return m.reply(`Contoh: ${p_c} linknya`)
	
	try {
const data = await axios.get(text)
const contentType = data.headers["content-type"]

if (contentType.startsWith('image/')) {
ikann.sendMessage(m.chat, {
image: { url: text },
caption: `${text}\n\n*Headers Respons:*\n${Object.entries(data.headers).map(([key, value]) => `*${key}:* ${value}`).join('\n')}`
}, { quoted: m })

} else if (contentType.startsWith('video/')) {
ikann.sendMessage(m.chat, {
video: { url: text },
caption: `${text}\n\n*Headers Respons:*\n${Object.entries(data.headers).map(([key, value]) => `*${key}:* ${value}`).join('\n')}`
}, { quoted: m })

} else if (contentType.startsWith('audio/')) {
ikann.sendMessage(m.chat, {
audio: { url: text },
mimetype: 'audio/mpeg'
}, { quoted: m })

} else {
m.reply(util.format(data.data))

const saveFileToDisk = async (url, outputPath) => {
const response = await axios.get(url, { responseType: 'arraybuffer' })
const contentType = response.headers['content-type']
const ext = contentType.split('/')[1] || 'bin'
const filePath = `${outputPath}.${ext}`

return new Promise((resolve, reject) => {
	fs.writeFile(filePath, response.data, (err) => {
if (err) reject(err)
else resolve({ file: filePath, ext, mime: contentType })
	})
})
}

try {
const buffer = await ikann.downloadAndSaveMediaMessage(m.quoted || m)
await sleep(2000)

const mimeType = await getMimeType(buffer)
ikann.sendMessage(m.chat, {
	document: fs.readFileSync(buffer),
	mimetype: mimeType,
	fileName: `get-data.${mimeType}`
}, { quoted: m })

fs.unlinkSync(buffer)
} catch (error) {
console.error('Gagal menyimpan:', error)
}
}
	} catch (error) {
m.reply('Terjadi kesalahan')
console.error('Error:', error)
	}
}
break

case 'enc': {
  if (!quoted || !quoted.message || !quoted.message.documentMessage) {
    return m.reply("Balas file kode (misal .js) dengan caption *.enc*")
  }

  const mimeType = quoted.message.documentMessage.mimetype || ''
  const fileName = quoted.message.documentMessage.fileName || 'file.js'
  const fileExt = path.extname(fileName).toLowerCase()

  if (!fileExt.endsWith(".js")) {
    return m.reply("File harus berformat .js (JavaScript saja untuk saat ini).")
  }

  try {
    const media = await quoted.download()
    const code = media.toString()

    const obfuscator = require('javascript-obfuscator')
    const result = obfuscator.obfuscate(code, {
      compact: true,
      controlFlowFlattening: true,
      controlFlowFlatteningThreshold: 1,
      numbersToExpressions: true,
      simplify: true,
      shuffleStringArray: true,
      splitStrings: true,
      splitStringsChunkLength: 5,
      stringArray: true,
      stringArrayEncoding: ['base64', 'rc4'],
      stringArrayThreshold: 1,
      selfDefending: true
    })

    const hasil = result.getObfuscatedCode()
    const outPath = `./data/sampah/encrypted-${Date.now()}.js`
    fs.writeFileSync(outPath, hasil)

    await ikann.sendMessage(m.chat, {
      document: fs.readFileSync(outPath),
      fileName: `encrypted-${fileName}`,
      mimetype: "application/javascript",
      caption: "✅ File berhasil dienkripsi dan siap dijalankan!"
    }, { quoted: m })

    fs.unlinkSync(outPath)
  } catch (err) {
    console.error(err)
    m.reply("Gagal mengenkripsi file.")
  }
}
break

case 'get': {
    if (!text) return m.reply(`Contoh: ${p_c} linknya`)
	if (!text.includes('http')) return m.reply(`Contoh: ${p_c} linknya`)
	
	try {
const data = await axios.get(text)
const contentType = data.headers["content-type"]

if (contentType.startsWith('image/')) {
ikann.sendMessage(m.chat, {
image: { url: text },
caption: `${text}\n\n*Headers Respons:*\n${Object.entries(data.headers).map(([key, value]) => `*${key}:* ${value}`).join('\n')}`
}, { quoted: m })

} else if (contentType.startsWith('video/')) {
ikann.sendMessage(m.chat, {
video: { url: text },
caption: `${text}\n\n*Headers Respons:*\n${Object.entries(data.headers).map(([key, value]) => `*${key}:* ${value}`).join('\n')}`
}, { quoted: m })

} else if (contentType.startsWith('audio/')) {
ikann.sendMessage(m.chat, {
audio: { url: text },
mimetype: 'audio/mpeg'
}, { quoted: m })

} else {
m.reply(util.format(data.data))

const saveFileToDisk = async (url, outputPath) => {
const response = await axios.get(url, { responseType: 'arraybuffer' })
const contentType = response.headers['content-type']
const ext = contentType.split('/')[1] || 'bin'
const filePath = `${outputPath}.${ext}`

return new Promise((resolve, reject) => {
	fs.writeFile(filePath, response.data, (err) => {
if (err) reject(err)
else resolve({ file: filePath, ext, mime: contentType })
	})
})
}

try {
const buffer = await ikann.downloadAndSaveMediaMessage(m.quoted || m)
await sleep(2000)

const mimeType = await getMimeType(buffer)
ikann.sendMessage(m.chat, {
	document: fs.readFileSync(buffer),
	mimetype: mimeType,
	fileName: `get-data.${mimeType}`
}, { quoted: m })

fs.unlinkSync(buffer)
} catch (error) {
console.error('Gagal menyimpan:', error)
}
}
	} catch (error) {
m.reply('Terjadi kesalahan')
console.error('Error:', error)
	}
}
break

case 'nulis': {
  if (!text) return m.reply(`Contoh: ${p_c} toyaa`)
  try {
    react()
    ikann.sendMessage(m.chat, {
      image: {
url: `https://deliriussapi-oficial.vercel.app/canvas/book?text=${encodeURIComponent(text)}&footer=---`
      },
      caption: global.wm
    }, {
      quoted: m
    })
  } catch {
    m.reply('Terjadi kesalahan: ' + err.toString())
  }
}
break

case 'nuliskanan': {
  if (!text) return m.reply(`Contoh: ${p_c} toyaa`)
  try {
    react()
    ikann.sendMessage(m.chat, {
      image: {
url: `https://api.siputzx.my.id/api/m/nulis?text=${encodeURIComponent(text)}&name=${pushname}&class=`
      },
      caption: global.wm
    }, {
      quoted: m
    })
  } catch {
    m.reply('Terjadi kesalahan: ' + err.toString())
  }
}
break

case 'nuliskiri': {
  if (!text) return m.reply(`Contoh: ${p_c} toyaa`)
  try {
    react()
    const p = await fetchJson(`https://api.neoxr.eu/api/nulis?text=${encodeURIComponent(text)}&apikey=${neoxrapi}`)
    ikann.sendMessage(m.chat, {
      image: {
url: p.data.url
      },
      caption: global.wm
    }, {
      quoted: m
    })
  } catch {
    m.reply('Terjadi kesalahan: ' + err.toString())
  }
}
break

case 'foliokanan': {
  if (!text) return m.reply(`Contoh: ${p_c} toyaa`)
  try {
    react()
    ikann.sendMessage(m.chat, {
      image: {
url: `https:\/\/api.zeeoneofc.my.id/api/canvas/${command}?text=${encodeURIComponent(text)}&apikey=${global.onekey}`
      },
      caption: global.wm
    }, {
      quoted: m
    })
  } catch {
    m.reply('Terjadi kesalahan: ' + err.toString())
  }
}
break

case 'brat': {
 if (!text) {
 return peringatan(`⚠️ *Penggunaan Salah!*\nContoh: ${p_c} hai`, m);
 }

 if (text.length > 250) {
 return peringatan(`❌ *Karakter terlalu panjang!*\nMaksimal 250 karakter.`, m);
 }

 let user = pushname

 await react();

 try {
 let res = await fetch(`https://aqul-brat.hf.space/?text=${encodeURIComponent(text)}&isVideo=false`);
 let buffer = await res.buffer();

 await ikann.sendImageAsSticker(m.chat, buffer, m, {
 packname: ``,
 author: `${author} | ${user.nama}`
 });

 } catch (err) {
 console.error(err);
 return peringatan(`❌ *Terjadi kesalahan!*\n${err.message}`, m);
 }
}
break

case 'idch':
case 'cekidch': {
    if (!text) return m.reply(`Contoh: ${p_c} linknya`)
    if (!text.includes('https://whatsapp.com/channel/')) return m.reply('Harus berupa link saluran!')

    let result = text.split('https://whatsapp.com/channel/')[1]
    let res = await ikann.newsletterMetadata('invite', result)

    let rarw = `
• *Nama:* ${res.name}
• *Total Pengikut:* ${res.subscribers}
• *Status:* ${res.state}
• *Verified:* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}
• *Undangan:* ${res.invite ? `https://whatsapp.com/channel/${res.invite}` : '-'}
• *Deskripsi:* ${res.description ? res.description.slice(0, 100) + '...' : '-'}
    `
copybut(m.chat, rarw, 'ID Channel', res.id)
}
break

case 'toqr': {
    if (!text) return m.reply('Masukkan link atau teks untuk diubah jadi QR.\n\nContoh: .qr https://ikann.rf.gd');
    
    try {
        const qrImage = await generateQRCodeBuffer(text);
        await ikann.sendMessage(m.chat, {
            image: qrImage,
            caption: `QR Code dari:\n${text}`
        }, { quoted: m });
    } catch (e) {
        m.reply('Gagal membuat QR code.');
    }
}
break;

case 'jadwalsholat': 
case 'jadwalsolat': {
  if (!text) return m.reply(example('jawa'))
  let data = jadwalSholat(text)
  let anux = ``
}
break

case 'to64':
case 'tobase64': {
  if (!text) return m.reply(`Contoh: ${p_c} teksnya`)
  const base = await toBase64(text)
  const buttons = [
 {
 name: "cta_copy",
 buttonParamsJson: JSON.stringify({
 display_text: "Salin URL Catbox",
 id: "Code Base64",
 copy_code: base
 })
 }
 ];

 await ikann.sendButtonSpecial(
 m.chat,
 '*Sukses mengubah ke base64*',
 `*Base64:* ${base}`,
 null,
 buttons,
 { quoted: m })
}
break

case 'editimage':
case 'editgambar': {
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || ""
    let defaultPrompt = text
    
    if (!mime) {
        m.reply("Tidak ada gambar yang direply, membuat gambar default...")
        mime = "image/png"
        q = { msg: { mimetype: mime }, download: async () => fs.readFileSync("default_image.png") }
    }
    
    if (!/image\/(jpe?g|png)/.test(mime)) return m.reply(`Format ${mime} tidak didukung! Hanya jpeg/jpg/png`)
    
    let promptText = text || defaultPrompt
    
    try {
        let imgData = await q.download()
        let genAI = new GoogleGenerativeAI(geminiToken)
        const base64Image = imgData.toString("base64")
        
        const contents = [
            { text: promptText },
            {
                inlineData: {
                    mimeType: mime,
                    data: base64Image
                }
            }
        ]
        
        const model = genAI.getGenerativeModel({
            model: "gemini-2.0-flash-exp-image-generation",
            generationConfig: {
                responseModalities: ["Text", "Image"]
            },
        })
        
        const response = await model.generateContent(contents)
        let resultImage
        let resultText = ""
        
        for (const part of response.response.candidates[0].content.parts) {
            if (part.text) {
                resultText += part.text
            } else if (part.inlineData) {
                const imageData = part.inlineData.data
                resultImage = Buffer.from(imageData, "base64")
            }
        }
        
        if (resultImage) {
            const tmpDir = path.join(process.cwd(), "lib")
            if (!fs.existsSync(tmpDir)) {
                fs.mkdirSync(tmpDir, { recursive: true })
            }
            
            let tempPath = path.join(tmpDir, `gemini_${Date.now()}.png`)
            fs.writeFileSync(tempPath, resultImage)
            
            await ikann.sendMessage(m.chat, {
                image: { url: tempPath },
                caption: wm
            }, { quoted: m })
            
            setTimeout(() => {
                try {
                    fs.unlinkSync(tempPath)
                } catch (err) {
                    throw Error('Error')
                }
            }, 30000)
        }
    } catch (err) {
        console.error(err.message)
        m.reply('Terjadi kesalahan: '+err)
    }
}
break

case 'hitamkan':
case 'hytamkan':
case 'hytam': {
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || ""
    let defaultPrompt = "Ubah kulit karakter pada gambar tersebut dengan warna hitam kecoklatan yang alami dan natural. Pastikan perubahan warna hanya berlaku pada kulit karakter saja, tanpa mengubah warna mata, hidung, bibir, atau fitur wajah lainnya. Mata dan hidung harus tetap terlihat jelas dan tidak boleh hilang atau terdistorsi. Hasil akhir harus terlihat realistis dan sesuai dengan karakter aslinya."
    
    if (!mime) {
        m.reply("Tidak ada gambar yang direply, membuat gambar default...")
        mime = "image/png"
        q = { msg: { mimetype: mime }, download: async () => fs.readFileSync("default_image.png") }
    }
    
    if (!/image\/(jpe?g|png)/.test(mime)) return m.reply(`Format ${mime} tidak didukung! Hanya jpeg/jpg/png`)
    
    let promptText = text || defaultPrompt
    
    try {
        let imgData = await q.download()
        let genAI = new GoogleGenerativeAI(geminiToken)
        const base64Image = imgData.toString("base64")
        
        const contents = [
            { text: promptText },
            {
                inlineData: {
                    mimeType: mime,
                    data: base64Image
                }
            }
        ]
        
        const model = genAI.getGenerativeModel({
            model: "gemini-2.0-flash-exp-image-generation",
            generationConfig: {
                responseModalities: ["Text", "Image"]
            },
        })

        const response = await model.generateContent(contents)
        let resultImage
        let resultText = ""
        
        for (const part of response.response.candidates[0].content.parts) {
            if (part.text) {
                resultText += part.text
            } else if (part.inlineData) {
                const imageData = part.inlineData.data
                resultImage = Buffer.from(imageData, "base64")
            }
        }
        
        if (resultImage) {
            const tmpDir = path.join(process.cwd(), "lib")
            if (!fs.existsSync(tmpDir)) {
                fs.mkdirSync(tmpDir, { recursive: true })
            }
            
            let tempPath = path.join(tmpDir, `gemini_${Date.now()}.png`)
            fs.writeFileSync(tempPath, resultImage)
            
            await ikann.sendMessage(m.chat, {
                image: { url: tempPath },
                caption: wm
            }, { quoted: m })
            
            setTimeout(() => {
                try {
                    fs.unlinkSync(tempPath)
                } catch (err) {
                    throw Error('Error')
                }
            }, 30000)
        }
    } catch (err) {
        console.error(err.message)
        m.reply('Terjadi kesalahan: '+err)
    }
}
break

case 'putihkan':
case 'pytikan':
case 'pytih': {
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || ""
    let defaultPrompt = "Ubah kulit karakter pada gambar tersebut dengan warna putih yang alami dan natural. Pastikan perubahan warna hanya berlaku pada kulit karakter saja, tanpa mengubah warna mata, hidung, bibir, atau fitur wajah lainnya. Mata dan hidung harus tetap terlihat jelas dan tidak boleh hilang atau terdistorsi. Hasil akhir harus terlihat realistis dan sesuai dengan karakter aslinya."
    
    if (!mime) {
        m.reply("Tidak ada gambar yang direply, membuat gambar default...")
        mime = "image/png"
        q = { msg: { mimetype: mime }, download: async () => fs.readFileSync("default_image.png") }
    }
    
    if (!/image\/(jpe?g|png)/.test(mime)) return m.reply(`Format ${mime} tidak didukung! Hanya jpeg/jpg/png`)
    
    let promptText = text || defaultPrompt
    
    try {
        let imgData = await q.download()
        let genAI = new GoogleGenerativeAI(geminiToken)
        const base64Image = imgData.toString("base64")
        
        const contents = [
            { text: promptText },
            {
                inlineData: {
                    mimeType: mime,
                    data: base64Image
                }
            }
        ]
        
        const model = genAI.getGenerativeModel({
            model: "gemini-2.0-flash-exp-image-generation",
            generationConfig: {
                responseModalities: ["Text", "Image"]
            },
        })

        const response = await model.generateContent(contents)
        let resultImage
        let resultText = ""
        
        for (const part of response.response.candidates[0].content.parts) {
            if (part.text) {
                resultText += part.text
            } else if (part.inlineData) {
                const imageData = part.inlineData.data
                resultImage = Buffer.from(imageData, "base64")
            }
        }
        
        if (resultImage) {
            const tmpDir = path.join(process.cwd(), "lib")
            if (!fs.existsSync(tmpDir)) {
                fs.mkdirSync(tmpDir, { recursive: true })
            }
            
            let tempPath = path.join(tmpDir, `gemini_${Date.now()}.png`)
            fs.writeFileSync(tempPath, resultImage)
            
            await ikann.sendMessage(m.chat, {
                image: { url: tempPath },
                caption: wm
            }, { quoted: m })
            
            setTimeout(() => {
                try {
                    fs.unlinkSync(tempPath)
                } catch (err) {
                    throw Error('Error')
                }
            }, 30000)
        }
    } catch (err) {
        console.error(err.message)
        m.reply('Terjadi kesalahan: '+err)
    }
}
break

case 'hijabkan':
case 'tohijab': {
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || ""
    let defaultPrompt = "Desain ulang karakter pada gambar tersebut dengan menambahkan hijab warna putih yang sesuai dengan gaya hijab orang Indonesia. Pastikan hijab tersebut menutupi seluruh rambut karakter, sehingga tidak terlihat sama sekali. Hijab harus dirancang dengan cara yang natural dan realistis, sehingga terlihat seperti hijab yang dikenakan dalam kehidupan sehari-hari. Perhatikan detail dan tekstur hijab agar terlihat autentik dan sesuai dengan karakter aslinya."
    
    if (!mime) {
        m.reply("Tidak ada gambar yang direply, membuat gambar default...")
        mime = "image/png"
        q = { msg: { mimetype: mime }, download: async () => fs.readFileSync("default_image.png") }
    }
    
    if (!/image\/(jpe?g|png)/.test(mime)) return m.reply(`Format ${mime} tidak didukung! Hanya jpeg/jpg/png`)
    
    let promptText = text || defaultPrompt
    
    try {
        let imgData = await q.download()
        let genAI = new GoogleGenerativeAI(geminiToken)
        const base64Image = imgData.toString("base64")
        
        const contents = [
            { text: promptText },
            {
                inlineData: {
                    mimeType: mime,
                    data: base64Image
                }
            }
        ]
        
        const model = genAI.getGenerativeModel({
            model: "gemini-2.0-flash-exp-image-generation",
            generationConfig: {
                responseModalities: ["Text", "Image"]
            },
        })
        
        const response = await model.generateContent(contents)
        let resultImage
        let resultText = ""
        
        for (const part of response.response.candidates[0].content.parts) {
            if (part.text) {
                resultText += part.text
            } else if (part.inlineData) {
                const imageData = part.inlineData.data
                resultImage = Buffer.from(imageData, "base64")
            }
        }
        
        if (resultImage) {
            const tmpDir = path.join(process.cwd(), "lib")
            if (!fs.existsSync(tmpDir)) {
                fs.mkdirSync(tmpDir, { recursive: true })
            }
            
            let tempPath = path.join(tmpDir, `gemini_${Date.now()}.png`)
            fs.writeFileSync(tempPath, resultImage)
            
            await ikann.sendMessage(m.chat, {
                image: { url: tempPath },
                caption: wm
            }, { quoted: m })
            
            setTimeout(() => {
                try {
                    fs.unlinkSync(tempPath)
                } catch (err) {
                    throw Error('Error')
                }
            }, 30000)
        }
    } catch (err) {
        console.error(err.message)
        m.reply('Terjadi kesalahan: '+err)
    }
}
break

case 'tourl': {
    if (!/image/.test(mime) && !/video/.test(mime) && !/audio/.test(mime) && !/webp/.test(mime)) return m.reply('Harus berupa video, gambar, audio, atau stiker')
    let media = await ikann.downloadAndSaveMediaMessage(quoted)
    react()
    try {
const catBoxUrl = await CatBox(media)
const cloudMinii = await CloudMini(media)
const cloudMiniUrl = await cloudMinii || 'Gagal membuat link'
 const buttons = [
 {
 name: "cta_copy",
 buttonParamsJson: JSON.stringify({
 display_text: "Salin URL Catbox",
 id: "copycatbox",
 copy_code: catBoxUrl
 })
 },
 {
 name: "cta_copy",
 buttonParamsJson: JSON.stringify({
 display_text: "Salin URL CloudMini",
 id: "copycloud",
 copy_code: cloudMiniUrl
 })
 }
 ];

 await ikann.sendButtonSpecial(
 m.chat,
 '*Link Berhasil Diupload*',
 `*Catbox:* ${catBoxUrl}\n*CloudMini:* ${cloudMiniUrl}`,
 catBoxUrl,
 buttons,
 { quoted: m }
 );
    } catch (err) {
console.error(err)
    } finally {
await fs.unlinkSync(media)
    }
}
break

case 'rch': {
    if (!args[0]) {
        return m.reply(`Contoh penggunaan:\n.reactch https://whatsapp.com/channel/xxxx halo dunia`);
    }

    if (!args[0].startsWith("https://whatsapp.com/channel/")) {
        return m.reply("Link tautan tidak valid.");
    }

    const hurufGaya = {
        a: '🅐', b: '🅑', c: '🅒', d: '🅓', e: '🅔', f: '🅕', g: '🅖',
        h: '🅗', i: '🅘', j: '🅙', k: '🅚', l: '🅛', m: '🅜', n: '🅝',
        o: '🅞', p: '🅟', q: '🅠', r: '🅡', s: '🅢', t: '🅣', u: '🅤',
        v: '🅥', w: '🅦', x: '🅧', y: '🅨', z: '🅩',
        '0': '⓿', '1': '➊', '2': '➋', '3': '➌', '4': '➍',
        '5': '➎', '6': '➏', '7': '➐', '8': '➑', '9': '➒'
    };

    const emojiInput = args.slice(1).join(' ').toLowerCase();
    const emoji = emojiInput.split('').map(c => {
        if (c === ' ') return '―';
        return hurufGaya[c] || c;
    }).join('');

    try {
        const link = args[0];
        const channelId = link.split('/')[4];
        const messageId = link.split('/')[5];

        const res = await ikann.newsletterMetadata("invite", channelId);
        await ikann.newsletterReactMessage(res.id, messageId, emoji);

        return m.reply(`Berhasil mengirim reaction *${emoji}* ke pesan di channel *${res.name}*.`);
    } catch (e) {
        console.error(e);
        return m.reply("Gagal mengirim reaction. Pastikan link dan emoji valid.");
    }
};
break

// ==== Download Menu
case 'tiktok':
case 'tt': {
  // Cek jika command sudah diproses
  if (m.processedTikTok) return;
  m.processedTikTok = true;

  if (!text) return reply(`Contoh penggunaan:\n• .${command} <link>\n• .${command} <link> -video\n• .${command} <link> -audio`);

  const { tiktokDownloaderVideo } = require('./lib/scrape');
  
  // Ekstrak opsi dan link
  const isVideo = text.includes('-video');
  const isAudio = text.includes('-audio');
  const cleanLink = text.replace(/(-video|-audio)/g, '').trim();

  try {
    const tiktokData = await tiktokDownloaderVideo(cleanLink);

    // Format informasi
    const info = `📌 *Informasi Video*:
🌍 Region: ${tiktokData.region}
⏱ Durasi: ${tiktokData.duration}
📅 Diupload: ${tiktokData.taken_at}

📊 *Statistik*:
👀 Views: ${tiktokData.stats.views}
❤️ Likes: ${tiktokData.stats.likes}
💬 Komentar: ${tiktokData.stats.comment}
↪️ Share: ${tiktokData.stats.share}
⬇️ Download: ${tiktokData.stats.download}

👤 *Pembuat*:
${tiktokData.author.fullname} (@${tiktokData.author.nickname})

🎵 *Musik*:
${tiktokData.music_info.title} - ${tiktokData.music_info.author}
${tiktokData.music_info.album ? `Album: ${tiktokData.music_info.album}` : ''}

📝 *Keterangan*:
${tiktokData.title}`;

    // Handle opsi video
    if (isVideo) {
      const hdVideo = tiktokData.data.find(v => v.type === 'nowatermark_hd');
      if (!hdVideo) return reply('Video HD tidak tersedia');
      
      return await ikann.sendMessage(m.chat, {
        video: { url: hdVideo.url },
        caption: '© IkannNew 2222'
      }, { quoted: m });
    }

    // Handle opsi audio
    if (isAudio) {
      return await ikann.sendMessage(m.chat, {
        audio: { url: tiktokData.music_info.url },
        mimetype: 'audio/mpeg',
        ptt: false
      }, { quoted: m });
    }

    // Default: tampilkan opsi
    const buttons = [
      {
        buttonId: `${_p}${command} ${cleanLink} -video`,
        buttonText: { displayText: '🎥 Video' },
        type: 1
      },
      {
        buttonId: `${_p}${command} ${cleanLink} -audio`,
        buttonText: { displayText: '🎵 Audio' },
        type: 1
      }
    ];

    await ikann.sendMessage(m.chat, {
      image: { url: tiktokData.cover },
      caption: info,
      buttons,
      headerType: 4,
      viewOnce: true
    }, { quoted: m });

  } catch (error) {
    console.error('Error processing TikTok:', error);
    reply('Gagal memproses link TikTok. Pastikan link valid dan coba lagi.');
  }
}
break;

case 'ytvideo':
case 'ytmp4': {
  if (!text) return m.reply(`Contoh: ${p_c} linknya`)
  if (!text.match('youtu')) return m.reply('Harus berupa link youtube!')
  react()
  try {
    await downloadMp4(text)
  } catch {
    await downloadMp4v2(text)
  }
}
break

case 'ytaudio':
case 'ytmp3': {
  if (!text) return m.reply(`Contoh: ${p_c} linknya`)
  if (!text.match('youtu')) return m.reply('Harus berupa link youtube!')
  react()
  try {
    await downloadMp3(text)
  } catch {
    await downloadMp3v2(text)
  }
}
break

// ==== Search Menu
case 'play': {
  if (!text) {
    return m.reply(`Contoh: ${p_c} aku yang tersakiti`)
  }
  try {
    react()
    const play = await yt_search(text)
    if (!play || play.length === 0) {
      return m.reply('Tidak ada hasil yang ditemukan.')
    }

    const { title, url, author, ago, duration, views, authorUrl, thumbnail } = play[0]
    const body = `• Judul: ${title}\n` +
      `• Channel: ${author}\n` +
      `• Diupload: ${ago}\n` +
      `• Durasi: ${duration}\n` +
      `• Views: ${views}\n` +
      `• Link: ${url}\n\nKlik *Video* tuk vidio\nKlik *Audio* tuk audio`

    const buttons = [
      {
buttonId: `${_p}ytmp4 ${url}`,
buttonText: { displayText: 'Video' },
type: 1
      },
      {
buttonId: `${_p}ytmp3 ${url}`,
buttonText: { displayText: 'Audio' },
type: 1
      }
    ]

    await ikann.sendMessage(m.chat, {
      image: { url: thumbnail },
      caption: body,
      footer: null,
      buttons: buttons,
      headerType: 1,
      viewOnce: true
    }, { quoted: m })
  } catch (err) {
    console.error(err)
    m.reply('Terjadi kesalahan: '+err)
  }
}
break

// ==== Cpanel Menu
case 'cadmin': {
  if (!isOwner && !isPatner && !isOwnnel) return onlyNo()
  let t = text.split(',');
  if (t.length < 2) return m.reply(`Contoh: ${p_c} username,nomor`);
  let text__ = t[0]
  let emailX = text__
  let email = `${emailX}@buyer.ikann`
  let username = text__
  let name = text__
  let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
  if (!u) return m.reply(`Contoh: ${p_c} nama,nomor`);
  let d = (await ikann.onWhatsApp(u.split`@` [0]))[0] || {}
  let password = username + "admin"
  let f = await fetch(domain + "api/application/users", {
    "method": "POST",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey
    },
    "body": JSON.stringify({
      "email": email,
      "username": username,
      "first_name": name,
      "last_name": "Admin",
      "root_admin": true,
      "language": "en",
      "password": password.toString()
    })
  })
  let data = await f.json();
  if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
  let user = data.attributes
  m.reply(`BERHASIL  CADMIN!
• ID: ${user.id}
• UUID: ${user.uuid}
• Email: ${user.email}

Data lainnya sudah terkirim ke
privat chat...`)
let teksnyo = `*BERIKUT DATA ADMIN PANEL ANDA*

• ID: ${user.id}
• UUID: ${user.uuid}
• Email: ${user.email}
• Username: ${user.username}
• Password: ${password.toString()}
• Server: ${domain}

Simpan data admin panel baik-baik`
  buttonpanel(u,teksnyo,user.username,password.toString(),domain,null)
}
break

case 'dadmin': {
  if (!isOwner && !isPatner && !isOwnnel) return onlyNo()
  if (!args[0]) return m.reply(`Untuk melihat ID silahkan ketik ${_p}listadmin`)
  let cek = await fetch(domain + "api/application/users?page=1", {
    "method": "GET",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey
    }
  })
  let res2 = await cek.json();
  let users = res2.data;
  let getid = null
  let idadmin = null
  await users.forEach(async (e) => {
    if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
      getid = e.attributes.username
      idadmin = e.attributes.id
      let delusr = await fetch(domain + `api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
  "Accept": "application/json",
  "Content-Type": "application/json",
  "Authorization": "Bearer " + apikey
}
      })
      let res = delusr.ok ? {
errors: null
      } : await delusr.json()
    }
  })
  if (idadmin == null) return m.reply("ID admin tidak ditemukan!")
  m.reply(`Berhasil del admin panel *${getid}*`)
}
break

case 'ladmin': {
  if (!isOwner && !isPatner && !isOwnnel) return onlyNo()
  let page = args[0] ? args[0] : '1';
  let f = await fetch(domain + "api/application/users?page=" + page, {
    "method": "GET",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey
    }
  });
  let res = await f.json();
  let users = res.data;
  let messageText = "Berikut List Admin:\n\n";
  for (let user of users) {
    let u = user.attributes;
    if (u.root_admin) {
      messageText += `ID: ${u.id} - Status: ${u.attributes?.user?.server_limit === null ? 'Inactive' : 'Active'}\n`;
      messageText += `${u.username}\n`;
      messageText += `${u.first_name} ${u.last_name}\n\n`;
    }
  }
  messageText += `Halaman: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
  messageText += `Total: ${res.meta.pagination.count}`;
  await ikann.sendMessage(m.chat, {
    text: messageText
  }, {
    quoted: m
  });
  if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
    m.reply(`Contoh: ${p_c} ${res.meta.pagination.current_page + 1} untuk melihat halaman selanjutnya`);
  }
}
break

case '1gb': case '2gb': case '3gb': case '4gb': case '5gb': case '6gb': case '7gb': case '8gb': case '9gb': case '10gb': case 'unli': {
    if (!isOwner && !isReseller && !isAdminnel && !isOwnnel && !isPatner && !isPremium) return m.reply(onlyNo());
    if (!text) return m.reply(`Contoh: ${p_c} username`);
    
    const success = await handleGlobalCooldown(m, command, async () => {
        try {
            // Validasi input
            if (!text || text.includes('@')) return m.reply('Username tidak valid');
            
            // Konfigurasi resource
            let memo, disk, cpu;
            switch(command) {
                case '1gb':
                    memo = "1024"; disk = "1024"; cpu = "50";
                    break;
                case '2gb':
                    memo = "2048"; disk = "2048"; cpu = "80";
                    break;
                case '3gb':
                    memo = "3072"; disk = "3072"; cpu = "100";
                    break;
                case '4gb':
                    memo = "4096"; disk = "4096"; cpu = "100";
                    break;
                case '5gb':
                    memo = "5120"; disk = "5120"; cpu = "150";
                    break;
                case '6gb':
                    memo = "6144"; disk = "6144"; cpu = "200";
                    break;
                case '7gb':
                    memo = "7168"; disk = "7168"; cpu = "250";
                    break;
                case '8gb':
                    memo = "8192"; disk = "8192"; cpu = "300";
                    break;
                case '9gb':
                    memo = "9216"; disk = "9216"; cpu = "400";
                    break;
                case '10gb':
                    memo = "10240"; disk = "10240"; cpu = "400";
                    break;
                default: // unli
                    memo = "0"; disk = "0"; cpu = "0";
            }
            
            let username = text.trim();
            let u = m.sender;
            let name = username;
            let egg = global.eggs;
            let loc = global.locc;
            let email = `${username}${gmailPanel}`
            
            // Validasi pengirim
            if (!u) return m.reply('Invalid user');
            
            // Verifikasi WhatsApp
            let whatsappData;
            try {
                whatsappData = await ikann.onWhatsApp(u.split('@')[0]);
                if (!whatsappData || !whatsappData[0]) {
                    return m.reply('Gagal memverifikasi nomor WhatsApp');
                }
            } catch (waError) {
                console.error('WhatsApp verification error:', waError);
                return m.reply('Error saat verifikasi WhatsApp');
            }
            
            let d = whatsappData[0] || {};
            let password = `${username}@ikann`;
            let deskripsi = `${username} | IkannNew`;
            
            // Membuat user
            let userResponse;
            try {
                userResponse = await fetch(`${domain}api/application/users`, {
                    method: "POST",
                    headers: {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": `Bearer ${apikey}`
                    },
                    body: JSON.stringify({
                        email,
                        username,
                        first_name: username,
                        last_name: username,
                        language: "en",
                        password: password
                    })
                });
                
                const userData = await userResponse.json();
                
                if (!userData || userData.errors) {
                    const errorMsg = userData?.errors?.[0]?.detail || 'Gagal membuat user';
                    return m.reply(`Error: ${errorMsg}`);
                }
                
                if (!userData.attributes || !userData.attributes.id) {
                    return m.reply('Gagal mendapatkan ID user dari API');
                }
                
                const user = userData.attributes;
                await m.reply(`_Sedang Membuat Server..._`);
                
                // Get egg configuration
                let eggResponse;
                try {
                    eggResponse = await fetch(`${domain}api/application/nests/5/eggs/${egg}`, {
                        method: "GET",
                        headers: {
                            "Accept": "application/json",
                            "Content-Type": "application/json",
                            "Authorization": `Bearer ${apikey}`
                        }
                    });
                    
                    const eggData = await eggResponse.json();
                    
                    if (!eggData || !eggData.attributes || !eggData.attributes.startup) {
                        return m.reply('Gagal mendapatkan konfigurasi egg');
                    }
                    
                    const startup_cmd = eggData.attributes.startup;
                    
                    // Membuat server
                    let serverResponse;
                    try {
                        serverResponse = await fetch(`${domain}api/application/servers`, {
                            method: "POST",
                            headers: {
                                "Accept": "application/json",
                                "Content-Type": "application/json",
                                "Authorization": `Bearer ${apikey}`,
                            },
                            body: JSON.stringify({
                                name: name,
                                description: deskripsi,
                                user: user.id,
                                egg: parseInt(egg),
                                docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
                                startup: startup_cmd,
                                environment: {
                                    INST: "npm",
                                    USER_UPLOAD: "0",
                                    AUTO_UPDATE: "0",
                                    CMD_RUN: "npm start"
                                },
                                limits: {
                                    memory: parseInt(memo),
                                    swap: 0,
                                    disk: parseInt(disk),
                                    io: 500,
                                    cpu: parseInt(cpu)
                                },
                                feature_limits: {
                                    databases: 0,
                                    backups: 0,
                                    allocations: 0
                                },
                                deploy: {
                                    locations: [parseInt(loc)],
                                    dedicated_ip: false,
                                    port_range: [],
                                },
                            })
                        });
                        
                        const serverData = await serverResponse.json();
                        
                        if (!serverData || serverData.errors) {
                            const errorMsg = serverData?.errors?.[0]?.detail || 'Gagal membuat server';
                            return m.reply(`Error: ${errorMsg}`);
                        }
                        
                        if (!serverData.attributes || !serverData.attributes.id) {
                            return m.reply('Gagal mendapatkan ID server dari API');
                        }
                        
                        const server = serverData.attributes;
                        
                        // Kirim data panel ke user
                        let ctf = `*BERIKUT DATA PANEL ANDA*\n\n* ID User: ${user.id}\n* Username: ${user.username}\n* Password: ${password}\n* Server: ${domain}\n\n*Rules Pembelian Panel ⚠️*\n* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!\n* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!\n* Garansi Aktif 1 Minggu (1x replace)\n* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian`;
                        
                        buttonpanel(u, ctf, user.username, password, domain, null);
                        
                        // Kirim notifikasi ke owner
                        let message = `User ${u} telah membuat server klik dibawah ini untuk hapus\n\nID User : ${user.id}\nID Server : ${server.id}\nRam ${memo}\nDisk ${disk}\nCpu ${cpu}%`;
                        let kun = `{\"display_text\":\"Delete Panel\",\"id\":\"${_p}alldel ${server.id}-${user.id}\"}`;
                        quickreply1(owner + '@s.whatsapp.net', message, kun, null, m);
                        
                        // Konfirmasi sukses
                        await m.reply(`SUKSES CPANEL\n\nID User : ${user.id}\nID Server : ${server.id}\nRam ${memo}MB\nDisk ${disk}MB\nCpu ${cpu}%\n\nUsername dan password telah dikirim ke nomer target`);
                        
                    } catch (serverError) {
                        console.error('Server creation error:', serverError);
                        return m.reply('Error saat membuat server');
                    }
                    
                } catch (eggError) {
                    console.error('Egg config error:', eggError);
                    return m.reply('Error saat mendapatkan konfigurasi egg');
                }
                
            } catch (userError) {
                console.error('User creation error:', userError);
                return m.reply('Error saat membuat user');
            }
            
        } catch (globalError) {
            console.error('Global error:', globalError);
            return m.reply('Terjadi kesalahan sistem');
        }
    });
    
    if (!success) return; // Jika cooldown aktif atau error terjadi
}
break;

case 'listserver': {
  if (!isOwner && !isReseller && !isAdminnel && !isOwnnel && !isPatner && !isPremium) return onlyNo()
  let page = args[0] ? args[0] : '1';
  let f = await fetch(domain + "api/application/servers?page=" + page, {
    "method": "GET",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey
    }
  });
  let res = await f.json();
  let servers = res.data;
  let sections = [];
  let messageText = "Berikut list server nya:\n\n";
  for (let server of servers) {
    let s = server.attributes;
    let f3 = await fetch(domain + "api/ikanm/servers/" + s.uuid.split`-` [0] + "/resources", {
      "method": "GET",
      "headers": {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": "Bearer " + capikey
      }
    });
    let data = await f3.json();
    let status = data.attributes ? data.attributes.current_state : s.status;
    messageText += `ID server: ${s.id}\n`;
    messageText += `Nama server: ${s.name}\n`;
    messageText += `Status: ${status}\n\n`;
  }
  messageText += `Halaman: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
  messageText += `Total server: ${res.meta.pagination.count}`;
  await ikann.sendMessage(m.chat, {
    text: messageText
  }, {
    quoted: m
  });
  if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
    m.reply(`Contoh: ${p_c} ${res.meta.pagination.current_page + 1} untuk melihat halaman selanjutnya`);
  }
}
break

case 'delserver': {
  if (!isOwner && !isReseller && !isAdminnel && !isOwnnel && !isPatner && !isPremium) return onlyNo()
  let srv = args[0]
  if (!srv) return m.reply('ID nya mana?')
  let f = await fetch(domain + "api/application/servers/" + srv, {
    "method": "DELETE",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey,
    }
  })
  let res = f.ok ? {
    errors: null
  } : await f.json()
  if (res.errors) return m.reply('Server tidak ditemukan!')
  m.reply('Sukses menghapus server!')
}
break

case 'listuser': {
  if (!isOwner && !isReseller && !isAdminnel && !isOwnnel && !isPatner && !isPremium) return onlyNo()
  let page = args[0] ? args[0] : '1';
  let f = await fetch(domain + "api/application/users?page=" + page, {
    "method": "GET",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey
    }
  });
  let res = await f.json();
  let users = res.data;
  let messageText = "Berikut list user nya:\n\n";
  for (let user of users) {
    let u = user.attributes;
    messageText += `ID: ${u.id} - Status: ${u.attributes?.user?.server_limit === null ? 'Tidak aktif' : 'Aktif'}\n`;
    messageText += `${u.username}\n`;
    messageText += `${u.first_name} ${u.last_name}\n\n`;
  }
  messageText += `Halaman: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
  messageText += `Total user: ${res.meta.pagination.count}`;
  await ikann.sendMessage(m.chat, {
    text: messageText
  }, {
    quoted: m
  });
  if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
    m.reply(`Contoh: ${p_c} ${res.meta.pagination.current_page + 1} untuk melihat halaman selanjutnya`);
  }
}
break

case 'deluser': {
  if (!isOwner && !isReseller && !isAdminnel && !isOwnnel && !isPatner && !isPremium) return onlyNo()
  let usr = args[0]
  if (!usr) return m.reply('ID nya mana?')
  let f = await fetch(domain + "api/application/users/" + usr, {
    "method": "DELETE",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey
    }
  })
  let res = f.ok ? {
    errors: null
  } : await f.json()
  if (res.errors) return m.reply('User tidak ditemukan!')
  m.reply('Sukses menghapus user!')
}
break

case 'alldel': {
  const t = text.split('-');
let srv = t[0]
let usr = t[1]
  let f = await fetch(domain + "api/application/servers/" + srv, {
    "method": "DELETE",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey,
    }
  })
  let res = f.ok ? {
    errors: null
  } : await f.json()
  if (res.errors) return m.reply('Server tidak ditemukan!')
  m.reply('Sukses menghapus server!')
  
  let u = await fetch(domain + "api/application/users/" + usr, {
    "method": "DELETE",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey
    }
  })
  let ros = u.ok ? {
    errors: null
  } : await u.json()
  if (ros.errors) return m.reply('User tidak ditemukan!')
  m.reply('Sukses menghapus user!')
}
break

// ==== Grup Menu
case 'kudeta':
    if (!m.isGroup) return reply('Fitur ini hanya bisa digunakan di dalam grup!');
    if (!isAdmins) return reply('Fitur ini hanya bisa digunakan oleh admin grup!');
    if (!isBotAdmins) return reply('Bot harus menjadi admin untuk menjalankan fitur ini!');
    
    reply(`Kudeta dimulai...\nMengeluarkan semua anggota (kecuali admin & bot)...`);

    for (let participant of groupMembers) {
        let jid = participant.id;
        let isGroupAdmin = groupAdmins.includes(jid);

        if (jid !== botNumber && jid !== m.sender && !isGroupAdmin) {
            await delay(1500); // jeda agar tidak spam
            await ikann.groupParticipantsUpdate(m.chat, [jid], 'remove').catch(() => {});
        }
    }

    reply('✅ Kudeta selesai! Semua anggota telah dikeluarkan.');
    break;

case 'mute': {
    if (!m.isGroup) return reply(mess.grup)
    if (!isOwner) return reply(mess.owner)
    if (!text) return reply(example("on/off"))

    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {}

    let teks = text.toLowerCase()
    if (teks == "on") {
        if (global.db.groups[m.chat].mute === true) return m.reply(`*Mute* di grup ini sudah aktif!`)
        global.db.groups[m.chat].mute = true
        return m.reply("Berhasil menyalakan *mute* di grup ini")
    } else if (teks == "off") {
        if (global.db.groups[m.chat].mute === false) return m.reply(`*Mute* di grup ini tidak aktif!`)
        global.db.groups[m.chat].mute = false
        return m.reply("Berhasil mematikan *mute* di grup ini")
    } else {
        return reply(example("on/off"))
    }
}
break

case 'antilink': {
    if (!m.isGroup) return reply(mess.grup)
    if (!isOwner) return reply(mess.owner)
    if (!text) return reply(example("on/off"))

    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {}

    let teks = text.toLowerCase()
    if (teks == "on") {
        if (global.db.groups[m.chat].antilink === true) return m.reply(`*Antilink* di grup ini sudah aktif!`)
        if (global.db.groups[m.chat].antilink2 === true) global.db.groups[m.chat].antilink2 = false
        global.db.groups[m.chat].antilink = true
        return m.reply("Berhasil menyalakan *antilink* di grup ini")
    } else if (teks == "off") {
        if (global.db.groups[m.chat].antilink === false) return m.reply(`*Antilink* di grup ini tidak aktif!`)
        global.db.groups[m.chat].antilink = false
        return m.reply("Berhasil mematikan *antilink* di grup ini")
    } else {
        return reply(example("on/off"))
    }
}
break

case 'antitagsw': {
    if (!m.isGroup) return reply(mess.grup)
    if (!isOwner) return reply(mess.owner)
    if (!text) return reply(example("on/off"))

    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {}

    let teks = text.toLowerCase()
    if (teks == "on") {
        if (global.db.groups[m.chat].antitagsw === true) return m.reply(`*Antitagsw* di grup ini sudah aktif!`)
        global.db.groups[m.chat].antitagsw = true
        return m.reply("Berhasil menyalakan *antitagsw* di grup ini")
    } else if (teks == "off") {
        if (global.db.groups[m.chat].antitagsw === false) return m.reply(`*Antitagsw* di grup ini tidak aktif!`)
        global.db.groups[m.chat].antitagsw = false
        return m.reply("Berhasil mematikan *antitagsw* di grup ini")
    } else {
        return reply(example("on/off"))
    }
}
break

case 'antitoxic': {
    if (!m.isGroup) return reply(mess.grup)
    if (!isOwner) return reply(mess.owner)
    if (!text) return reply(example("on/off"))

    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {}

    let teks = text.toLowerCase()
    if (teks == "on") {
        if (global.db.groups[m.chat].antitoxic === true) return m.reply(`*Antitoxic* di grup ini sudah aktif!`)
        global.db.groups[m.chat].antitoxic = true
        return m.reply("Berhasil menyalakan *antitoxic* di grup ini")
    } else if (teks == "off") {
        if (global.db.groups[m.chat].antitoxic === false) return m.reply(`*Antitoxic* di grup ini tidak aktif!`)
        global.db.groups[m.chat].antitoxic = false
        return m.reply("Berhasil mematikan *antitoxic* di grup ini")
    } else {
        return reply(example("on/off"))
    }
}
break

case 'add': {
  if (!m.isGroup) return onlyGrup()
  if (!isOwner && !isAdmins) return onlyAdmin()
  if (!isBotAdmins) return onlyBotAdmin()

  let users = m.quoted ? m.quoted.sender : m.mentionedJid[0] ? m.mentionedJid[0] : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'

  if (!m.quoted && !m.mentionedJid.length && !text) {
    return m.reply('Tulis nomor yang mau di add')
  }

  try {
    const participants = await ikann.groupMetadata(m.chat)
    if (participants.participants.some(p => p.id === users)) {
      return m.reply('Target udah ada di grup.')
    }
    await ikann.groupParticipantsUpdate(m.chat, [users], 'add')
    m.reply('Sukses nambahin target.')
  } catch (err) {
    m.reply('Terjadi kesalahan: '+err)
  }
}
break

case 'kick': {
  if (!m.isGroup) return onlyGrup()
  if (!isOwner && !isAdmins) return onlyAdmin()
  if (!isBotAdmins) return onlyBotAdmin()

  let users = m.quoted ? m.quoted.sender : m.mentionedJid[0] ? m.mentionedJid[0] : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'

  if (!m.quoted && !m.mentionedJid.length && !text) {
    return m.reply('Tag/kutip pesan seseorang!')
  }

  try {
    const participants = await ikann.groupMetadata(m.chat)
    const ownerNumber = global.owner + '@s.whatsapp.net'

    if (users === ownerNumber || users === botNumber) {
      return m.reply('Ga bisa ngeluarin admin utama atau bot.')
    }

    if (!participants.participants.some(p => p.id === users)) {
      return m.reply('Target nggak ada di grup.')
    }

    await ikann.groupParticipantsUpdate(m.chat, [users], 'remove')
    m.reply('Sukses kick target.')
  } catch (err) {
    m.reply('Terjadi kesalahan.')
  }
}
break

case 'addtime': {
  if (!m.isGroup) return onlyGrup()
  if (!isAdmins) return onlyAdmin()
  if (!isBotAdmins) return onlyBotAdmin()

  if (!m.quoted && !m.mentionedJid.length && !text) {
    return m.reply('Tag/kutip pesan seseorang!')
  }

  const timeUnits = { detik: 1000, menit: 60000, jam: 3600000, hari: 86400000 }
  const duration = parseInt(args[0])
  const unit = args[1]?.toLowerCase()
  const multiplier = timeUnits[unit]

  if (!multiplier || isNaN(duration) || duration <= 0) {
    return m.reply(`Pilih:\nDetik\nMenit\nJam\nHari\n\nContoh: ${p_c} 10 detik`)
  }

  const timer = duration * multiplier
  m.reply(`Add time ${duration} ${unit} dimulai sekarang!`)

  setTimeout(async () => {
    let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
    const participants = await ikann.groupMetadata(m.chat)

    if (participants.participants.some(p => p.id === users)) {
      return m.reply('Target udah ada di grup.')
    }

    await ikann.groupParticipantsUpdate(m.chat, [users], 'add')
    m.reply('Sukses nambahin target.')
  }, timer)
}
break

case 'kicktime': {
  if (!m.isGroup) return onlyGrup()
  if (!isAdmins) return onlyAdmin()
  if (!isBotAdmins) return onlyBotAdmin()

  if (!m.quoted && !m.mentionedJid.length && !text) {
    return m.reply('Tag/kutip pesan seseorang!')
  }

  const timeUnits = { detik: 1000, menit: 60000, jam: 3600000, hari: 86400000 }
  const duration = parseInt(args[0])
  const unit = args[1]?.toLowerCase()
  const multiplier = timeUnits[unit]

  if (!multiplier || isNaN(duration) || duration <= 0) {
    return m.reply(`Pilih:\nDetik\nMenit\nJam\nHari\n\nContoh: ${p_c} 10 detik`)
  }

  const timer = duration * multiplier
  m.reply(`Kick time ${duration} ${unit} dimulai sekarang!`)

  setTimeout(async () => {
    let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
    const participants = await ikann.groupMetadata(m.chat)
    const ownerNumber = global.owner + '@s.whatsapp.net'

    if (users === ownerNumber || users === botNumber) {
      return m.reply('Ga bisa ngeluarin admin utama atau bot.')
    }

    if (!participants.participants.some(p => p.id === users)) {
      return m.reply('Target nggak ada di grup.')
    }

    await ikann.groupParticipantsUpdate(m.chat, [users], 'remove')
    m.reply('Sukses kick target.')
  }, timer)
}
break

case 'undang':
case 'invite': {
    if (!m.isGroup) return onlyGrup()
    if (!isBotAdmins) return onlyBotAdmin()
    if (!text) return m.reply(`Contoh: ${p_c} 628xx`)
    if (text.includes('+')) return m.reply(`Masukan nomor tanpa "+"`)
    
    const phoneNumber = text.replace(/[^0-9]/g, '')
    if (phoneNumber !== text || isNaN(phoneNumber)) return m.reply(`Hanya Angka! dan masukan kode (nomor) negara tanpa spasi atau tanda lain seperti "-" atau "."`)
    let link = 'https://chat.whatsapp.com/'+await ikann.groupInviteCode(m.chat)
    
    await ikann.sendMessage(`${text}@s.whatsapp.net`, {
        text: `*GROUP INVITATION*\n\nAdmin dari *${groupMetadata.subject}* mengundang kamu untuk bergabung nih.\n${link}`,
        mentions: [m.sender]
    })

    m.reply('Sukses mengundang nomor target!')
}
break

case 'linkgc': {
  if (!m.isGroup) return onlyGrup()
  if (!isBotAdmins) return onlyBotAdmin()
  let responsee = await ikann.groupInviteCode(m.chat)
  ikann.sendTeks(m.chat, `https://chat.whatsapp.com/${responsee}\n\nLink grup: ${groupMetadata.subject}`, m, {
    detectLink: true
  })
}
break

case 'revoke': {
  if (!m.isGroup) return onlyGrup()
  if (!isAdmins) return onlyAdmin()
  if (!isBotAdmins) return onlyBotAdmin()
  await ikann.groupRevokeInvite(m.chat)
  .then(res => {
    m.reply(`Sukses menyetel ulang link grup`)
  }).catch(() => m.reply('Terjadi kesalahan'))
}
break

case 'promote': {
  if (!m.isGroup) return onlyGrup()
  if (!isOwner && !isAdmins) return onlyAdmin()
  if (!isBotAdmins) return onlyBotAdmin()
  let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
  await ikann.groupParticipantsUpdate(m.chat, [users], 'promote').then((res) => m.reply('Sukses promote target')).catch((err) => m.reply('Terjadi kesalahan'))
}
break

case 'demote': {
  if (!m.isGroup) return onlyGrup()
  if (!isOwner && !isAdmins) return onlyAdmin()
  if (!isBotAdmins) return onlyBotAdmin()
  let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
  await ikann.groupParticipantsUpdate(m.chat, [users], 'demote').then((res) => m.reply('Sukses demote target')).catch((err) => m.reply('Terjadi kesalahan'))
}
break

case 'h':
case 'hidetag': {
  if (!m.isGroup) return onlyGrup()
  if (!isOwner && !isAdmins) return onlyOa()
  if (m.quoted) {
    ikann.sendMessage(m.chat, {
      forward: m.quoted.fakeObj,
      mentions: participants.map(a => a.id)
    })
  }
  if (!m.quoted) {
    ikann.sendMessage(m.chat, {
      text: q ? q : '',
      mentions: participants.map(a => a.id)
    }, {
      quoted: ftext
    })
  }
}
break

case 'tagall': {
  if (!m.isGroup) return onlyGrup()
  if (!isOwner && !isAdmins) return onlyOa()
  if (!isBotAdmins) return onlyBotAdmin()
  let teks = `*👥 Tag All By Admin*
 
Pesan: ${q ? q : 'Tidak ada'}\n\n`
  for (let mem of participants) {
    teks += `• @${mem.id.split('@')[0]}\n`
  }
  ikann.sendMessage(m.chat, {
    text: teks,
    mentions: participants.map(a => a.id)
  }, {
    quoted: m
  })
}
break

case 'totag': {
  if (!m.isGroup) return onlyGrup()
  if (!isOwner && !isAdmins) return onlyOa()
  if (!isBotAdmins) return onlyBotAdmin()
  if (!m.quoted) return m.reply(`Kutip pesan dengan caption ${p_c}`)
  ikann.sendMessage(m.chat, {
    forward: m.quoted.fakeObj,
    mentions: participants.map(a => a.id)
  })
}
break

case 'open':
case 'buka': {
  if (!m.isGroup) return onlyGrup()
  if (!isAdmins) return onlyAdmin()
  if (!isBotAdmins) return onlyBotAdmin()
  ikann.groupSettingUpdate(m.chat, 'not_announcement')
  m.reply(`Sukses membuka grup`)
}
break

case 'close':
case 'tutup': {
  if (!m.isGroup) return onlyGrup()
  if (!isAdmins) return onlyAdmin()
  if (!isBotAdmins) return onlyBotAdmin()
  ikann.groupSettingUpdate(m.chat, 'announcement')
  m.reply(`Sukses menutup grup`)
}
break

case 'opentime': {
  if (!m.isGroup) return onlyGrup()
  if (!isAdmins) return onlyAdmin();
  if (!isBotAdmins) return onlyBotAdmin();
  const timeUnits = {
    detik: 1000,
    menit: 60000,
    jam: 3600000,
    hari: 86400000
  };
  const unit = args[1]?.toLowerCase();
  const multiplier = timeUnits[unit];
  const duration = parseInt(args[0]);
  if (!multiplier || isNaN(duration) || duration <= 0) {
    return m.reply(`Pilih:\nDetik\nMenit\nJam\nHari\n\nContoh: ${p_c} 10 detik`);
  }
  const timer = duration * multiplier;
  m.reply(`Open time ${duration} ${unit} dimulai dari sekarang!`);
  const sendReminder = (message, delay) => {
    if (timer > delay) {
      setTimeout(() => {
        m.reply(message);
      }, timer - delay);
    }
  };
  sendReminder(`Pengingat: 10 detik lagi grup akan dibuka!`, 10000);
  setTimeout(() => {
    const open = `*[ OPEN TIME ]* Grup telah dibuka!`;
    ikann.groupSettingUpdate(from, 'not_announcement');
    m.reply(open);
  }, timer);
}
break

case 'closetime': {
  if (!m.isGroup) return onlyGrup()
  if (!isAdmins) return onlyAdmin();
  if (!isBotAdmins) return onlyBotAdmin();
  const timeUnits = {
    detik: 1000,
    menit: 60000,
    jam: 3600000,
    hari: 86400000
  };
  const unit = args[1]?.toLowerCase();
  const multiplier = timeUnits[unit];
  const duration = parseInt(args[0]);
  if (!multiplier || isNaN(duration) || duration <= 0) {
    return m.reply(`Pilih:\nDetik\nMenit\nJam\nHari\n\nContoh: ${p_c} 10 detik`);
  }
  const timer = duration * multiplier;
  m.reply(`Close time ${duration} ${unit} dimulai dari sekarang!`);
  const sendReminder = (message, delay) => {
    if (timer > delay) {
      setTimeout(() => {
        m.reply(message);
      }, timer - delay);
    }
  };
  sendReminder(`Pengingat: 10 detik lagi grup akan ditutup!`, 10000);
  setTimeout(() => {
    const close = `*[ CLOSE TIME ]* Grup telah ditutup!`;
    ikann.groupSettingUpdate(from, 'announcement');
    m.reply(close);
  }, timer);
}
break

case 'delete':
case 'del': {
  if (!froms == botNumber) return m.reply('Kutip pesan bot yang ingin dihapus!')
  ikann.sendMessage(m.chat, {
    delete: {
      remoteJid: m.chat,
      fromMe: true,
      id: m.quoted.id,
      participant: m.quoted.sender
    }
  })
}
break

case 'welcome': {
if (!m.isGroup) return warning(mess.grup)
if (!isOwner) return warning(mess.owner)
if (!text) return reply(example("on/off"))
let teks = text.toLowerCase()
if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {}
if (teks == "on") {
if (global.db.groups[m.chat].welcome == true) return m.reply(`*Welcome* di grup ini sudah aktif!`)
global.db.groups[m.chat].welcome = true
return m.reply("Berhasil menyalakan *welcome* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].welcome == false) return m.reply(`*Welcome* di grup ini tidak aktif!`)
global.db.groups[m.chat].welcome = false
return m.reply("Berhasil mematikan *welcome* di grup ini")
} else return reply(example("on/off"))
}
break

// ==== Jpm Menu
case 'addch': {
if (!isOwner) return onlyOwn();
  const idToAdd = text.trim()
  if (!idToAdd.endsWith('@newsletter'))
    return m.reply('❌ Format ID tidak valid. Gunakan @newsletter')

  const list = getChList()
  if (list.includes(idToAdd)) return m.reply('⚠️ ID sudah ada dalam daftar.')

  list.push(idToAdd)
  updateChList(list)
  return m.reply(`✅ ID ${idToAdd} berhasil ditambahkan ke daftar channel.`)
}
break

case 'delch': {
  if (!isOwner && !isJasher) return onlyNo();
  if (text && text.trim() !== '') {
    const idToRemove = text.trim()
    let list = getChList()
    if (!list.includes(idToRemove)) return m.reply('⚠️ ID tidak ditemukan dalam daftar.')

    list = list.filter(id => id !== idToRemove)
    updateChList(list)
    return m.reply(`✅ ID ${idToRemove} berhasil dihapus.`)
  } else {
    await sendRemoveChList(from, m)
  }
}
break

case 'listch': {
if (!isOwner && !isJasher) return onlyNo();
const list = await getChList();

const rows = list.map((id, i) => ({
title: `${id} || [ ${i + 1} ]`,
description: `> Jpmch By IkannNew`,
id: `.delch ${id}`,
}));

const listnye = {
title: 'Daftar ch',
sections: [
{
title: '',
highlight_label: '',
rows: rows.length > 0 ? rows : [{ title: 'Belum ada id', description: 'Silakan tambahkan id.', id: '0' }],
},
],
};

const pesan = `🎏 *Ikann - Jpmch*
> Silahkan Pilih Salah Untuk Menghapus Id Channel
`

listbut2(m.chat, pesan, listnye, m);
}
break

case 'jpmch': {
  if (!isOwner && !isJasher) return onlyNo();
  if (!text) return m.reply('❌ Masukkan teks.\nContoh: .jpmch Halo semua!')
  const list = getChList()
  if (!Array.isArray(list) || list.length === 0)
    return m.reply('📭 Daftar channel kosong.')

  let success = 0, failed = 0
  for (const jid of list) {
    try {
      await ikann.sendMessage(jid, { text }, { quoted: m })
      success++
    } catch (err) {
      console.error(`❌ Gagal kirim ke ${jid}:`, err)
      failed++
    }
  }

  return m.reply(`✅ Selesai kirim ke channel!\n\n📤 Berhasil: ${success}\n❌ Gagal: ${failed}`)
}
break

case 'jpm': {
if (!isOwner && !isJasher) return onlyNo();
if (!text) return reply('kirim berupa text / gambar + text / video + text')
const teks = text;
const jid = m.chat;

let rest = null, mediaType = null;
let getGroups = await ikann.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
let ahh = groups.map(v => v.id)

reply(`Proses wak`)
for (let i of ahh) {
    if (/image/.test(mime)) {
        rest = await ikann.downloadAndSaveMediaMessage(qmsg);
        mediaType = "image";
    } else if (/video/.test(mime)) {
        rest = await ikann.downloadAndSaveMediaMessage(qmsg);
        mediaType = "video";
    }

let nyo = `{\"display_text\":\"Chat With Owner\",\"url\":\"https://wa.me/+${owner}\",\"merchant_url\":\"https://www.google.com\"}`;

await buttonjpm(i, teks, nyo, "IkannNew", qlocJpm, rest, mediaType)}
reply(`Udah selesai nich`)
}
break

// ==== Buy Menu
case 'buysc': {
let requestAmount = 15000;
const amount = parseInt(requestAmount);
const totalAmount = amount;
let apis = 'https://www.decode.im-rerezz.xyz'
try {
const apiUrl = `${apis}/api/pay/okt-deposit?amount=${totalAmount}&qrcode=${global.orkut.codeqr}&apikey=16cfda5d38`;
const { data } = await axios.get(apiUrl, { responseType: 'json' });
if (!data.status) {
return m.reply(`❌ Gagal membuat QR deposit.\n📌 *Pesan:* ${data.message || 'Tidak ada detail error'}`);
}
const { qrImageUrl, transactionId } = data;
const fs = require('fs');
const path = require('path');
const qrFilePath = path.join(__dirname, 'sticker', `${transactionId}.png`);
if (!fs.existsSync(path.dirname(qrFilePath))) {
fs.mkdirSync(path.dirname(qrFilePath), { recursive: true });
}
const base64Data = qrImageUrl.split(';base64,').pop();
fs.writeFileSync(qrFilePath, base64Data, { encoding: 'base64' });
const caption = `✅ *Pembelian Script IkannNew*

💰 *Jumlah:* Rp ${amount.toLocaleString('id-ID')}
⚡ *Biaya Admin:* Rp -
📌 *Total yang harus dibayar:* Rp ${totalAmount.toLocaleString('id-ID')}
🆔 *ID Transaksi:* ${transactionId}

🔗 *Scan QR ini untuk bayar:*
⏰ *QR akan kadaluarsa dalam 5 menit.*`;
const qrMessage = await ikann.sendMessage(m.chat, { 
image: { url: qrFilePath }, 
caption: caption 
}, { quoted: m });
setTimeout(() => {
fs.unlinkSync(qrFilePath);
}, 5000);
const qrMessageID = qrMessage.key.id;
let checkCount = 0;
const maxChecks = 60;
const checkStatus = setInterval(async () => {
if (checkCount >= maxChecks) {
clearInterval(checkStatus);
await ikann.sendMessage(m.chat, { delete: qrMessage.key });
return m.reply('❌ Waktu pembayaran habis. Silakan buat deposit ulang.');
}
try {
const checkUrl = `${apis}/api/pay/okt-status?memid=${global.orkut.merchant}&keyorkut=${global.orkut.key}&apikey=16cfda5d38`;
const { data: checkResult } = await axios.get(checkUrl, { responseType: 'json' });
if (checkResult.status && checkResult.latestTransaction) {
const { date, amount: paidAmount, type, qris, brand_name, issuer_reff, buyer_reff } = checkResult.latestTransaction;
if (parseInt(paidAmount) === totalAmount) {
clearInterval(checkStatus);
await ikann.sendMessage(m.chat, { delete: qrMessage.key });

const fileUrl = 'https://files.catbox.moe/dgem7x.zip';
const response = await axios.get(fileUrl, { responseType: 'arraybuffer' });
const fileBuffer = Buffer.from(response.data);
await ikann.sendMessage(m.chat, {
  document: fileBuffer,
  mimetype: 'application/zip',
  fileName: `IkannNew.zip`,
  caption: `Ga masuk grup ga dapat update free
https://chat.whatsapp.com/Dhoz5hzgpRJEUyzZiiO4lc`
}, { quoted: m });
	  
const successMessage = `✅ *Pembayaran Berhasil!*

📅 *Tanggal:* ${date}
💰 *Jumlah:* Rp ${parseInt(amount).toLocaleString('id-ID')}
⚡ *Biaya Admin:* Rp -
📌 *Total Bayar:* Rp ${totalAmount.toLocaleString('id-ID')}

💳 *Metode Pembayaran:* ${brand_name}
🔗 *Referensi Issuer:* ${issuer_reff}
👤 *Referensi Pembeli:* ${buyer_reff}
`;
return m.reply(successMessage);
}
}
} catch (err) {
console.error(err);
}
checkCount++;
}, 5000);
} catch (err) {
console.error(err);
m.reply(`❌ Terjadi kesalahan saat memproses deposit.`);
}
}
break

// ==== Unban Menu
case 'unban': {
  if (!text) return m.reply('Masukkan nomor yang diblokir!\nContoh: .unban 6281234567890')

  const nomor = text.replace(/[^0-9]/g, '')
  if (!nomor.startsWith('62')) return m.reply('Gunakan format nomor Indonesia. Contoh: 628xxxx')
  
    const caption = `╭──────────────────────
│        UNBAN NOMOR
╰──────────────────────
■ *Statistik unban*
────────────────────────
- Tidak sepenuhnya kedip jadi jangan berharap lebih
- Pasti ada yang kedip
- Kamu bisa pilih bebas text ke berapa

■ *Nomor yang mau di unban*
${nomor}
`;

    const button = [
        {
            "name": "single_select",
            "buttonParamsJson": `{
                "title": "Pilihan unban",
                "highlight_label": "",
                "sections": [
                    {
                        "title": "Pilih Text Unban",
                        "rows": [
                            { "title": "Unban 1", "id": "${prefix}unban1 ${nomor}" },
                            { "title": "Unban 2", "id": "${prefix}unban2 ${nomor}" },
                            { "title": "Unban 3", "id": "${prefix}unban3 ${nomor}" }
                        ]
                    }
                ]
            }`
        }
    ];

    ikann.sendButtonImage(m.chat, "", caption, thum169, button, m)
}
break

case 'unban1': {
  if (!text) return m.reply('Masukkan nomor yang diblokir!\nContoh: .unban 6281234567890')

  const nomor = text.replace(/[^0-9]/g, '')
  if (!nomor.startsWith('62')) return m.reply('Gunakan format nomor Indonesia. Contoh: 628xxxx')

  const payload = {
    nomor: `+${nomor}`,
    email: 'support@support.whatsapp.com',
    subject: 'Permohonan Peninjauan Banned WhatsApp',
    message: `
Kepada Tim WhatsApp,

Saya ingin mengajukan permohonan untuk membuka kembali akun WhatsApp saya.

📱 Nomor WhatsApp: +${nomor}

Saya yakin pemblokiran ini terjadi karena kesalahan sistem atau aktivitas yang tidak saya sadari. Saya berkomitmen untuk selalu mematuhi Ketentuan Layanan WhatsApp.

Mohon bantuannya agar akun saya bisa dipulihkan.

Hormat saya,
Pengguna WhatsApp
    `
  }

  try {
    await axios.post('https://formspree.io/f/xqabagek', payload, {
      headers: { Accept: 'application/json' }
    })
    m.reply(`✅ Permohonan unban untuk nomor +${nomor} telah dikirim ke sistem WhatsApp.`)
  } catch (e) {
    console.error(e)
    m.reply('❌ Gagal mengirim permohonan. Pastikan endpoint benar & aktif.')
  }
}
break

case 'unban2': {
  if (!text) return m.reply('Masukkan nomor yang diblokir!\nContoh: .unban 6281234567890')

  const nomor = text.replace(/[^0-9]/g, '')
  if (!nomor.startsWith('62')) return m.reply('Gunakan format nomor Indonesia. Contoh: 628xxxx')

  const payload = {
    nomor: `+${nomor}`,
    email: 'support@support.whatsapp.com',
    subject: 'Permohonan Peninjauan Banned WhatsApp',
    message: `
Здравствуйте, команда поддержки WhatsApp. Приношу извинения за возможные неудобства и путаницу. Надеюсь, вы поймете и снимете блокировку моей учетной записи, поскольку она нужна мне для общения с семьей и друзьями. Я не знал условий использования. в прошлом, и я хорошо изучил и понял условия использования WhatsApp. Обещаю, что буду придерживаться всех условий в будущем. После снятия блокировки моего аккаунта я надеюсь, что вы поймете и снимите запрет на мою учетную запись. аккаунт. Это номер моего счета +${nomor}
    `
  }

  try {
    await axios.post('https://formspree.io/f/xqabagek', payload, {
      headers: { Accept: 'application/json' }
    })
    m.reply(`✅ Permohonan unban untuk nomor +${nomor} telah dikirim ke sistem WhatsApp.`)
  } catch (e) {
    console.error(e)
    m.reply('❌ Gagal mengirim permohonan. Pastikan endpoint benar & aktif.')
  }
}
break

case 'unban3': {
  if (!text) return m.reply('Masukkan nomor yang diblokir!\nContoh: .unban 6281234567890')

  const nomor = text.replace(/[^0-9]/g, '')
  if (!nomor.startsWith('62')) return m.reply('Gunakan format nomor Indonesia. Contoh: 628xxxx')

  const payload = {
    nomor: `+${nomor}`,
    email: 'support@support.whatsapp.com',
    subject: 'Permohonan Peninjauan Banned WhatsApp',
    message: `
Да пребудет с вами мир, милость и благословение Божие, мои братья в Боге, команда поддержки WhatsApp
Я человек, соблюдающий условия использования WhatsApp, и я никому не причиняю вреда и не беспокою, но однажды я использовал WhatsApp, как обычно, для общения со своими клиентами, друзьями и семьей. Я получил сообщение от неизвестного человека, содержащее эти слова: Добро пожаловать. Мы - служба поддержки WhatsApp. Просматривая журналы нашего сервера, мы заметили подозрительную активность. В вашей учетной записи мы отправили вам 6-значный код. Мы просим вас отправить текст, чтобы мы могли защитить вашу Если вы не отправите код в течение 6 часов, ваша учетная запись будет навсегда заблокирована для использования WhatsApp.
Когда я получил это сообщение, я боялся, что моя учетная запись будет удалена, поэтому я подумал, что неизвестный человек - это служба поддержки WhatsApp, и отправил ему сообщение. Через некоторое время я вышел из своей учетной записи, и я получил более одного короткого сообщения, содержащего текст WhatsApp.Когда я попытался снова войти в свою учетную запись, там говорилось, что мне нужно подождать еще час.Я подождал, и прошел час.Я попытался снова войти в свою учетную запись. Я заметил, что мой аккаунт заблокирован для использования WhatsApp. Когда я нажал на запрос на проверку, изнутри приложения был получен ответ, что я не могу войти в свой аккаунт в результате нарушения. Никакого нарушения я не совершал. Просто против меня была создана игра в «байху» и произошло вот это.Я искал способ связи со службой поддержки WhatsApp и обнаружил, что могу общаться с вами через электронную почту и другие приложения.Это все.Спасибо WhatsApp служба поддержки. Это номер моего счета +${nomor}
    `
  }

  try {
    await axios.post('https://formspree.io/f/xqabagek', payload, {
      headers: { Accept: 'application/json' }
    })
    m.reply(`✅ Permohonan unban untuk nomor +${nomor} telah dikirim ke sistem WhatsApp.`)
  } catch (e) {
    console.error(e)
    m.reply('❌ Gagal mengirim permohonan. Pastikan endpoint benar & aktif.')
  }
}
break

// =================================== //

default:

if (global.help.includes(command)) {
for (const handler of global.handlers) {
if (handler.command && handler.command.includes(command)) {
if (handler.owner && !isOwner) return onlyOwn()
if (handler.premium && !isPremium) return onlyPrem()
if (handler.group && !m.isGroup) return onlyGrup()
if (handler.botAdmin && !isBotAdmins) return onlyBotAdmin()
if (handler.admin && !isAdmins) return onlyAdmin()
if (handler.private && m.isGroup) return onlyPrivat()
let datahandler = {
isCmd, prefix, botNumber, isOwner, isAdmins, isBotAdmins, isPremium, isGc, isPc, body, text, args, command, ikann, quoted, chatUpdate, reply
}
await handler(m, datahandler)
break
}}
}

// =================================== //

if (m.text.toLowerCase() == "tes") {
m.reply("Online ♻️")
}

if (m.text.toLowerCase() == `@6283846754143`) {
m.reply(`Oy napa`)
}

if (m.text.toLowerCase() == `@${owner}`) {
m.reply('apa mau beli sc di dia ??')
}

}
} catch (err) {
console.log(util.format(err))
let OwN = global.owner
ikann.sendMessage(OwN + '@s.whatsapp.net', {text: 'Hi developer, tolong perbaiki beberapa ini\n\n' + util.format(err)})
}}

// =================================== //

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});